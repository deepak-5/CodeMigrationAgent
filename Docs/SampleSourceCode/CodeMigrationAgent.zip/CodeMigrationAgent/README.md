# Amazing Code Migration Coding Agent 🚀

Welcome to the **Code Migration Coding Agent**! This is a production-ready, enterprise-grade multi-agent system built on the **Microsoft Agent Framework**. It is designed for autonomous code migration, refactoring, and modernization.

## 🏗️ Architecture & Orchestration

This system utilizes a **Multi-Agent Workflow** to orchestrate specialized agents:

1.  **Architect Agent (`/a2a/architect`)**: Analyzes legacy code and creates a structured migration plan.
2.  **Coder Agent (`/a2a/coder`)**: Executes the actual code transformation.
3.  **Reviewer Agent (`/a2a/reviewer`)**: Validates code quality and security.
4.  **Migration Agent (`/a2a/migration`)**: Handles file I/O operations and final migration steps.
5.  **Migration Workflow (`/a2a/workflow`)**: A sequential workflow orchestrating the entire Plan → Code → Review → Test pipeline.

## ⚙️ Prerequisites

- **.NET 10 SDK** (or suitable version targeting `net10.0`)
- **Azure OpenAI Service** or an OpenAI-compatible endpoint.
- **Azure CLI** (for authentication)

## 🚀 How to Try It Out

### 1. Configure Environment Variables

The agents rely on Azure OpenAI to function. You must set the following environment variables before running the application.

You can set these in your terminal session or add them to your system environment variables:

**Windows (PowerShell):**
```powershell
$env:AZURE_OPENAI_ENDPOINT="https://<your-resource-name>.openai.azure.com/"
$env:AZURE_OPENAI_DEPLOYMENT_NAME="gpt-4o-mini"
```

**Authentication:** 
The app uses `DefaultAzureCredential`. Ensure you are logged into Azure CLI with an account that has access to the Azure OpenAI resource:
```bash
az login
```

### 2. Build and Run the Application

Navigate to the main web project directory and run the application:

```bash
cd CodeMigrationAgent
dotnet run
```

You should see console output indicating that the application is listening on specific HTTP/HTTPS ports (e.g., `https://localhost:7123`).

### 3. Interact via A2A Endpoints (Agent-to-Agent Protocol)

The agents are exposed via the **Agent-to-Agent (A2A)** protocol over HTTP. You can interact with the agents by sending HTTP POST requests to their respective mapping paths.

**Example: Requesting the Architect Agent to plan a migration**

Open a new terminal and use a tool like `curl` to send a message to the agent:

```bash
curl -X POST https://localhost:<YOUR_PORT>/a2a/architect \
     -H "Content-Type: application/json" \
     -d '{
           "messages": [
             {
               "role": "user",
               "content": "Please analyze my legacy code repository and provide an upgrade strategy from .NET Framework 4.8 to .NET 10."
             }
           ]
         }'
```

*(Note: Replace `<YOUR_PORT>` with the HTTPS port assigned when you ran `dotnet run`, and if using PowerShell's built-in `curl` alias `Invoke-WebRequest`, ensure proper JSON escaping or use Postman/Insomnia for easier testing).*

### Available Endpoints

- `POST /a2a/architect`
- `POST /a2a/coder`
- `POST /a2a/reviewer`
- `POST /a2a/migration`
- `POST /a2a/workflow` (To trigger the full orchestration pipeline)

## 🛠️ Upcoming Features & Development

- **Code Interpreter Integration**: For secure, sandboxed code execution and validation using `CodeInterpreterToolDefinition`.
- **Model Context Protocol (MCP)**: GitHub and File System server integrations for remote code manipulation.
- **Human-in-the-Loop Approvals**: Guardrails via `ApprovalRequiredAIFunction` for critical operations like committing code.
