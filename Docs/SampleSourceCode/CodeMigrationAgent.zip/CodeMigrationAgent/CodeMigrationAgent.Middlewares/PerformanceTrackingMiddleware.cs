using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

namespace CodeMigrationAgent.Middlewares
{
    /// <summary>
    /// Performance tracking middleware that measures per-run latency,
    /// message counts, and emits OpenTelemetry-compatible Activity spans.
    /// </summary>
    public static class PerformanceTrackingMiddleware
    {
        private static readonly ActivitySource ActivitySource = new("CodeMigrationAgent.Performance");

        /// <summary>
        /// Tracks performance metrics for each agent run.
        /// </summary>
        public static async Task<AgentResponse> InvokeAsync(
            IEnumerable<ChatMessage> messages,
            AgentSession? session,
            AgentRunOptions? options,
            AIAgent innerAgent,
            CancellationToken cancellationToken)
        {
            var agentName = innerAgent.Name ?? "UnknownAgent";
            var inputCount = messages.Count();
            var sw = Stopwatch.StartNew();

            using var activity = ActivitySource.StartActivity($"AgentRun.{agentName}");
            activity?.SetTag("agent.name", agentName);
            activity?.SetTag("agent.input_messages", inputCount);

            try
            {
                var response = await innerAgent.RunAsync(messages, session, options, cancellationToken);
                sw.Stop();

                var outputCount = response.Messages.Count;
                var responseLength = response.Messages.Sum(m => m.Text?.Length ?? 0);

                activity?.SetTag("agent.output_messages", outputCount);
                activity?.SetTag("agent.response_length", responseLength);
                activity?.SetTag("agent.duration_ms", sw.ElapsedMilliseconds);
                activity?.SetTag("agent.status", "success");

                Console.WriteLine(
                    $"[Perf] ⚡ {agentName}: {sw.ElapsedMilliseconds}ms | " +
                    $"In: {inputCount} msgs | Out: {outputCount} msgs | " +
                    $"Response: {responseLength:N0} chars");

                return response;
            }
            catch (Exception ex)
            {
                sw.Stop();
                activity?.SetTag("agent.status", "error");
                activity?.SetTag("agent.error", ex.Message);
                activity?.SetTag("agent.duration_ms", sw.ElapsedMilliseconds);

                Console.WriteLine($"[Perf] 💥 {agentName}: FAILED after {sw.ElapsedMilliseconds}ms — {ex.Message}");
                throw;
            }
        }
    }
}
