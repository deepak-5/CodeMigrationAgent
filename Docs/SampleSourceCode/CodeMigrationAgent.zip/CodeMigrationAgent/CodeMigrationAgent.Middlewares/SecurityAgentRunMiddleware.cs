using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Logging;

namespace CodeMigrationAgent.Middlewares
{
    public static class SecurityAgentRunMiddleware
    {
        private static readonly AgentSafetyPolicy DefaultPolicy = new();

        public static async Task<AgentResponse> InvokeAsync(
            IEnumerable<ChatMessage> messages,
            AgentSession? session,
            AgentRunOptions? options,
            AIAgent innerAgent,
            CancellationToken cancellationToken)
        {
            var logger = innerAgent.GetService(typeof(ILogger)) as ILogger;
            var policy = innerAgent.GetService(typeof(AgentSafetyPolicy)) as AgentSafetyPolicy ?? DefaultPolicy;

            var prompt = messages.LastOrDefault()?.Text ?? string.Empty;
            if (prompt.Length > policy.MaxUserPromptLength)
            {
                logger?.LogWarning("[SecurityMiddleware] Prompt too long: {Length}", prompt.Length);
                return new AgentResponse(new[]
                {
                    new ChatMessage(ChatRole.Assistant, $"Request rejected. Prompt length {prompt.Length} exceeds limit {policy.MaxUserPromptLength}.")
                });
            }

            var response = await innerAgent.RunAsync(messages, session, options, cancellationToken);

            var modified = new List<ChatMessage>();
            foreach (var msg in response.Messages)
            {
                if (msg.Role != ChatRole.Assistant || string.IsNullOrEmpty(msg.Text))
                {
                    modified.Add(msg);
                    continue;
                }

                var text = msg.Text;
                foreach (var pattern in policy.SecretPatterns)
                {
                    if (pattern.IsMatch(text))
                    {
                        logger?.LogWarning("[SecurityMiddleware] Redacted secret-like output pattern.");
                        text = pattern.Replace(text, "[REDACTED]");
                    }
                }

                if (text.Length > policy.MaxResponseLength)
                {
                    logger?.LogInformation("[SecurityMiddleware] Response too long ({Length}), truncating to {Max}.", text.Length, policy.MaxResponseLength);
                    text = text[..policy.MaxResponseLength] + "... [truncated]";
                }

                modified.Add(new ChatMessage(ChatRole.Assistant, text));
            }

            return new AgentResponse(modified);
        }
    }
}
