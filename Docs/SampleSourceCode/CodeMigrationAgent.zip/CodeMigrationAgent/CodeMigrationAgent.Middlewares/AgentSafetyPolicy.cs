using System.Text.RegularExpressions;

namespace CodeMigrationAgent.Middlewares
{
    /// <summary>
    /// Centralized safety policy for agent execution.
    /// Keep this conservative for dev; tighten further for prod.
    /// </summary>
    public sealed class AgentSafetyPolicy
    {
        /// <summary>
        /// If set, file operations should be constrained to these roots.
        /// (Enforced by tools/middleware where possible.)
        /// </summary>
        public string[] AllowedPathRoots { get; set; } = Array.Empty<string>();

        /// <summary>
        /// Hard block patterns for user prompts (pre-execution).
        /// </summary>
        public string[] BlockedPromptSubstrings { get; set; } = new[]
        {
            "rm -rf /", "rm -rf ~", "rm -rf .",
            "format c:", "format d:",
            "del /s /q c:",
            "drop database", "drop table",
            ":(){:|:&};:",
            "shutdown /s", "shutdown -h",
            "mkfs.", "dd if="
        };

        /// <summary>
        /// Regex patterns for secrets/credentials in output.
        /// </summary>
        public Regex[] SecretPatterns { get; set; } = new[]
        {
            new Regex(@"(?i)(api[_-]?key|apikey)\s*[:=]\s*['""']?\w{16,}", RegexOptions.Compiled),
            new Regex(@"(?i)(secret|password|passwd|pwd)\s*[:=]\s*['""']?\S{8,}", RegexOptions.Compiled),
            new Regex(@"(?i)(bearer\s+)[A-Za-z0-9\-._~+/]+=*", RegexOptions.Compiled),
            new Regex(@"(?i)(ghp_|github_pat_)[A-Za-z0-9]{36,}", RegexOptions.Compiled),
            new Regex(@"(?i)-----BEGIN\s+(RSA\s+)?PRIVATE\s+KEY-----", RegexOptions.Compiled),
            new Regex(@"(?i)(AKIA|ASIA)[A-Z0-9]{16}", RegexOptions.Compiled)
        };

        public int MaxResponseLength { get; set; } = 15_000;
        public int MaxUserPromptLength { get; set; } = 50_000;
    }
}
