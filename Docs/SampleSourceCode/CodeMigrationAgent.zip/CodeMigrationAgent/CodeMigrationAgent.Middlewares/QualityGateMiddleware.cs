using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using CodeMigrationAgent.Models;

namespace CodeMigrationAgent.Middlewares
{
    /// <summary>
    /// BMAD-inspired Quality Gate Middleware.
    /// Evaluates configurable halt-conditions after each agent execution.
    /// 
    /// BMAD pattern: halt-conditions that stop execution on failure.
    /// "HALT if build fails", "HALT if zero findings — re-analyze."
    ///
    /// Quality gates can be configured per-phase via MigrationModuleConfig.
    /// In YOLO mode, only Critical-severity gates cause halts.
    /// </summary>
    public static class QualityGateMiddleware
    {
        /// <summary>
        /// Middleware function that evaluates quality gates on agent output.
        /// Matches the existing middleware signature: (messages, session, options, agent, ct) → AgentResponse.
        /// </summary>
        public static async Task<AgentResponse> InvokeAsync(
            IEnumerable<ChatMessage> messages,
            AgentSession? session,
            AgentRunOptions? options,
            AIAgent innerAgent,
            CancellationToken cancellationToken)
        {
            var response = await innerAgent.RunAsync(messages, session, options, cancellationToken);
            // Default gate — checks for critical issues
            var defaultConfig = new QualityGateConfig();
            var result = EvaluateResponse(response, defaultConfig, "default");

            if (!result.Passed)
            {
                Console.WriteLine($"[QualityGate] 🛑 HALT — {result.Findings.Count} finding(s)");
                var haltMessage = FormatHaltMessage(result);
                return new AgentResponse(new[] { new ChatMessage(ChatRole.Assistant, haltMessage) });
            }

            Console.WriteLine("[QualityGate] ✅ Gate passed");
            return response;
        }

        /// <summary>
        /// Creates a quality gate middleware function configured for a specific phase.
        /// Use this for per-phase gate customization.
        /// </summary>
        public static Func<IEnumerable<ChatMessage>, AgentSession?, AgentRunOptions?, AIAgent, CancellationToken, Task<AgentResponse>>
            CreateGate(QualityGateConfig gateConfig, string phaseName)
        {
            return async (messages, session, options, agent, cancellationToken) =>
            {
                if (!gateConfig.Enabled)
                {
                    return await agent.RunAsync(messages, session, options, cancellationToken);
                }

                Console.WriteLine($"[QualityGate] 🚧 Evaluating quality gate for phase: {phaseName}");

                var response = await agent.RunAsync(messages, session, options, cancellationToken);
                var result = EvaluateResponse(response, gateConfig, phaseName);

                if (!result.Passed)
                {
                    Console.WriteLine($"[QualityGate] 🛑 HALT — {phaseName}: {result.Findings.Count} finding(s)");
                    return new AgentResponse(new[] { new ChatMessage(ChatRole.Assistant, FormatHaltMessage(result)) });
                }

                Console.WriteLine($"[QualityGate] ✅ Phase {phaseName} passed ({result.Findings.Count} minor findings)");
                return response;
            };
        }

        /// <summary>
        /// Evaluates an agent response against quality gate criteria.
        /// </summary>
        private static QualityGateResult EvaluateResponse(AgentResponse response, QualityGateConfig config, string phaseName)
        {
            var responseText = response.Messages.LastOrDefault()?.Text ?? "";
            return Evaluate(responseText, config, phaseName);
        }

        /// <summary>
        /// Evaluates a text output against quality gate criteria.
        /// Returns true if the gate passes, false if it should halt.
        /// </summary>
        public static QualityGateResult Evaluate(string agentOutput, QualityGateConfig config, string phaseName)
        {
            var result = new QualityGateResult { PhaseName = phaseName };

            // Build check
            if (config.RequireBuildPass &&
                agentOutput.Contains("Build FAILED", StringComparison.OrdinalIgnoreCase))
            {
                result.Findings.Add(new QualityFinding
                {
                    Severity = HaltSeverity.Critical,
                    Category = "Build",
                    Description = "Build failure detected"
                });
            }

            // Security check
            var securityKeywords = new[] { "hardcoded secret", "password exposed", "PII leak", "injection vulnerability" };
            foreach (var keyword in securityKeywords)
            {
                if (agentOutput.Contains(keyword, StringComparison.OrdinalIgnoreCase))
                {
                    result.Findings.Add(new QualityFinding
                    {
                        Severity = HaltSeverity.Critical,
                        Category = "Security",
                        Description = $"Security concern detected: {keyword}"
                    });
                }
            }

            // Custom halt conditions
            foreach (var condition in config.CustomHaltConditions)
            {
                if (agentOutput.Contains(condition, StringComparison.OrdinalIgnoreCase))
                {
                    result.Findings.Add(new QualityFinding
                    {
                        Severity = HaltSeverity.Error,
                        Category = "Custom",
                        Description = $"Custom halt condition triggered: {condition}"
                    });
                }
            }

            // Zero findings check (BMAD: "HALT if zero findings — suspicious")
            if (phaseName.Contains("review", StringComparison.OrdinalIgnoreCase) &&
                !agentOutput.Contains("Finding", StringComparison.OrdinalIgnoreCase) &&
                !agentOutput.Contains("Issue", StringComparison.OrdinalIgnoreCase))
            {
                result.Findings.Add(new QualityFinding
                {
                    Severity = HaltSeverity.Warning,
                    Category = "Review",
                    Description = "Zero findings from review — this is suspicious, consider re-analyzing"
                });
            }

            result.Passed = result.Findings.Count(f => f.Severity >= HaltSeverity.Error) <= config.MaxAllowedIssues;
            return result;
        }

        private static string FormatHaltMessage(QualityGateResult result)
        {
            var criticalCount = result.Findings.Count(f => f.Severity == HaltSeverity.Critical);
            return $"🛑 QUALITY GATE HALT — Phase: {result.PhaseName}\n\n" +
                $"Findings ({result.Findings.Count} total, {criticalCount} critical):\n" +
                string.Join("\n", result.Findings.Select(f =>
                    $"  [{f.Severity}] {f.Category}: {f.Description}")) +
                "\n\nPipeline HALTED. Fix these issues before proceeding.";
        }
    }

    /// <summary>Result of a quality gate evaluation.</summary>
    public class QualityGateResult
    {
        public string PhaseName { get; set; } = "";
        public bool Passed { get; set; } = true;
        public List<QualityFinding> Findings { get; set; } = new();
    }

    /// <summary>A single quality finding from gate evaluation.</summary>
    public class QualityFinding
    {
        public HaltSeverity Severity { get; set; }
        public string Category { get; set; } = "";
        public string Description { get; set; } = "";
    }
}
