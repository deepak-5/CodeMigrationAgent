using System.Diagnostics;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Logging;
using CodeMigrationAgent.Models;

namespace CodeMigrationAgent.Middlewares
{
    public static class FunctionCallingMiddleware
    {
        public static async ValueTask<object?> InvokeAsync(
            AIAgent agent,
            FunctionInvocationContext context,
            Func<FunctionInvocationContext, CancellationToken, ValueTask<object?>> next,
            CancellationToken cancellationToken)
        {
            var functionName = context.Function.Name;
            var sw = Stopwatch.StartNew();
            var logger = agent.GetService(typeof(ILogger)) as ILogger;

            logger?.LogInformation("[FunctionCalling] Invoking {FunctionName}", functionName);

            try
            {
                var result = await next(context, cancellationToken);
                sw.Stop();

                var resultPreview = result?.ToString() ?? "(null)";
                if (resultPreview.Length > 200)
                {
                    resultPreview = resultPreview[..200] + "...";
                }

                logger?.LogInformation(
                    "[FunctionCalling] {FunctionName} completed in {ElapsedMs}ms. Result preview: {ResultPreview}",
                    functionName,
                    sw.ElapsedMilliseconds,
                    resultPreview);
                await RuntimeObservability.WriteReplayAsync(new ReplayEvent(
                    RuntimeExecutionContext.RunId ?? "unknown",
                    "tool_call",
                    agent.Name ?? "unknown",
                    $"{functionName} => {resultPreview}",
                    DateTime.UtcNow,
                    RuntimeExecutionContext.TenantId));

                return result;
            }
            catch (Exception ex)
            {
                sw.Stop();
                logger?.LogError(ex, "[FunctionCalling] {FunctionName} failed after {ElapsedMs}ms", functionName, sw.ElapsedMilliseconds);
                throw;
            }
        }
    }
}
