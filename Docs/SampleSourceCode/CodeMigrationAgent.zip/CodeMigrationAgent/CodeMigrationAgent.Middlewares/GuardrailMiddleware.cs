using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Logging;

namespace CodeMigrationAgent.Middlewares
{
    /// <summary>
    /// Guardrail middleware that enforces content safety pre- and post-execution.
    /// Pre-execution:  Blocks dangerous shell commands and destructive inputs.
    /// Post-execution: Scrubs accidentally leaked secrets/PII from agent output
    ///                 and enforces maximum response length.
    /// </summary>
    public static class GuardrailMiddleware
    {
        private static readonly AgentSafetyPolicy DefaultPolicy = new();

        /// <summary>
        /// Agent run middleware — pre/post content safety guardrails.
        /// </summary>
        public static async Task<AgentResponse> InvokeAsync(
            IEnumerable<ChatMessage> messages,
            AgentSession? session,
            AgentRunOptions? options,
            AIAgent innerAgent,
            CancellationToken cancellationToken)
        {
            var logger = innerAgent.GetService(typeof(ILogger)) as ILogger;
            var policy = innerAgent.GetService(typeof(AgentSafetyPolicy)) as AgentSafetyPolicy ?? DefaultPolicy;

            // ─── PRE-EXECUTION: Block dangerous inputs ───
            var lastMessage = messages.LastOrDefault()?.Text ?? "";
            var lowerMessage = lastMessage.ToLowerInvariant();

            if (lastMessage.Length > policy.MaxUserPromptLength)
            {
                logger?.LogWarning("[Guardrail] Blocked prompt exceeding max length: {Length}", lastMessage.Length);
                return new AgentResponse(new[]
                {
                    new ChatMessage(ChatRole.Assistant,
                        $"⛔ Request blocked by safety guardrail. Prompt too large ({lastMessage.Length} chars).")
                });
            }

            foreach (var pattern in policy.BlockedPromptSubstrings)
            {
                if (lowerMessage.Contains(pattern))
                {
                    logger?.LogWarning("[Guardrail] BLOCKED dangerous pattern: {Pattern}", pattern);
                    return new AgentResponse(new[]
                    {
                        new ChatMessage(ChatRole.Assistant,
                            $"⛔ Request blocked by safety guardrail. Detected dangerous pattern: `{pattern}`. " +
                            "This action is not permitted in the migration pipeline.")
                    });
                }
            }

            // ─── EXECUTE ───
            var response = await innerAgent.RunAsync(messages, session, options, cancellationToken);

            // ─── POST-EXECUTION: Scrub secrets from output ───
            var modifiedMessages = new List<ChatMessage>();
            foreach (var msg in response.Messages)
            {
                if (msg.Role == ChatRole.Assistant && msg.Text is not null)
                {
                    var scrubbed = ScrubSecrets(msg.Text, policy, logger);

                    // Enforce max response length with smart truncation
                    if (scrubbed.Length > policy.MaxResponseLength)
                    {
                        logger?.LogInformation("[Guardrail] Response truncated from {Original} to {Max} chars.", scrubbed.Length, policy.MaxResponseLength);
                        scrubbed = scrubbed[..policy.MaxResponseLength] +
                            "\n\n… [response truncated by safety guardrail]";
                    }

                    modifiedMessages.Add(new ChatMessage(ChatRole.Assistant, scrubbed));
                }
                else
                {
                    modifiedMessages.Add(msg);
                }
            }

            return new AgentResponse(modifiedMessages);
        }

        /// <summary>
        /// Scrubs potential secrets/credentials from text using regex patterns.
        /// Replaces matches with [REDACTED].
        /// </summary>
        private static string ScrubSecrets(string text, AgentSafetyPolicy policy, ILogger? logger)
        {
            var scrubbed = text;
            foreach (var pattern in policy.SecretPatterns)
            {
                if (pattern.IsMatch(scrubbed))
                {
                    logger?.LogWarning("[Guardrail] Scrubbed potential secret from output (pattern: {Pattern})", pattern.ToString());
                    scrubbed = pattern.Replace(scrubbed, "[REDACTED]");
                }
            }
            return scrubbed;
        }
    }
}
