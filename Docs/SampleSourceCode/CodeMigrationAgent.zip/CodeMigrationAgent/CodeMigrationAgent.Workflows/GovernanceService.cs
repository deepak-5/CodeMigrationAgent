using CodeMigrationAgent.Models;

namespace CodeMigrationAgent.Workflows;

public sealed class GovernanceService
{
    public IReadOnlyList<string> ValidatePlanDag(MigrationPlan plan)
    {
        var errors = new List<string>();
        var all = plan.Modifications
            .Concat(plan.ParallelTasks.SelectMany(g => g.Tasks))
            .ToList();

        var byPath = all
            .Where(m => !string.IsNullOrWhiteSpace(m.FilePath))
            .ToDictionary(m => m.FilePath, StringComparer.OrdinalIgnoreCase);

        var graph = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
        foreach (var node in byPath.Keys)
        {
            graph[node] = [];
        }

        foreach (var mod in all)
        {
            foreach (var dep in mod.DependsOn)
            {
                if (!byPath.ContainsKey(dep))
                {
                    errors.Add($"Dependency '{dep}' referenced by '{mod.FilePath}' does not exist in plan.");
                    continue;
                }
                graph[mod.FilePath].Add(dep);
            }
        }

        var visited = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var stack = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        bool Dfs(string node)
        {
            if (stack.Contains(node)) return true;
            if (!visited.Add(node)) return false;
            stack.Add(node);
            foreach (var dep in graph[node])
            {
                if (Dfs(dep))
                {
                    return true;
                }
            }
            stack.Remove(node);
            return false;
        }

        foreach (var node in graph.Keys)
        {
            if (Dfs(node))
            {
                errors.Add($"Cycle detected in dependency graph at '{node}'.");
                break;
            }
        }

        return errors;
    }

    public List<TaskAssignment> ResolveConflictsAndAssignOwners(List<TaskAssignment> assignments, int maxWorkers)
    {
        var deduped = assignments
            .GroupBy(x => x.FilePath, StringComparer.OrdinalIgnoreCase)
            .Select(g =>
            {
                var winner = g.OrderBy(x => x.TaskId, StringComparer.Ordinal).First();
                if (g.Count() > 1)
                {
                    winner.Metadata["governance_conflict_count"] = g.Count().ToString();
                    winner.Description += "\n[Governance] Merged conflicting tasks for same file path.";
                }
                return winner;
            })
            .ToList();

        foreach (var assignment in deduped)
        {
            assignment.Metadata["owner"] = ResolveOwner(assignment, maxWorkers);
        }

        return deduped;
    }

    private static string ResolveOwner(TaskAssignment assignment, int maxWorkers)
    {
        var basis = $"{assignment.ParentPlanId}:{assignment.FilePath}:{assignment.ModificationType}";
        var hash = basis.GetHashCode();
        var index = Math.Abs(hash % Math.Max(1, maxWorkers));
        return $"worker-{index:D2}";
    }
}
