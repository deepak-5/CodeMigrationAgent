using System.Text.Json;
using CodeMigrationAgent.Models;
using Microsoft.Extensions.Logging;

namespace CodeMigrationAgent.Workflows
{
    /// <summary>
    /// BMAD-inspired Workflow Execution Engine.
    /// Executes workflow definitions step-by-step with:
    /// - Mandate enforcement at every step boundary
    /// - Halt-condition evaluation before/after each step
    /// - Checkpoint/save after every checkpoint step
    /// - Normal (interactive) and YOLO (full auto) execution modes
    /// - Protocol invocation support
    ///
    /// BMAD mandate: "Execute ALL steps IN EXACT ORDER. NEVER skip a step."
    /// </summary>
    public class WorkflowExecutionEngine
    {
        private readonly ILogger<WorkflowExecutionEngine>? _logger;
        private readonly CheckpointManager? _checkpointManager;
        private readonly Dictionary<string, object> _sessionVariables = new();

        public WorkflowExecutionEngine(
            ILogger<WorkflowExecutionEngine>? logger = null,
            CheckpointManager? checkpointManager = null)
        {
            _logger = logger;
            _checkpointManager = checkpointManager;
        }

        /// <summary>
        /// Executes a workflow definition from start to finish.
        /// Returns the execution result with all step outcomes.
        /// </summary>
        public async Task<WorkflowExecutionResult> ExecuteAsync(
            WorkflowDefinition workflow,
            Dictionary<string, string>? initialVariables = null,
            CancellationToken cancellationToken = default)
        {
            var result = new WorkflowExecutionResult
            {
                WorkflowName = workflow.Name,
                StartedAt = DateTime.UtcNow,
                Mode = workflow.Mode
            };

            // Initialize session variables
            if (initialVariables != null)
            {
                foreach (var kv in initialVariables)
                    _sessionVariables[kv.Key] = kv.Value;
            }

            _logger?.LogInformation("🚀 Starting workflow '{Name}' in {Mode} mode with {Steps} steps",
                workflow.Name, workflow.Mode, workflow.Steps.Count);

            // Log mandates
            foreach (var mandate in workflow.Mandates)
            {
                _logger?.LogWarning("⚡ MANDATE: {Mandate}", mandate);
            }

            try
            {
                // Execute steps in exact order (BMAD rule #1)
                foreach (var step in workflow.Steps.OrderBy(s => s.StepNumber))
                {
                    cancellationToken.ThrowIfCancellationRequested();

                    // Evaluate pre-step halt conditions
                    var haltResult = EvaluateHaltConditions(workflow.HaltConditions, result, "pre-step");
                    if (haltResult != null)
                    {
                        result.HaltedAt = step.StepNumber;
                        result.HaltReason = haltResult;
                        result.Status = WorkflowStatus.Halted;
                        _logger?.LogError("🛑 HALT at step {Step}: {Reason}", step.StepNumber, haltResult);
                        break;
                    }

                    // Execute the step
                    var stepResult = await ExecuteStepAsync(step, workflow, result, cancellationToken);
                    result.StepResults.Add(stepResult);

                    // Handle checkpoint
                    if (step.IsCheckpoint && _checkpointManager != null)
                    {
                        var checkpoint = new MigrationCheckpoint
                        {
                            CheckpointId = $"{workflow.Name}-step-{step.StepNumber}",
                            Phase = step.Title,
                            CompletedAt = DateTime.UtcNow,
                            Data = JsonSerializer.Serialize(result)
                        };
                        await _checkpointManager.SaveCheckpointAsync(checkpoint);
                        _logger?.LogInformation("💾 Checkpoint saved at step {Step}: {Title}", step.StepNumber, step.Title);
                    }

                    // Post-step halt condition evaluation
                    var postHaltResult = EvaluateHaltConditions(workflow.HaltConditions, result, "post-step");
                    if (postHaltResult != null)
                    {
                        result.HaltedAt = step.StepNumber;
                        result.HaltReason = postHaltResult;
                        result.Status = WorkflowStatus.Halted;
                        _logger?.LogError("🛑 HALT after step {Step}: {Reason}", step.StepNumber, postHaltResult);
                        break;
                    }
                }

                if (result.Status != WorkflowStatus.Halted)
                {
                    result.Status = WorkflowStatus.Completed;
                }
            }
            catch (OperationCanceledException)
            {
                result.Status = WorkflowStatus.Cancelled;
                _logger?.LogWarning("⚠️ Workflow '{Name}' was cancelled", workflow.Name);
            }
            catch (Exception ex)
            {
                result.Status = WorkflowStatus.Failed;
                result.HaltReason = ex.Message;
                _logger?.LogError(ex, "💥 Workflow '{Name}' failed", workflow.Name);
            }

            result.CompletedAt = DateTime.UtcNow;
            _logger?.LogInformation("✅ Workflow '{Name}' {Status} in {Duration}ms",
                workflow.Name, result.Status, result.Duration.TotalMilliseconds);

            return result;
        }

        /// <summary>
        /// Executes a single workflow step, handling conditional logic and sub-steps.
        /// </summary>
        private async Task<StepResult> ExecuteStepAsync(
            WorkflowStep step,
            WorkflowDefinition workflow,
            WorkflowExecutionResult overallResult,
            CancellationToken cancellationToken)
        {
            var stepResult = new StepResult
            {
                StepNumber = step.StepNumber,
                Title = step.Title,
                StartedAt = DateTime.UtcNow
            };

            _logger?.LogInformation("▶️ Step {N}: {Title}", step.StepNumber, step.Title);

            // Handle optional steps
            if (step.IsOptional && workflow.Mode != ExecutionMode.Yolo)
            {
                stepResult.Skipped = true;
                stepResult.SkipReason = "Optional step — skipped in Normal mode (would need user confirmation)";
                _logger?.LogInformation("⏭️ Skipping optional step {N}", step.StepNumber);
                stepResult.CompletedAt = DateTime.UtcNow;
                return stepResult;
            }

            // Handle conditional execution
            if (!string.IsNullOrEmpty(step.Condition))
            {
                var conditionMet = EvaluateCondition(step.Condition, overallResult);
                if (!conditionMet)
                {
                    stepResult.Skipped = true;
                    stepResult.SkipReason = $"Condition not met: {step.Condition}";
                    stepResult.CompletedAt = DateTime.UtcNow;
                    return stepResult;
                }
            }

            try
            {
                // Execute sub-steps if present
                if (step.SubSteps.Count > 0)
                {
                    foreach (var subStep in step.SubSteps.OrderBy(s => s.StepNumber))
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                        var subResult = await ExecuteStepAsync(subStep, workflow, overallResult, cancellationToken);
                        stepResult.SubStepResults.Add(subResult);
                    }
                }

                // Execute actions
                foreach (var action in step.Actions)
                {
                    _logger?.LogDebug("  ⚙️ Action: {Action}", action);
                    stepResult.ActionsCompleted.Add(action);
                }

                stepResult.Status = StepStatus.Completed;
            }
            catch (Exception ex)
            {
                stepResult.Status = StepStatus.Failed;
                stepResult.Error = ex.Message;
                _logger?.LogError(ex, "💥 Step {N} failed", step.StepNumber);

                // Critical steps cause workflow halt
                if (step.IsCritical)
                {
                    throw;
                }
            }

            stepResult.CompletedAt = DateTime.UtcNow;
            return stepResult;
        }

        /// <summary>
        /// Evaluates halt conditions against current workflow state.
        /// Returns the halt reason string if a halt should occur, null otherwise.
        /// </summary>
        private string? EvaluateHaltConditions(
            List<HaltCondition> conditions,
            WorkflowExecutionResult result,
            string phase)
        {
            foreach (var condition in conditions)
            {
                // In YOLO mode, only Critical severity causes a halt
                if (result.Mode == ExecutionMode.Yolo && condition.Severity != HaltSeverity.Critical)
                    continue;

                var failedSteps = result.StepResults.Count(s => s.Status == StepStatus.Failed);
                if (failedSteps > 0 && condition.Severity >= HaltSeverity.Error)
                {
                    return $"[{phase}] {condition.Condition} (Severity: {condition.Severity}, Failed steps: {failedSteps})";
                }
            }

            return null;
        }

        /// <summary>
        /// Evaluates a step condition against the current workflow state.
        /// </summary>
        private bool EvaluateCondition(string condition, WorkflowExecutionResult result)
        {
            // Simple condition evaluator — extensible for complex expressions
            if (condition.StartsWith("has_failures"))
                return result.StepResults.Any(s => s.Status == StepStatus.Failed);
            if (condition.StartsWith("all_passed"))
                return result.StepResults.All(s => s.Status == StepStatus.Completed || s.Skipped);
            if (condition.StartsWith("variable:"))
            {
                var varName = condition.Substring("variable:".Length).Trim();
                return _sessionVariables.ContainsKey(varName);
            }
            return true; // Default: condition is met
        }

        /// <summary>Sets a session variable for use in condition evaluation and variable substitution.</summary>
        public void SetVariable(string name, object value) => _sessionVariables[name] = value;

        /// <summary>Gets a session variable value.</summary>
        public T? GetVariable<T>(string name) =>
            _sessionVariables.TryGetValue(name, out var value) && value is T typed ? typed : default;
    }

    /// <summary>Result of a complete workflow execution.</summary>
    public class WorkflowExecutionResult
    {
        public string WorkflowName { get; set; } = "";
        public WorkflowStatus Status { get; set; } = WorkflowStatus.Running;
        public ExecutionMode Mode { get; set; }
        public DateTime StartedAt { get; set; }
        public DateTime CompletedAt { get; set; }
        public TimeSpan Duration => CompletedAt - StartedAt;
        public List<StepResult> StepResults { get; set; } = new();
        public int? HaltedAt { get; set; }
        public string? HaltReason { get; set; }
    }

    /// <summary>Result of a single step execution.</summary>
    public class StepResult
    {
        public int StepNumber { get; set; }
        public string Title { get; set; } = "";
        public StepStatus Status { get; set; } = StepStatus.Pending;
        public bool Skipped { get; set; }
        public string? SkipReason { get; set; }
        public string? Error { get; set; }
        public DateTime StartedAt { get; set; }
        public DateTime CompletedAt { get; set; }
        public List<string> ActionsCompleted { get; set; } = new();
        public List<StepResult> SubStepResults { get; set; } = new();
    }

    public enum WorkflowStatus { Running, Completed, Halted, Failed, Cancelled }
    public enum StepStatus { Pending, Completed, Failed, Skipped }
}
