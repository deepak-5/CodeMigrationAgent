using System.Diagnostics;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Logging;
using CodeMigrationAgent.Models;

namespace CodeMigrationAgent.Workflows
{
    /// <summary>
    /// The Parallel Workforce Engine.
    /// Takes a MigrationPlan, extracts independent tasks, fans them out to worker agents
    /// via Task.WhenAll, collects results, and merges them.
    /// Each worker gets a surgical TaskAssignment — not the full conversation.
    /// Supports configurable retry with exponential backoff for transient failures.
    /// </summary>
    public class ParallelOrchestrator
    {
        private readonly Func<AIAgent> _workerFactory;
        private readonly int _maxConcurrency;
        private readonly RetryPolicy _retryPolicy;
        private readonly ILogger? _logger;
        private readonly GovernanceService _governanceService;

        public ParallelOrchestrator(
            Func<AIAgent> workerFactory,
            int maxConcurrency = 8,
            RetryPolicy? retryPolicy = null,
            ILogger? logger = null,
            GovernanceService? governanceService = null)
        {
            _workerFactory = workerFactory;
            _maxConcurrency = maxConcurrency;
            _retryPolicy = retryPolicy ?? new RetryPolicy();
            _logger = logger;
            _governanceService = governanceService ?? new GovernanceService();
        }

        /// <summary>
        /// Fans out tasks from the migration plan to parallel worker agents.
        /// </summary>
        public async Task<List<TaskResult>> ExecuteParallelAsync(MigrationPlan plan, MigrationRunContext? runContext = null)
        {
            var governanceErrors = _governanceService.ValidatePlanDag(plan);
            if (governanceErrors.Count > 0)
            {
                var message = string.Join(" | ", governanceErrors);
                _logger?.LogError("[Governance] Invalid migration plan DAG: {Message}", message);
                return governanceErrors.Select((error, i) => new TaskResult
                {
                    TaskId = $"governance-{i + 1:D2}",
                    Status = Models.TaskStatus.Failed,
                    ErrorMessage = error
                }).ToList();
            }

            // Convert plan modifications to task assignments
            var assignments = plan.Modifications
                .Where(m => m.CanRunInParallel)
                .Select(m => new TaskAssignment
                {
                    ParentPlanId = plan.PlanId,
                    FilePath = m.FilePath,
                    Description = m.Description,
                    ModificationType = m.ModificationType,
                    DependencyContext = m.DependencyContext
                })
                .ToList();

            // Also include tasks from ParallelTaskGroups
            foreach (var group in plan.ParallelTasks)
            {
                foreach (var task in group.Tasks)
                {
                    assignments.Add(new TaskAssignment
                    {
                        ParentPlanId = plan.PlanId,
                        FilePath = task.FilePath,
                        Description = $"[{group.GroupName}] {task.Description}",
                        ModificationType = task.ModificationType,
                        DependencyContext = task.DependencyContext,
                        Metadata = new Dictionary<string, string>
                        {
                            ["group"] = group.GroupName
                        }
                    });
                }
            }

            assignments = _governanceService.ResolveConflictsAndAssignOwners(assignments, _maxConcurrency);

            _logger?.LogInformation("[ParallelOrchestrator] Fanning out {TaskCount} tasks (max concurrency: {MaxConcurrency}, retries: {MaxRetries})",
                assignments.Count, _maxConcurrency, _retryPolicy.MaxRetries);

            // Fan out with controlled concurrency using SemaphoreSlim
            var semaphore = new SemaphoreSlim(_maxConcurrency);
            var tasks = assignments.Select(assignment => ExecuteWorkerWithRetryAsync(assignment, semaphore, runContext));
            var results = await Task.WhenAll(tasks);

            // Log summary
            var succeeded = results.Count(r => r.Status == Models.TaskStatus.Completed);
            var failed = results.Count(r => r.Status == Models.TaskStatus.Failed);
            _logger?.LogInformation("[ParallelOrchestrator] Fan-in complete: {Succeeded} succeeded, {Failed} failed, {Total} total",
                succeeded, failed, results.Length);

            return results.ToList();
        }

        private async Task<TaskResult> ExecuteWorkerWithRetryAsync(TaskAssignment assignment, SemaphoreSlim semaphore, MigrationRunContext? runContext)
        {
            TaskResult? lastResult = null;

            for (int attempt = 0; attempt <= _retryPolicy.MaxRetries; attempt++)
            {
                if (attempt > 0)
                {
                    var delay = _retryPolicy.GetDelay(attempt - 1);
                    _logger?.LogWarning("[Worker] Retrying task {TaskId} (attempt {Attempt}/{MaxAttempts}) after {DelaySeconds:F1}s",
                        assignment.TaskId, attempt + 1, _retryPolicy.MaxRetries + 1, delay.TotalSeconds);
                    await Task.Delay(delay);
                }

                lastResult = await ExecuteWorkerAsync(assignment, semaphore, runContext);

                runContext?.Record(lastResult);

                if (lastResult.Status == Models.TaskStatus.Completed)
                    return lastResult;
            }

            _logger?.LogError("[Worker] Task {TaskId} failed after {Attempts} attempts.", assignment.TaskId, _retryPolicy.MaxRetries + 1);
            return lastResult!;
        }

        private async Task<TaskResult> ExecuteWorkerAsync(TaskAssignment assignment, SemaphoreSlim semaphore, MigrationRunContext? runContext)
        {
            await semaphore.WaitAsync();
            var stopwatch = Stopwatch.StartNew();

            try
            {
                using var workerActivity = PipelineTelemetry.StartWorker(assignment.TaskId, assignment.FilePath);
                workerActivity?.SetTag("worker.run_id", runContext?.RunId);

                _logger?.LogInformation("[Worker] Starting task {TaskId} for {FilePath}: {Description}",
                    assignment.TaskId,
                    assignment.FilePath,
                    assignment.Description[..Math.Min(120, assignment.Description.Length)]);

                var worker = _workerFactory();
                var prompt = BuildWorkerPrompt(assignment);
                var messages = new[] { new ChatMessage(ChatRole.User, prompt) };

                var response = await worker.RunAsync(messages);
                stopwatch.Stop();

                var output = response.Messages.LastOrDefault()?.Text ?? "";
                _logger?.LogInformation("[Worker] Task {TaskId} completed in {Seconds:F1}s", assignment.TaskId, stopwatch.Elapsed.TotalSeconds);

                return new TaskResult
                {
                    TaskId = assignment.TaskId,
                    Status = Models.TaskStatus.Completed,
                    OutputContent = output,
                    Duration = stopwatch.Elapsed,
                    AgentName = worker.Name ?? "UnknownAgent"
                };
            }
            catch (Exception ex)
            {
                stopwatch.Stop();
                _logger?.LogError(ex, "[Worker] Task {TaskId} failed after {Seconds:F1}s", assignment.TaskId, stopwatch.Elapsed.TotalSeconds);

                return new TaskResult
                {
                    TaskId = assignment.TaskId,
                    Status = Models.TaskStatus.Failed,
                    ErrorMessage = ex.Message,
                    Duration = stopwatch.Elapsed
                };
            }
            finally
            {
                semaphore.Release();
            }
        }

        /// <summary>
        /// Builds a focused, surgical prompt for a worker agent.
        /// Contains ONLY what the worker needs — no bloat.
        /// </summary>
                private string BuildWorkerPrompt(TaskAssignment assignment)
        {
            var prompt = $"## Task: {assignment.ModificationType} - {assignment.FilePath}\n\n";
            if (assignment.Metadata.TryGetValue("owner", out var owner))
            {
                prompt += $"**Deterministic Owner:** {owner}\n\n";
            }

            prompt += $"**Description:** {assignment.Description}\n\n";

            if (!string.IsNullOrWhiteSpace(assignment.DependencyContext))
            {
                prompt += $"**Dependency Context (related code you need to know):**\n{assignment.DependencyContext}\n\n";
            }

            prompt += "**Instructions:** Execute this task completely. Use your tools to read the file, make the modifications, " +
                      "verify the build succeeds, and report the result. Do NOT ask for approval - execute autonomously.";

            return prompt;
        }
    }
}

