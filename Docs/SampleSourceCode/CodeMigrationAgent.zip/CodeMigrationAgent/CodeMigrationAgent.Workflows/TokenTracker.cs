using System.Text.Json;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Logging;
using Microsoft.ML.Tokenizers;
using CodeMigrationAgent.Models;

namespace CodeMigrationAgent.Workflows
{
    /// <summary>
    /// Wraps an IChatClient to track token usage per request.
    /// When the AgentTokenBudget is exhausted (~90%), signals the ContinuationOrchestrator.
    /// Uses response metadata for real token counts, falls back to char-based estimation.
    /// </summary>
    public class TokenTracker : IChatClient
    {
        private readonly IChatClient _inner;
        private readonly AgentTokenBudget _budget;
        private readonly ILogger? _logger;
        private readonly Tokenizer _tokenizer;

        public AgentTokenBudget Budget => _budget;

        public TokenTracker(IChatClient inner, AgentTokenBudget? budget = null, ILogger? logger = null)
        {
            _inner = inner;
            _budget = budget ?? new AgentTokenBudget();
            _logger = logger;
            _tokenizer = TiktokenTokenizer.CreateForModel("gpt-4o");
        }

        public async Task<ChatResponse> GetResponseAsync(
            IEnumerable<ChatMessage> chatMessages,
            ChatOptions? options = null,
            CancellationToken cancellationToken = default)
        {
            // Estimate input tokens using TiktokenTokenizer for gpt-4o
            var inputEstimate = chatMessages.Sum(m => _tokenizer.CountTokens(m.Text ?? string.Empty));
            _budget.AddTokens(inputEstimate);

            _logger?.LogDebug("[TokenTracker] Pre-call budget: {Budget}", _budget.ToString());

            if (_budget.IsExhausted)
            {
                _logger?.LogWarning("[TokenTracker] Budget exhausted BEFORE call. Signaling continuation.");
                throw new TokenBudgetExhaustedException(_budget);
            }

            var response = await _inner.GetResponseAsync(chatMessages, options, cancellationToken);

            // Try to get real token counts from response Usage metadata
            if (response.Usage is { } usage)
            {
                var realOutput = (int)(usage.OutputTokenCount ?? 0);
                _budget.AddTokens(realOutput);

                // Correct the input estimate with real count if available
                var realInput = (int)(usage.InputTokenCount ?? 0);
                if (realInput > 0)
                {
                    _budget.CorrectInputTokens(inputEstimate, realInput);
                }

                _logger?.LogDebug("[TokenTracker] Real usage — Input: {InputTokens}, Output: {OutputTokens}", realInput, realOutput);
            }
            else
            {
                // Fallback: estimate output tokens using TiktokenTokenizer for gpt-4o
                var outputEstimate = response.Messages.Sum(m => _tokenizer.CountTokens(m.Text ?? string.Empty));
                _budget.AddTokens(outputEstimate);
                _logger?.LogDebug("[TokenTracker] Estimated output tokens (tiktoken): {OutputTokens}", outputEstimate);
            }

            _logger?.LogDebug("[TokenTracker] Post-call budget: {Budget}", _budget.ToString());

            if (_budget.IsExhausted)
            {
                _logger?.LogWarning("[TokenTracker] Budget exhausted AFTER call. Next request will trigger continuation.");
            }

            var textPreview = response.Messages.LastOrDefault()?.Text ?? string.Empty;
            if (textPreview.Length > 1000)
            {
                textPreview = textPreview[..1000] + "...";
            }
            await RuntimeObservability.WriteReplayAsync(new ReplayEvent(
                RuntimeExecutionContext.RunId ?? "unknown",
                "model_turn",
                "IChatClient",
                textPreview,
                DateTime.UtcNow,
                RuntimeExecutionContext.TenantId), cancellationToken);

            return response;
        }

        public async IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(
            IEnumerable<ChatMessage> chatMessages,
            ChatOptions? options = null,
            [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            // Estimate input tokens using TiktokenTokenizer for gpt-4o
            var inputEstimate = chatMessages.Sum(m => _tokenizer.CountTokens(m.Text ?? string.Empty));
            _budget.AddTokens(inputEstimate);

            _logger?.LogDebug("[TokenTracker] Streaming — Pre-call budget: {Budget}", _budget.ToString());

            if (_budget.IsExhausted)
            {
                _logger?.LogWarning("[TokenTracker] Budget exhausted BEFORE streaming. Signaling continuation.");
                throw new TokenBudgetExhaustedException(_budget);
            }

            int streamedTokens = 0;
            await foreach (var update in _inner.GetStreamingResponseAsync(chatMessages, options, cancellationToken))
            {
                // Accumulate tokens from each chunk using TiktokenTokenizer
                var chunkTokens = _tokenizer.CountTokens(update.Text ?? string.Empty);
                streamedTokens += chunkTokens;
                _budget.AddTokens(chunkTokens);

                yield return update;

                // Check budget after each chunk — allow graceful cutoff
                if (_budget.IsExhausted)
                {
                    _logger?.LogWarning("[TokenTracker] Budget exhausted mid-stream after {StreamedTokens} estimated output tokens.", streamedTokens);
                    throw new TokenBudgetExhaustedException(_budget);
                }
            }

            _logger?.LogDebug("[TokenTracker] Streaming complete — {StreamedTokens} estimated output tokens. Budget: {Budget}",
                streamedTokens, _budget.ToString());
        }

        public void Dispose() => _inner.Dispose();
        public object? GetService(Type serviceType, object? serviceKey = null) => _inner.GetService(serviceType, serviceKey);
    }

    /// <summary>
    /// Thrown when the token budget is exhausted. Caught by ContinuationOrchestrator.
    /// </summary>
    public class TokenBudgetExhaustedException : Exception
    {
        public AgentTokenBudget Budget { get; }
        public TokenBudgetExhaustedException(AgentTokenBudget budget)
            : base($"Token budget exhausted: {budget}")
        {
            Budget = budget;
        }
    }
}
