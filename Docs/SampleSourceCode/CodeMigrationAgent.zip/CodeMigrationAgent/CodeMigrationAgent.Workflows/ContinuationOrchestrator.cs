using System.Diagnostics;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Logging;
using CodeMigrationAgent.Models;

namespace CodeMigrationAgent.Workflows
{
    /// <summary>
    /// Manages the token continuation loop:
    /// 1. Run agent with TokenTracker
    /// 2. If TokenBudgetExhaustedException is thrown → serialize ContinuationState
    /// 3. Spawn a fresh continuation agent with summarized context
    /// 4. Resume from where the previous agent left off
    /// No work is ever lost.
    /// </summary>
    public class ContinuationOrchestrator
    {
        private readonly Func<TokenTracker, AIAgent> _agentFactory;
        private readonly IChatClient _baseChatClient;
        private readonly int _maxTokensPerAgent;
        private readonly int _maxContinuations;
        private readonly ILogger? _logger;

        public ContinuationOrchestrator(
            IChatClient baseChatClient,
            Func<TokenTracker, AIAgent> agentFactory,
            int maxTokensPerAgent = 200_000,
            int maxContinuations = 10,
            ILogger? logger = null)
        {
            _baseChatClient = baseChatClient;
            _agentFactory = agentFactory;
            _maxTokensPerAgent = maxTokensPerAgent;
            _maxContinuations = maxContinuations;
            _logger = logger;
        }

        /// <summary>
        /// Runs an agent with automatic continuation when the token budget is exhausted.
        /// </summary>
        public async Task<AgentResponse> RunWithContinuationAsync(
            IEnumerable<ChatMessage> initialMessages,
            ContinuationState? existingState = null,
            MigrationRunContext? runContext = null,
            CancellationToken cancellationToken = default)
        {
            var state = existingState ?? new ContinuationState();
            var allResponseMessages = new List<ChatMessage>();

            for (int iteration = 0; iteration < _maxContinuations; iteration++)
            {
                state.Iteration = iteration;
                var budget = new AgentTokenBudget { MaxTokens = _maxTokensPerAgent };
                var tracker = new TokenTracker(_baseChatClient, budget, _logger);
                var agent = _agentFactory(tracker);
                var session = await agent.CreateSessionAsync(cancellationToken);

                // Build the messages for this iteration
                var messages = BuildContinuationMessages(initialMessages, state, iteration);

                _logger?.LogInformation("[ContinuationOrchestrator] Starting iteration {Iteration}. Budget: {Budget}. RunId: {RunId}",
                    iteration, budget.ToString(), runContext?.RunId);
                using var iterationActivity = PipelineTelemetry.StartContinuation(iteration, _maxTokensPerAgent);

                try
                {
#pragma warning disable MEAI001 // Type is for evaluation purposes only and is subject to change or removal in future updates.
                    var options = new ChatClientAgentRunOptions { AllowBackgroundResponses = true };
                    var response = await agent.RunAsync(messages, session: session, options: options, cancellationToken: cancellationToken);
                    
                    // Poll if the agent returns a background response continuation token
                    while (response.ContinuationToken is not null)
                    {
                        _logger?.LogDebug("[ContinuationOrchestrator] Background operation in progress. Polling...");
                        await Task.Delay(TimeSpan.FromSeconds(2), cancellationToken);
                        options.ContinuationToken = response.ContinuationToken;
                        response = await agent.RunAsync(Array.Empty<ChatMessage>(), session: session, options: options, cancellationToken: cancellationToken);
                    }
#pragma warning restore MEAI001

                    allResponseMessages.AddRange(response.Messages);

                    // Success — agent completed within budget
                    state.TotalTokensUsedAcrossIterations += budget.UsedTokens;
                    iterationActivity?.SetTag("continuation.status", "completed");
                    iterationActivity?.SetTag("continuation.tokens_used", budget.UsedTokens);
                    _logger?.LogInformation("[ContinuationOrchestrator] Completed in {Iterations} iteration(s). Total tokens: {TotalTokens:N0}. RunId: {RunId}",
                        iteration + 1, state.TotalTokensUsedAcrossIterations, runContext?.RunId);

                    return new AgentResponse(allResponseMessages);
                }
                catch (TokenBudgetExhaustedException)
                {
                    iterationActivity?.SetTag("continuation.status", "exhausted");
                    iterationActivity?.SetTag("continuation.tokens_used", budget.UsedTokens);
                    // Budget exhausted — serialize state and continue
                    state.TotalTokensUsedAcrossIterations += budget.UsedTokens;

                    // If we have structured task results, carry them forward.
                    if (runContext is not null)
                    {
                        state.CompletedTasks = runContext.TaskResults.Values
                            .Where(r => r.Status == Models.TaskStatus.Completed)
                            .OrderBy(r => r.TaskId)
                            .ToList();

                        state.PendingTasks = runContext.TaskResults.Values
                            .Where(r => r.Status != Models.TaskStatus.Completed)
                            .OrderBy(r => r.TaskId)
                            .Select(r => new TaskAssignment
                            {
                                TaskId = r.TaskId,
                                Description = r.ErrorMessage ?? "Pending",
                                FilePath = "",
                                ModificationType = "Unknown"
                            })
                            .ToList();
                    }

                    // Capture what was accomplished so far
                    state.SharedContextSummary = BuildContextSummary(allResponseMessages, state);

                    _logger?.LogWarning("[ContinuationOrchestrator] Token budget exhausted at iteration {Iteration}. Total tokens so far: {TotalTokens:N0}. RunId: {RunId}",
                        iteration, state.TotalTokensUsedAcrossIterations, runContext?.RunId);
                }
            }

            _logger?.LogError("[ContinuationOrchestrator] Max continuations ({MaxContinuations}) reached. RunId: {RunId}",
                _maxContinuations, runContext?.RunId);
            allResponseMessages.Add(new ChatMessage(ChatRole.Assistant,
                $"[Migration reached max continuation limit of {_maxContinuations} iterations. " +
                $"Total tokens used: {state.TotalTokensUsedAcrossIterations:N0}. " +
                "Please review partial results and re-run for remaining work.]"));

            return new AgentResponse(allResponseMessages);
        }

        private IEnumerable<ChatMessage> BuildContinuationMessages(
            IEnumerable<ChatMessage> original, ContinuationState state, int iteration)
        {
            if (iteration == 0)
                return original;

            // For continuation iterations, provide a compressed context
            var continuationPrompt =
                $"You are continuing migration work from a previous agent (iteration {iteration}).\n\n" +
                $"## Work Completed So Far\n{state.SharedContextSummary}\n\n" +
                $"## Completed Tasks ({state.CompletedTasks.Count})\n" +
                string.Join("\n", state.CompletedTasks.Select(t => $"- [{t.Status}] {t.TaskId}: {t.OutputContent[..Math.Min(200, t.OutputContent.Length)]}")) +
                $"\n\n## Pending Tasks ({state.PendingTasks.Count})\n" +
                string.Join("\n", state.PendingTasks.Select(t => $"- {t.TaskId}: {t.Description}")) +
                "\n\nContinue from where the previous agent left off. Do NOT redo completed tasks.";

            return new[] { new ChatMessage(ChatRole.User, continuationPrompt) };
        }

        private string BuildContextSummary(List<ChatMessage> messages, ContinuationState state)
        {
            // Extract the most recent assistant messages as a summary
            var recentAssistantMessages = messages
                .Where(m => m.Role == ChatRole.Assistant && !string.IsNullOrEmpty(m.Text))
                .TakeLast(3)
                .Select(m => m.Text!.Length > 500 ? m.Text[..500] + "..." : m.Text)
                .ToList();

            return string.Join("\n---\n", recentAssistantMessages);
        }
    }
}
