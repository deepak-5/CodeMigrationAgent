using System.Diagnostics;
using System.Text.Json;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using CodeMigrationAgent.Agents;
using CodeMigrationAgent.Models;
using CodeMigrationAgent.Platform;
using CodeMigrationAgent.Tools;

namespace CodeMigrationAgent.Workflows
{
    /// <summary>
    /// The GOATED Hybrid Migration Pipeline.
    /// Phase 1: Architect Agent analyzes (sequential) → produces MigrationPlan
    /// Phase 1.5: Context Enrichment — pre-populate DependencyContext via SearchUsages
    /// Phase 2: ParallelOrchestrator fans out coding tasks (parallel, Task.WhenAll)
    /// Phase 3: Reviewer Agent validates all results (sequential)
    /// Phase 4: Migration Agent applies final changes (sequential)
    ///
    /// Token continuation is handled by wrapping each agent in a ContinuationOrchestrator.
    /// OpenTelemetry Activity spans instrument every phase for full observability.
    /// </summary>
    public class HybridMigrationPipeline
    {
        private readonly IChatClient _chatClient;
        private readonly int _maxTokensPerAgent;
        private readonly int _maxParallelWorkers;
        private readonly ILogger<HybridMigrationPipeline> _logger;
        private readonly IDurableStateStore _stateStore;
        private readonly ControlPlaneService _controlPlane;
        private readonly PromptVersioningService _promptVersioning;
        private readonly GovernanceService _governanceService;
        private readonly RunSupervisor _runSupervisor;

        public HybridMigrationPipeline(
            IChatClient chatClient,
            ILogger<HybridMigrationPipeline> logger,
            IDurableStateStore stateStore,
            ControlPlaneService controlPlane,
            PromptVersioningService promptVersioning,
            GovernanceService governanceService,
            RunSupervisor runSupervisor,
            int maxTokensPerAgent = 200_000,
            int maxParallelWorkers = 8)
        {
            _chatClient = chatClient;
            _logger = logger;
            _stateStore = stateStore;
            _controlPlane = controlPlane;
            _promptVersioning = promptVersioning;
            _governanceService = governanceService;
            _runSupervisor = runSupervisor;
            _maxTokensPerAgent = maxTokensPerAgent;
            _maxParallelWorkers = maxParallelWorkers;
        }

        public async Task<AgentResponse> ExecuteAsync(
            string migrationRequest,
            string tenantId = "default",
            string? runId = null,
            int? budgetTokens = null,
            string? workspaceRoot = null,
            string? customInstructions = null,
            CancellationToken cancellationToken = default)
        {
            runId ??= Guid.NewGuid().ToString("N");
            var runBudget = budgetTokens ?? _controlPlane.ResolveRunBudget(null);
            var configVersion = _controlPlane.ResolveConfigVersion(tenantId, runId);
            await _controlPlane.EnsureTenantQuotaAsync(tenantId, runBudget, cancellationToken);

            var supervisedToken = _runSupervisor.Register(runId, cancellationToken);
            using var pipelineActivity = PipelineTelemetry.StartPhase("Pipeline.Execute", migrationRequest[..Math.Min(200, migrationRequest.Length)]);
            var allMessages = new List<ChatMessage>();
            var runContext = new MigrationRunContext(_logger, tenantId, configVersion, runBudget, runId);
            RuntimeExecutionContext.RunId = runContext.RunId;
            RuntimeExecutionContext.TenantId = tenantId;
            RuntimeExecutionContext.ConfigVersion = configVersion;
            await _stateStore.StartRunAsync(new ActiveRunInfo(runContext.RunId, tenantId, "running", "start", DateTime.UtcNow, DateTime.UtcNow, 0, runBudget), supervisedToken);
            await _stateStore.AddCheckpointAsync(
                runContext.RunId,
                "start",
                JsonSerializer.Serialize(new { Prompt = migrationRequest, tenantId, runBudget, configVersion, workspaceRoot, customInstructions }),
                supervisedToken);

            using var logScope = _logger.BeginScope(new Dictionary<string, object>
            {
                ["runId"] = runContext.RunId
            });

            // ═══════════════════════════════════════════════════
            // PHASE 1: ARCHITECT — Analyze and Decompose
            // ═══════════════════════════════════════════════════
            _logger.LogInformation("PHASE 1: ARCHITECT — Analyzing Codebase");

            MigrationPlan? plan = null;
            string planJson;
            using (var architectActivity = PipelineTelemetry.StartPhase("Phase1.Architect", "Analyze codebase and produce MigrationPlan"))
            {
                await _stateStore.UpdateRunPhaseAsync(runContext.RunId, "architect", runContext.UsedTokensApprox, "running", supervisedToken);
                var architectInstructions = await _promptVersioning.ResolveInstructionsAsync(
                    ArchitectAgentBuilder.AgentName,
                    tenantId,
                    runContext.RunId,
                    workspaceRoot,
                    customInstructions,
                    supervisedToken);
                var architectOrchestrator = new ContinuationOrchestrator(
                    _chatClient,
                    tracker => ArchitectAgentBuilder.Build(tracker, architectInstructions),
                    _maxTokensPerAgent,
                    logger: _logger);

                var architectResponse = await architectOrchestrator.RunWithContinuationAsync(
                    new[] { new ChatMessage(ChatRole.User, migrationRequest) },
                    runContext: runContext,
                    cancellationToken: supervisedToken);

                allMessages.AddRange(architectResponse.Messages);
                runContext.AddUsageFromText(architectResponse.Messages.LastOrDefault()?.Text);
                await RuntimeObservability.WriteReplayAsync(new ReplayEvent(runContext.RunId, "model_turn", ArchitectAgentBuilder.AgentName, architectResponse.Messages.LastOrDefault()?.Text ?? "", DateTime.UtcNow, tenantId), supervisedToken);

                // Parse the MigrationPlan from the architect's response
                planJson = architectResponse.Messages.LastOrDefault()?.Text ?? "{}";
                try
                {
                    plan = JsonSerializer.Deserialize<MigrationPlan>(planJson, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                    if (plan is not null)
                    {
                        var governanceErrors = _governanceService.ValidatePlanDag(plan);
                        if (governanceErrors.Count > 0)
                        {
                            throw new InvalidOperationException("Governance validation failed: " + string.Join(" | ", governanceErrors));
                        }
                    }
                    architectActivity?.SetTag("phase1.modifications_count", plan?.Modifications.Count ?? 0);
                    architectActivity?.SetTag("phase1.parallel_groups", plan?.ParallelTasks.Count ?? 0);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "[Pipeline] Failed to parse MigrationPlan. Using raw response.");
                    architectActivity?.SetTag("phase1.parse_error", ex.Message);
                }
            }

            // ═══════════════════════════════════════════════════
            // PHASE 1.5: CONTEXT ENRICHMENT — Pre-populate DependencyContext
            // ═══════════════════════════════════════════════════
            if (plan != null)
            {
                await _stateStore.UpdateRunPhaseAsync(runContext.RunId, "context-enrichment", runContext.UsedTokensApprox, "running", supervisedToken);
                using var enrichActivity = PipelineTelemetry.StartPhase("Phase1_5.ContextEnrichment", "Pre-populate DependencyContext via SearchUsages");

                _logger.LogInformation("PHASE 1.5: CONTEXT ENRICHMENT — Populating DependencyContext");

                int enriched = 0;
                var allModifications = plan.Modifications
                    .Concat(plan.ParallelTasks.SelectMany(g => g.Tasks))
                    .Where(m => string.IsNullOrWhiteSpace(m.DependencyContext))
                    .ToList();

                foreach (var mod in allModifications)
                {
                    try
                    {
                        // Extract the primary symbol/class name from the file path
                        var fileName = Path.GetFileNameWithoutExtension(mod.FilePath);
                        if (!string.IsNullOrEmpty(fileName))
                        {
                            var usages = await CodeSearchTools.SearchUsages(fileName, ".");
                            if (!string.IsNullOrWhiteSpace(usages) && usages.Length > 10)
                            {
                                mod.DependencyContext = usages.Length > 2000
                                    ? usages[..2000] + "\n... [truncated]"
                                    : usages;
                                enriched++;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogDebug(ex, "[Enrichment] Could not enrich {FilePath}", mod.FilePath);
                    }
                }

                _logger.LogInformation("[Enrichment] Pre-populated DependencyContext for {Enriched}/{Total} modifications.", enriched, allModifications.Count);
                enrichActivity?.SetTag("enrichment.total", allModifications.Count);
                enrichActivity?.SetTag("enrichment.enriched", enriched);
                await _stateStore.AddCheckpointAsync(runContext.RunId, "enriched-plan", JsonSerializer.Serialize(plan), supervisedToken);
            }

            // ═══════════════════════════════════════════════════
            // PHASE 2: PARALLEL CODERS — Fan-Out
            // ═══════════════════════════════════════════════════
            _logger.LogInformation("PHASE 2: PARALLEL CODERS — Executing Tasks");

            List<TaskResult> codingResults;
            using (var coderActivity = PipelineTelemetry.StartPhase("Phase2.ParallelCoders", "Fan out coding tasks"))
            {
                await _stateStore.UpdateRunPhaseAsync(runContext.RunId, "coder", runContext.UsedTokensApprox, "running", supervisedToken);
                if (plan != null && (plan.Modifications.Count > 0 || plan.ParallelTasks.Count > 0))
                {
                    var coderInstructions = await _promptVersioning.ResolveInstructionsAsync(
                        CoderAgentBuilder.AgentName,
                        tenantId,
                        runContext.RunId,
                        workspaceRoot,
                        customInstructions,
                        supervisedToken);
                    var parallelOrchestrator = new ParallelOrchestrator(
                        () => CoderAgentBuilder.Build(_chatClient, coderInstructions),
                        _maxParallelWorkers,
                        logger: _logger,
                        governanceService: _governanceService);

                    codingResults = await parallelOrchestrator.ExecuteParallelAsync(plan, runContext);
                }
                else
                {
                    // Fallback: run the coder sequentially with the architect's output
                    _logger.LogWarning("[Pipeline] No structured plan; running coder sequentially.");
                    var coderInstructions = await _promptVersioning.ResolveInstructionsAsync(
                        CoderAgentBuilder.AgentName,
                        tenantId,
                        runContext.RunId,
                        workspaceRoot,
                        customInstructions,
                        supervisedToken);
                    var coderOrchestrator = new ContinuationOrchestrator(
                        _chatClient,
                        tracker => CoderAgentBuilder.Build(tracker, coderInstructions),
                        _maxTokensPerAgent,
                        logger: _logger);

                    var coderResponse = await coderOrchestrator.RunWithContinuationAsync(
                        allMessages,
                        runContext: runContext,
                        cancellationToken: supervisedToken);
                    allMessages.AddRange(coderResponse.Messages);
                    runContext.AddUsageFromText(coderResponse.Messages.LastOrDefault()?.Text);
                    codingResults = new List<TaskResult>
                    {
                        new() { TaskId = "seq-001", Status = Models.TaskStatus.Completed, OutputContent = coderResponse.Messages.LastOrDefault()?.Text ?? "" }
                    };

                    runContext.Record(codingResults[0]);
                }

                coderActivity?.SetTag("phase2.task_count", codingResults.Count);
                coderActivity?.SetTag("phase2.succeeded", codingResults.Count(r => r.Status == Models.TaskStatus.Completed));
                coderActivity?.SetTag("phase2.failed", codingResults.Count(r => r.Status == Models.TaskStatus.Failed));
                await _stateStore.AddCheckpointAsync(runContext.RunId, "coder-results", JsonSerializer.Serialize(codingResults), supervisedToken);
            }

            // Summarize coding results for the reviewer
            var codingSummary = string.Join("\n\n", codingResults.Select(r =>
                $"### Task {r.TaskId} [{r.Status}]\n{r.OutputContent[..Math.Min(500, r.OutputContent.Length)]}"));

            // ═══════════════════════════════════════════════════
            // PHASE 3: REVIEWER — Validate
            // ═══════════════════════════════════════════════════
            _logger.LogInformation("PHASE 3: REVIEWER — Validating Changes");

            AgentResponse reviewResponse;
            using (var reviewActivity = PipelineTelemetry.StartPhase("Phase3.Reviewer", "Validate all code changes"))
            {
                await _stateStore.UpdateRunPhaseAsync(runContext.RunId, "reviewer", runContext.UsedTokensApprox, "running", supervisedToken);
                var reviewerInstructions = await _promptVersioning.ResolveInstructionsAsync(
                    ReviewerAgentBuilder.AgentName,
                    tenantId,
                    runContext.RunId,
                    workspaceRoot,
                    customInstructions,
                    supervisedToken);
                var reviewOrchestrator = new ContinuationOrchestrator(
                    _chatClient,
                    tracker => ReviewerAgentBuilder.Build(tracker, reviewerInstructions),
                    _maxTokensPerAgent,
                    logger: _logger);

                var reviewPrompt = $"Review the following code changes from the parallel coding phase:\n\n{codingSummary}";
                reviewResponse = await reviewOrchestrator.RunWithContinuationAsync(
                    new[] { new ChatMessage(ChatRole.User, reviewPrompt) },
                    runContext: runContext,
                    cancellationToken: supervisedToken);

                allMessages.AddRange(reviewResponse.Messages);
                runContext.AddUsageFromText(reviewResponse.Messages.LastOrDefault()?.Text);
                reviewActivity?.SetTag("phase3.review_length", reviewResponse.Messages.LastOrDefault()?.Text?.Length ?? 0);
            }

            // ═══════════════════════════════════════════════════
            // PHASE 4: MIGRATION — Apply
            // ═══════════════════════════════════════════════════
            _logger.LogInformation("PHASE 4: MIGRATION — Applying Changes");

            using (var migrationActivity = PipelineTelemetry.StartPhase("Phase4.Migration", "Apply and finalize changes"))
            {
                await _stateStore.UpdateRunPhaseAsync(runContext.RunId, "migration", runContext.UsedTokensApprox, "running", supervisedToken);
                var migrationInstructions = await _promptVersioning.ResolveInstructionsAsync(
                    MigrationAgentBuilder.AgentName,
                    tenantId,
                    runContext.RunId,
                    workspaceRoot,
                    customInstructions,
                    supervisedToken);
                var migrationOrchestrator = new ContinuationOrchestrator(
                    _chatClient,
                    tracker => MigrationAgentBuilder.Build(tracker, instructionsOverride: migrationInstructions),
                    _maxTokensPerAgent,
                    logger: _logger);

                planJson ??= "{}";
                var applyPrompt = $"Apply and finalize the following reviewed changes:\n\n" +
                    $"Architect Plan:\n{planJson[..Math.Min(1000, planJson.Length)]}\n\n" +
                    $"Review Result:\n{reviewResponse.Messages.LastOrDefault()?.Text ?? "No review output"}";

                var migrationResponse = await migrationOrchestrator.RunWithContinuationAsync(
                    new[] { new ChatMessage(ChatRole.User, applyPrompt) },
                    runContext: runContext,
                    cancellationToken: supervisedToken);

                allMessages.AddRange(migrationResponse.Messages);
                runContext.AddUsageFromText(migrationResponse.Messages.LastOrDefault()?.Text);
            }

            _logger.LogInformation("PIPELINE COMPLETE");

            pipelineActivity?.SetTag("pipeline.total_messages", allMessages.Count);
            pipelineActivity?.SetTag("pipeline.run_id", runContext.RunId);
            await _controlPlane.TrackUsageAsync(tenantId, runContext.UsedTokensApprox, supervisedToken);
            await _stateStore.CompleteRunAsync(runContext.RunId, "completed", runContext.UsedTokensApprox, null, supervisedToken);
            _runSupervisor.Complete(runContext.RunId);
            RuntimeExecutionContext.RunId = null;
            RuntimeExecutionContext.TenantId = null;
            RuntimeExecutionContext.ConfigVersion = null;
            return new AgentResponse(allMessages);
        }
    }
}

