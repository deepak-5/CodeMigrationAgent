using System.Diagnostics;

namespace CodeMigrationAgent.Workflows
{
    /// <summary>
    /// Central ActivitySource for the Code Migration Agent pipeline.
    /// Provides custom OpenTelemetry spans for each phase, parallel workers, and continuation iterations.
    /// </summary>
    public static class PipelineTelemetry
    {
        public const string SourceName = "CodeMigrationAgent.Pipeline";
        public static readonly ActivitySource Source = new(SourceName, "1.0.0");

        /// <summary>
        /// Starts a new activity (span) for a pipeline phase.
        /// </summary>
        public static Activity? StartPhase(string phaseName, string? description = null)
        {
            var activity = Source.StartActivity(phaseName, ActivityKind.Internal);
            if (activity != null && description != null)
            {
                activity.SetTag("phase.description", description);
            }
            return activity;
        }

        /// <summary>
        /// Starts an activity for a parallel worker task.
        /// </summary>
        public static Activity? StartWorker(string taskId, string filePath)
        {
            var activity = Source.StartActivity("Worker.Execute", ActivityKind.Internal);
            activity?.SetTag("worker.task_id", taskId);
            activity?.SetTag("worker.file_path", filePath);
            return activity;
        }

        /// <summary>
        /// Starts an activity for a continuation iteration.
        /// </summary>
        public static Activity? StartContinuation(int iteration, int maxTokens)
        {
            var activity = Source.StartActivity("Continuation.Iteration", ActivityKind.Internal);
            activity?.SetTag("continuation.iteration", iteration);
            activity?.SetTag("continuation.max_tokens", maxTokens);
            return activity;
        }
    }
}
