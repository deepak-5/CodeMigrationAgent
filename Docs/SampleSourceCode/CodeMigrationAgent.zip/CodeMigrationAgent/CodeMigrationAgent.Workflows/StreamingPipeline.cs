using System.Runtime.CompilerServices;

namespace CodeMigrationAgent.Workflows
{
    /// <summary>
    /// Streaming facade over HybridMigrationPipeline.
    /// Keeps orchestration logic unified across sync, queue, and streaming endpoints.
    /// </summary>
    public class StreamingPipeline
    {
        private readonly HybridMigrationPipeline _pipeline;

        public StreamingPipeline(HybridMigrationPipeline pipeline)
        {
            _pipeline = pipeline;
        }

        /// <summary>
        /// Executes the shared HybridMigrationPipeline and emits SSE-friendly events.
        /// </summary>
        public async IAsyncEnumerable<StreamEvent> ExecuteStreamingAsync(
            string prompt,
            string? tenantId = null,
            string? runId = null,
            int? budgetTokens = null,
            string? workspaceRoot = null,
            string? customInstructions = null,
            [EnumeratorCancellation] CancellationToken cancellationToken = default)
        {
            var resolvedTenantId = string.IsNullOrWhiteSpace(tenantId) ? "default" : tenantId!;
            var resolvedRunId = string.IsNullOrWhiteSpace(runId) ? Guid.NewGuid().ToString("N") : runId!;

            yield return StreamEvent.Phase("pipeline", $"Starting unified migration run {resolvedRunId}...");
            yield return StreamEvent.Progress("pipeline", "Delegating to HybridMigrationPipeline");

            var response = await _pipeline.ExecuteAsync(
                prompt,
                tenantId: resolvedTenantId,
                runId: resolvedRunId,
                budgetTokens: budgetTokens,
                workspaceRoot: workspaceRoot,
                customInstructions: customInstructions,
                cancellationToken: cancellationToken);

            foreach (var message in response.Messages)
            {
                yield return StreamEvent.AgentOutput(message.Role.Value, message.Text ?? string.Empty);
            }

            yield return StreamEvent.Phase("complete", $"Pipeline finished successfully for run {resolvedRunId}.");
        }
    }

    /// <summary>
    /// Represents a streaming event from the pipeline, designed for SSE output.
    /// </summary>
    public class StreamEvent
    {
        public string Type { get; set; } = "";
        public string Agent { get; set; } = "";
        public string Content { get; set; } = "";
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;

        public static StreamEvent Phase(string agent, string message) =>
            new() { Type = "phase", Agent = agent, Content = message };

        public static StreamEvent AgentOutput(string agent, string content) =>
            new() { Type = "output", Agent = agent, Content = content };

        public static StreamEvent Progress(string agent, string message) =>
            new() { Type = "progress", Agent = agent, Content = message };
    }
}
