using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Logging;

namespace CodeMigrationAgent.Workflows
{
    /// <summary>
    /// BMAD-inspired Iterative Refinement Engine.
    /// Implements multi-pass output improvement between pipeline phases.
    ///
    /// Inspired by BMAD's Advanced Elicitation workflow — each pass applies a different
    /// refinement "method" (security scan, edge-case analysis, performance review, etc.)
    /// and accumulates improvements iteratively.
    ///
    /// BMAD pattern: "Each method application builds upon previous enhancements."
    /// </summary>
    public class IterativeRefinementEngine
    {
        private readonly IChatClient _chatClient;
        private readonly ILogger<IterativeRefinementEngine>? _logger;

        /// <summary>
        /// Built-in refinement methods — inspired by BMAD's advanced-elicitation-methods.csv.
        /// Each method applies a different analytical lens to improve agent output.
        /// </summary>
        public static readonly IReadOnlyList<RefinementMethod> DefaultMethods = new List<RefinementMethod>
        {
            new()
            {
                Name = "Edge Case Analysis",
                Category = "risk",
                Description = "Identify edge cases and boundary conditions not addressed in the current output. " +
                             "Check for: null handling, empty collections, max/min values, unicode, concurrent access.",
                Prompt = "Analyze the following output for MISSED EDGE CASES. For each finding, describe the edge case, " +
                        "why it matters, and suggest a specific fix:\n\n{content}"
            },
            new()
            {
                Name = "Security Hardening",
                Category = "security",
                Description = "Review for security vulnerabilities: input validation, output encoding, " +
                             "secret exposure, injection vectors, authentication/authorization gaps.",
                Prompt = "Perform a SECURITY REVIEW of the following output. Look for: injection risks, " +
                        "secret exposure, missing validation, auth gaps, and data leakage:\n\n{content}"
            },
            new()
            {
                Name = "Performance Optimization",
                Category = "performance",
                Description = "Identify performance bottlenecks: O(n²) algorithms, unnecessary allocations, " +
                             "missing caching opportunities, N+1 query patterns, large memory consumption.",
                Prompt = "Review the following for PERFORMANCE ISSUES. Identify bottlenecks, unnecessary " +
                        "allocations, missing caching, and suggest optimizations:\n\n{content}"
            },
            new()
            {
                Name = "Completeness Audit",
                Category = "structural",
                Description = "Verify nothing is missing: all requirements addressed, all error paths handled, " +
                             "all contracts fulfilled, all stated goals achieved.",
                Prompt = "Audit the following for COMPLETENESS. What requirements are unaddressed? " +
                        "What error paths are unhandled? What's stated but not implemented?\n\n{content}"
            },
            new()
            {
                Name = "Simplification Pass",
                Category = "structural",
                Description = "Find opportunities to simplify: over-engineered solutions, unnecessary abstractions, " +
                             "dead code, duplicated logic that could be consolidated.",
                Prompt = "Review the following for SIMPLIFICATION opportunities. Find over-engineering, " +
                        "unnecessary abstractions, dead code, and logic that can be consolidated:\n\n{content}"
            }
        };

        public IterativeRefinementEngine(IChatClient chatClient, ILogger<IterativeRefinementEngine>? logger = null)
        {
            _chatClient = chatClient;
            _logger = logger;
        }

        /// <summary>
        /// Runs iterative refinement passes on agent output.
        /// Each pass applies a different method and accumulates improvements.
        ///
        /// BMAD pattern: "Content preservation: Track all enhancements made during elicitation."
        /// </summary>
        /// <param name="originalContent">The agent output to refine.</param>
        /// <param name="numberOfPasses">How many refinement passes to run (1-5 recommended).</param>
        /// <param name="methods">Specific methods to use. If null, selects from defaults based on content analysis.</param>
        /// <param name="cancellationToken">Cancellation token.</param>
        /// <returns>Refined content with all improvements applied.</returns>
        public async Task<RefinementResult> RefineAsync(
            string originalContent,
            int numberOfPasses = 2,
            IList<RefinementMethod>? methods = null,
            CancellationToken cancellationToken = default)
        {
            var selectedMethods = methods?.ToList() ?? SelectMethods(originalContent, numberOfPasses);
            var result = new RefinementResult
            {
                OriginalContent = originalContent,
                StartedAt = DateTime.UtcNow
            };

            var currentContent = originalContent;

            _logger?.LogInformation("🔄 Starting iterative refinement — {Passes} passes with methods: {Methods}",
                selectedMethods.Count,
                string.Join(", ", selectedMethods.Select(m => m.Name)));

            for (int i = 0; i < selectedMethods.Count; i++)
            {
                cancellationToken.ThrowIfCancellationRequested();

                var method = selectedMethods[i];
                _logger?.LogInformation("  Pass {N}/{Total}: {Method}", i + 1, selectedMethods.Count, method.Name);

                var prompt = method.Prompt.Replace("{content}", currentContent);

                var refinementPrompt = $"You are performing a '{method.Name}' refinement pass.\n\n" +
                    $"Description: {method.Description}\n\n" +
                    $"IMPORTANT: Output the IMPROVED version of the content, incorporating your analysis. " +
                    $"If you find no improvements needed, output the content unchanged with a note.\n\n" +
                    prompt;

                try
                {
                    var response = await _chatClient.GetResponseAsync(
                        new[] { new ChatMessage(ChatRole.User, refinementPrompt) },
                        cancellationToken: cancellationToken);

                    var refinedText = response.Messages.LastOrDefault()?.Text ?? currentContent;

                    result.Passes.Add(new RefinementPass
                    {
                        PassNumber = i + 1,
                        MethodName = method.Name,
                        Category = method.Category,
                        Improvements = refinedText,
                        ContentLengthBefore = currentContent.Length,
                        ContentLengthAfter = refinedText.Length
                    });

                    currentContent = refinedText;
                    _logger?.LogInformation("    ✅ Pass {N} complete — {Before} → {After} chars",
                        i + 1, result.Passes[i].ContentLengthBefore, result.Passes[i].ContentLengthAfter);
                }
                catch (Exception ex)
                {
                    _logger?.LogWarning(ex, "    ⚠️ Pass {N} failed — continuing with previous content", i + 1);
                    result.Passes.Add(new RefinementPass
                    {
                        PassNumber = i + 1,
                        MethodName = method.Name,
                        Category = method.Category,
                        Error = ex.Message
                    });
                }
            }

            result.RefinedContent = currentContent;
            result.CompletedAt = DateTime.UtcNow;

            _logger?.LogInformation("🔄 Refinement complete — {Passes} passes in {Duration}ms",
                result.Passes.Count, result.Duration.TotalMilliseconds);

            return result;
        }

        /// <summary>
        /// Intelligently selects refinement methods based on content analysis.
        /// BMAD pattern: "Balance approach: Include mix of foundational and specialized techniques."
        /// </summary>
        private List<RefinementMethod> SelectMethods(string content, int count)
        {
            var selected = new List<RefinementMethod>();

            // Always include completeness audit and edge case analysis
            selected.Add(DefaultMethods.First(m => m.Name == "Completeness Audit"));
            selected.Add(DefaultMethods.First(m => m.Name == "Edge Case Analysis"));

            // Add security if code-related
            if (content.Contains("class ") || content.Contains("function ") || content.Contains("def ") ||
                content.Contains("public ") || content.Contains("private "))
            {
                selected.Add(DefaultMethods.First(m => m.Name == "Security Hardening"));
            }

            // Fill remaining with performance and simplification
            if (selected.Count < count)
                selected.Add(DefaultMethods.First(m => m.Name == "Performance Optimization"));
            if (selected.Count < count)
                selected.Add(DefaultMethods.First(m => m.Name == "Simplification Pass"));

            return selected.Take(count).ToList();
        }
    }

    /// <summary>A refinement method — analytical lens to apply to agent output.</summary>
    public class RefinementMethod
    {
        public string Name { get; set; } = "";
        public string Category { get; set; } = "";
        public string Description { get; set; } = "";
        public string Prompt { get; set; } = "";
    }

    /// <summary>Result of the iterative refinement process.</summary>
    public class RefinementResult
    {
        public string OriginalContent { get; set; } = "";
        public string RefinedContent { get; set; } = "";
        public List<RefinementPass> Passes { get; set; } = new();
        public DateTime StartedAt { get; set; }
        public DateTime CompletedAt { get; set; }
        public TimeSpan Duration => CompletedAt - StartedAt;
    }

    /// <summary>Result of a single refinement pass.</summary>
    public class RefinementPass
    {
        public int PassNumber { get; set; }
        public string MethodName { get; set; } = "";
        public string Category { get; set; } = "";
        public string Improvements { get; set; } = "";
        public string? Error { get; set; }
        public int ContentLengthBefore { get; set; }
        public int ContentLengthAfter { get; set; }
    }
}
