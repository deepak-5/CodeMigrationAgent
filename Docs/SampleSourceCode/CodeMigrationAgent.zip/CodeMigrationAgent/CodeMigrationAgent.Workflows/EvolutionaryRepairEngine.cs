using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Logging;
using CodeMigrationAgent.Models;
using CodeMigrationAgent.Middlewares;
using CodeMigrationAgent.Agents;

namespace CodeMigrationAgent.Workflows
{
    /// <summary>
    /// Evolutionary Repair Engine — Auto-Healing Branches for Quality Gates.
    /// </summary>
    public class EvolutionaryRepairEngine
    {
        private readonly ILogger<EvolutionaryRepairEngine>? _logger;
        private readonly int _maxRetries;

        public EvolutionaryRepairEngine(int maxRetries = 3, ILogger<EvolutionaryRepairEngine>? logger = null)
        {
            _maxRetries = maxRetries;
            _logger = logger;
        }

        /// <summary>
        /// Wraps an agent execution with Auto-Healing logic.
        /// If the initial agent's output fails the Quality Gate, the engine spawns "Felix the Fixer" to resolve it.
        /// </summary>
        public async Task<string> RunWithAutoHealingAsync(
            IChatClient chatClient,
            AIAgent primaryAgent,
            IEnumerable<ChatMessage> messages,
            QualityGateConfig gateConfig,
            string phaseName,
            CancellationToken cancellationToken = default)
        {
            _logger?.LogInformation("🚀 [AutoHealing] Running Primary Agent for phase '{Phase}'...", phaseName);
            
            // 1. Initial Prompt execution
            var response = await primaryAgent.RunAsync(messages, cancellationToken: cancellationToken);
            var currentOutput = response.Messages.LastOrDefault()?.Text ?? string.Empty;

            // 2. Evaluate with Quality Gate
            var gateResult = QualityGateMiddleware.Evaluate(currentOutput, gateConfig, phaseName);

            if (gateResult.Passed)
            {
                _logger?.LogInformation("✅ [AutoHealing] Primary output passed Quality Gate on the first try.");
                return currentOutput;
            }

            // 3. Fall into the Evolutionary Repair cycle
            _logger?.LogWarning("🛑 [AutoHealing] Quality Gate FAILED. Invoking Evolutionary Repair (Fixer Agent).");

            int attempt = 0;
            while (attempt < _maxRetries && !gateResult.Passed)
            {
                attempt++;
                cancellationToken.ThrowIfCancellationRequested();

                _logger?.LogInformation("🛠️ [AutoHealing] Repair Attempt {Attempt}/{MaxRetries}...", attempt, _maxRetries);

                var fixerAgent = FixerAgentBuilder.Build(chatClient);

                var errorDescriptions = string.Join("\n", gateResult.Findings.Select(f => $"- [{f.Severity}] {f.Category}: {f.Description}"));
                
                var repairPrompt = $"The previous output failed the Quality Gate with {gateResult.Findings.Count} findings:\n" +
                                   $"{errorDescriptions}\n\n" +
                                   $"ORIGINAL FLAWED OUTPUT:\n" +
                                   $"====================================\n{currentOutput}\n====================================\n\n" +
                                   $"Apply a targeted patch to fix ONLY these exact findings and output the fully corrected result.";

                try
                {
                    var repairMessages = new[] { new ChatMessage(ChatRole.User, repairPrompt) };
                    var repairResponse = await fixerAgent.RunAsync(repairMessages, cancellationToken: cancellationToken);
                    var repairedOutput = repairResponse.Messages.LastOrDefault()?.Text ?? string.Empty;

                    // Re-Evaluate
                    gateResult = QualityGateMiddleware.Evaluate(repairedOutput, gateConfig, phaseName);

                    if (gateResult.Passed)
                    {
                        _logger?.LogInformation("🎉 [AutoHealing] SUCCESS! Fixer Agent resolved all gate findings on attempt {Attempt}.", attempt);
                        return repairedOutput;
                    }

                    _logger?.LogWarning("❌ [AutoHealing] Attempt {Attempt} failed to resolve all issues. Retrying...", attempt);
                    currentOutput = repairedOutput; // Feed the partially repaired output into the next cycle
                }
                catch (Exception ex)
                {
                    _logger?.LogError(ex, "⚠️ [AutoHealing] Fixer Agent execution failed during attempt {Attempt}.", attempt);
                }
            }

            _logger?.LogCritical("💥 [AutoHealing] MAX RETRIES ({MaxRetries}) EXHAUSTED. Auto-healing failed for phase '{Phase}'.", _maxRetries, phaseName);
            
            // Return the halting error if we totally exhaust max retries
            return $"[EVOLUTIONARY REPAIR HALTED]\n" +
                   $"Failed to resolve Quality Gate findings after {_maxRetries} attempts.\n" +
                   $"Final unsolved findings:\n" +
                   $"{string.Join("\n", gateResult.Findings.Select(f => $"- {f.Description}"))}";
        }
    }
}
