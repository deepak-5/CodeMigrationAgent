using System.Text.Json;
using Microsoft.Extensions.Logging;

namespace CodeMigrationAgent.Workflows
{
    /// <summary>
    /// BMAD-inspired Checkpoint Manager — save pipeline state after every phase.
    /// Inspired by BMAD's template-output pattern: "Save content after EVERY template-output tag."
    ///
    /// Enables resuming long-running migrations from the last successful checkpoint
    /// instead of restarting from scratch after failures or interruptions.
    /// </summary>
    public class CheckpointManager
    {
        private readonly string _checkpointDirectory;
        private readonly ILogger<CheckpointManager>? _logger;
        private static readonly JsonSerializerOptions _jsonOptions = new()
        {
            WriteIndented = true,
            PropertyNameCaseInsensitive = true
        };

        public CheckpointManager(string checkpointDirectory, ILogger<CheckpointManager>? logger = null)
        {
            _checkpointDirectory = checkpointDirectory;
            _logger = logger;
            Directory.CreateDirectory(_checkpointDirectory);
        }

        /// <summary>
        /// Saves a checkpoint to disk. Called after every pipeline phase completion.
        /// BMAD pattern: "Save to file after EVERY template-output tag."
        /// </summary>
        public async Task SaveCheckpointAsync(MigrationCheckpoint checkpoint)
        {
            var filePath = GetCheckpointPath(checkpoint.CheckpointId);
            var json = JsonSerializer.Serialize(checkpoint, _jsonOptions);
            await File.WriteAllTextAsync(filePath, json);
            _logger?.LogInformation("💾 Checkpoint saved: {Id} at phase '{Phase}'",
                checkpoint.CheckpointId, checkpoint.Phase);
        }

        /// <summary>
        /// Loads a checkpoint from disk for resume support.
        /// </summary>
        public async Task<MigrationCheckpoint?> LoadCheckpointAsync(string checkpointId)
        {
            var filePath = GetCheckpointPath(checkpointId);
            if (!File.Exists(filePath))
            {
                _logger?.LogWarning("⚠️ Checkpoint not found: {Id}", checkpointId);
                return null;
            }

            var json = await File.ReadAllTextAsync(filePath);
            var checkpoint = JsonSerializer.Deserialize<MigrationCheckpoint>(json, _jsonOptions);
            _logger?.LogInformation("📂 Checkpoint loaded: {Id} from phase '{Phase}'",
                checkpointId, checkpoint?.Phase);
            return checkpoint;
        }

        /// <summary>
        /// Lists all available checkpoints, ordered by completion time (newest first).
        /// </summary>
        public IReadOnlyList<MigrationCheckpoint> ListCheckpoints()
        {
            if (!Directory.Exists(_checkpointDirectory))
                return Array.Empty<MigrationCheckpoint>();

            var checkpoints = new List<MigrationCheckpoint>();
            foreach (var file in Directory.GetFiles(_checkpointDirectory, "*.json"))
            {
                try
                {
                    var json = File.ReadAllText(file);
                    var checkpoint = JsonSerializer.Deserialize<MigrationCheckpoint>(json, _jsonOptions);
                    if (checkpoint != null)
                        checkpoints.Add(checkpoint);
                }
                catch (Exception ex)
                {
                    _logger?.LogWarning(ex, "Failed to parse checkpoint file: {File}", file);
                }
            }

            return checkpoints.OrderByDescending(c => c.CompletedAt).ToList().AsReadOnly();
        }

        /// <summary>
        /// Finds the latest checkpoint for a given workflow run.
        /// </summary>
        public MigrationCheckpoint? GetLatestCheckpoint(string workflowRunId)
        {
            return ListCheckpoints()
                .Where(c => c.CheckpointId.StartsWith(workflowRunId))
                .OrderByDescending(c => c.CompletedAt)
                .FirstOrDefault();
        }

        /// <summary>
        /// Deletes all checkpoints for a completed workflow run.
        /// </summary>
        public void CleanupCheckpoints(string workflowRunId)
        {
            var files = Directory.GetFiles(_checkpointDirectory, $"{workflowRunId}*.json");
            foreach (var file in files)
            {
                File.Delete(file);
            }
            _logger?.LogInformation("🧹 Cleaned up {Count} checkpoints for run '{Id}'",
                files.Length, workflowRunId);
        }

        private string GetCheckpointPath(string checkpointId) =>
            Path.Combine(_checkpointDirectory, $"{SanitizeFileName(checkpointId)}.json");

        private static string SanitizeFileName(string name) =>
            string.Join("_", name.Split(Path.GetInvalidFileNameChars()));
    }

    /// <summary>
    /// Represents a saved pipeline checkpoint — snapshot of state at a specific phase boundary.
    /// </summary>
    public class MigrationCheckpoint
    {
        /// <summary>Unique identifier for this checkpoint (e.g., "run-001-architect").</summary>
        public string CheckpointId { get; set; } = "";

        /// <summary>The pipeline phase that was completed (e.g., "architect", "coder", "reviewer").</summary>
        public string Phase { get; set; } = "";

        /// <summary>When this checkpoint was saved.</summary>
        public DateTime CompletedAt { get; set; } = DateTime.UtcNow;

        /// <summary>Serialized pipeline state data for resume.</summary>
        public string Data { get; set; } = "";

        /// <summary>Additional metadata about the checkpoint.</summary>
        public Dictionary<string, string> Metadata { get; set; } = new();
    }
}
