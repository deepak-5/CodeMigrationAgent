using System.Collections.Concurrent;
using System.Diagnostics;
using Microsoft.Extensions.Logging;
using CodeMigrationAgent.Models;

namespace CodeMigrationAgent.Models
{
    /// <summary>
    /// Per-request context for a migration run.
    /// Provides correlation, structured task tracking, and a logger.
    /// </summary>
    public sealed class MigrationRunContext
    {
        public string RunId { get; }
        public string TenantId { get; }
        public string ConfigVersion { get; }
        public int BudgetTokens { get; }
        public int UsedTokensApprox { get; private set; }

        public ILogger Logger { get; }

        /// <summary>
        /// Tracks task results by TaskId across the run (including continuations).
        /// </summary>
        public ConcurrentDictionary<string, TaskResult> TaskResults { get; } = new();

        public MigrationRunContext(ILogger logger, string tenantId = "default", string configVersion = "stable-v1", int budgetTokens = 200_000, string? runId = null)
        {
            Logger = logger;
            RunId = runId ?? Activity.Current?.TraceId.ToString() ?? Guid.NewGuid().ToString("N");
            TenantId = tenantId;
            ConfigVersion = configVersion;
            BudgetTokens = budgetTokens;
        }

        public void Record(TaskResult result)
        {
            if (string.IsNullOrWhiteSpace(result.TaskId))
                return;

            TaskResults[result.TaskId] = result;
            AddUsageFromText(result.OutputContent);
        }

        public void AddUsageFromText(string? text)
        {
            if (string.IsNullOrEmpty(text))
            {
                return;
            }

            UsedTokensApprox += Math.Max(1, text.Length / 4);
        }
    }
}
