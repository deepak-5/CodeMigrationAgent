namespace CodeMigrationAgent.Models
{
    /// <summary>
    /// Tracks token usage for a single agent run.
    /// When IsExhausted is true, the orchestrator triggers a continuation hand-off.
    /// </summary>
    public class AgentTokenBudget
    {
        public int MaxTokens { get; set; } = 200_000;
        public int UsedTokens { get; private set; } = 0;
        public int RemainingTokens => MaxTokens - UsedTokens;
        public bool IsExhausted => UsedTokens >= (int)(MaxTokens * 0.90); // Trigger at 90% to leave room for continuation summary
        public double UtilizationPercent => MaxTokens > 0 ? (double)UsedTokens / MaxTokens * 100 : 0;

        private readonly object _lock = new();

        public void AddTokens(int count)
        {
            lock (_lock)
            {
                UsedTokens += count;
            }
        }

        /// <summary>
        /// Replaces a previous char-based estimate with the real token count from Usage metadata.
        /// </summary>
        public void CorrectInputTokens(int previousEstimate, int realCount)
        {
            lock (_lock)
            {
                UsedTokens = UsedTokens - previousEstimate + realCount;
                if (UsedTokens < 0) UsedTokens = 0;
            }
        }

        public void Reset()
        {
            lock (_lock)
            {
                UsedTokens = 0;
            }
        }

        public override string ToString() =>
            $"Tokens: {UsedTokens:N0}/{MaxTokens:N0} ({UtilizationPercent:F1}%) | Exhausted: {IsExhausted}";
    }
}
