namespace CodeMigrationAgent.Models
{
    /// <summary>
    /// The result returned by a parallel worker agent after completing its task.
    /// </summary>
    public class TaskResult
    {
        public string TaskId { get; set; } = string.Empty;
        public TaskStatus Status { get; set; } = TaskStatus.Pending;
        public string OutputContent { get; set; } = string.Empty;
        public List<string> Diagnostics { get; set; } = new();
        public int TokensUsed { get; set; } = 0;
        public TimeSpan Duration { get; set; } = TimeSpan.Zero;
        public string AgentName { get; set; } = string.Empty;
        public string? ErrorMessage { get; set; }
    }

    public enum TaskStatus
    {
        Pending,
        InProgress,
        Completed,
        Failed,
        ContinuationRequired
    }
}
