namespace CodeMigrationAgent.Models
{
    /// <summary>
    /// Defines an agent's persona — their identity, expertise, communication style, and operating principles.
    /// Inspired by BMAD-METHOD's persona-driven agent architecture where each agent has a
    /// distinct personality, backstory, and behavioral mandates that drive superior output quality.
    /// </summary>
    public record AgentPersona
    {
        /// <summary>Agent's given name (e.g., "Winston" the Architect).</summary>
        public required string Name { get; init; }

        /// <summary>Professional title (e.g., "System Architect + Technical Design Leader").</summary>
        public required string Title { get; init; }

        /// <summary>Visual icon for logs and UI (e.g., "🏗️").</summary>
        public required string Icon { get; init; }

        /// <summary>The persona role definition — what hat this agent wears.</summary>
        public required string Role { get; init; }

        /// <summary>
        /// Deep background and expertise description.
        /// This shapes how the agent reasons and what knowledge it draws upon.
        /// </summary>
        public required string Identity { get; init; }

        /// <summary>
        /// How the agent communicates — tone, style, formatting preferences.
        /// BMAD example: "Ultra-succinct. Speaks in file paths and AC IDs — every statement citable."
        /// </summary>
        public required string CommunicationStyle { get; init; }

        /// <summary>
        /// Core operating principles the agent MUST follow at all times.
        /// These are injected into the system prompt as top-level behavioral constraints.
        /// </summary>
        public required string[] Principles { get; init; }

        /// <summary>
        /// Critical actions the agent MUST perform — non-negotiable behavioral mandates.
        /// Inspired by BMAD's dev agent: "READ the entire story file BEFORE any implementation",
        /// "NEVER lie about tests being written or passing".
        /// </summary>
        public string[] CriticalActions { get; init; } = Array.Empty<string>();

        /// <summary>
        /// Capabilities this agent is known for — used for routing and delegation.
        /// </summary>
        public string[] Capabilities { get; init; } = Array.Empty<string>();

        /// <summary>
        /// Generates a rich system prompt incorporating the full persona definition.
        /// This is what makes BMAD agents behave like senior specialists, not generic bots.
        /// </summary>
        public string ToSystemPrompt(string baseInstructions)
        {
            var sb = new System.Text.StringBuilder();

            sb.AppendLine($"# {Icon} {Name} — {Title}");
            sb.AppendLine();
            sb.AppendLine($"**Role:** {Role}");
            sb.AppendLine($"**Identity:** {Identity}");
            sb.AppendLine($"**Communication Style:** {CommunicationStyle}");
            sb.AppendLine();

            if (Principles.Length > 0)
            {
                sb.AppendLine("## Core Principles (ALWAYS follow)");
                foreach (var p in Principles)
                    sb.AppendLine($"- {p}");
                sb.AppendLine();
            }

            if (CriticalActions.Length > 0)
            {
                sb.AppendLine("## ⚠️ CRITICAL ACTIONS (NON-NEGOTIABLE)");
                foreach (var ca in CriticalActions)
                    sb.AppendLine($"- **{ca}**");
                sb.AppendLine();
            }

            sb.AppendLine("## Mission & Instructions");
            sb.AppendLine(baseInstructions);

            return sb.ToString();
        }
    }
}
