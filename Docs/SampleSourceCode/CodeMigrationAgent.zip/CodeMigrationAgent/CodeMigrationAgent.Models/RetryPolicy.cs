namespace CodeMigrationAgent.Models
{
    /// <summary>
    /// Configures retry behavior with exponential backoff for parallel worker tasks.
    /// </summary>
    public class RetryPolicy
    {
        public int MaxRetries { get; set; } = 3;
        public TimeSpan InitialDelay { get; set; } = TimeSpan.FromSeconds(1);
        public double BackoffMultiplier { get; set; } = 2.0;
        public TimeSpan MaxDelay { get; set; } = TimeSpan.FromSeconds(30);

        /// <summary>
        /// Computes the delay for a given retry attempt using exponential backoff.
        /// </summary>
        public TimeSpan GetDelay(int attempt)
        {
            var delay = TimeSpan.FromMilliseconds(
                InitialDelay.TotalMilliseconds * Math.Pow(BackoffMultiplier, attempt));
            return delay > MaxDelay ? MaxDelay : delay;
        }
    }
}
