namespace CodeMigrationAgent.Models;

public sealed record ReplayEvent(
    string RunId,
    string EventType,
    string Agent,
    string Payload,
    DateTime TimestampUtc,
    string? TenantId = null);

public interface IReplayWriter
{
    Task WriteAsync(ReplayEvent replayEvent, CancellationToken cancellationToken = default);
}

public static class RuntimeObservability
{
    public static IReplayWriter? ReplayWriter { get; set; }

    public static Task WriteReplayAsync(ReplayEvent replayEvent, CancellationToken cancellationToken = default)
    {
        if (ReplayWriter is null)
        {
            return Task.CompletedTask;
        }

        return ReplayWriter.WriteAsync(replayEvent, cancellationToken);
    }
}
