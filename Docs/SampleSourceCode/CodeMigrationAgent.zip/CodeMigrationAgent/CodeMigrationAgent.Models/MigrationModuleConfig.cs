namespace CodeMigrationAgent.Models
{
    /// <summary>
    /// Per-project migration configuration — inspired by BMAD's module.yaml concept.
    /// Externalizes all project-specific settings so the same agent framework
    /// can be configured differently for each migration project.
    /// </summary>
    public class MigrationModuleConfig
    {
        /// <summary>Project name for identification and logging.</summary>
        public string ProjectName { get; set; } = "Unnamed Project";

        /// <summary>Source framework being migrated FROM (e.g., ".NET Framework 4.8").</summary>
        public string SourceFramework { get; set; } = "";

        /// <summary>Target framework being migrated TO (e.g., ".NET 10").</summary>
        public string TargetFramework { get; set; } = "";

        /// <summary>Where output artifacts and reports are saved.</summary>
        public string OutputFolder { get; set; } = "_migration-output";

        /// <summary>Default execution mode for this project.</summary>
        public ExecutionMode DefaultMode { get; set; } = ExecutionMode.Normal;

        /// <summary>
        /// Quality gate definitions per pipeline phase.
        /// Keys are phase names (e.g., "architect", "coder", "reviewer").
        /// </summary>
        public Dictionary<string, QualityGateConfig> QualityGates { get; set; } = new();

        /// <summary>
        /// Context discovery paths — maps logical names to file patterns.
        /// Used by SmartContextDiscovery to load relevant project context.
        /// </summary>
        public Dictionary<string, string> ContextPaths { get; set; } = new();

        /// <summary>Max tokens per agent invocation before continuation kicks in.</summary>
        public int MaxTokensPerAgent { get; set; } = 200_000;

        /// <summary>Max parallel coder workers for concurrent file processing.</summary>
        public int MaxParallelWorkers { get; set; } = 8;

        /// <summary>Number of iterative refinement passes to run (0 = disabled).</summary>
        public int RefinementPasses { get; set; } = 0;

        /// <summary>Path to checkpoint storage directory.</summary>
        public string CheckpointDirectory { get; set; } = "_migration-checkpoints";

        /// <summary>Whether to enable adversarial review pass after the normal review.</summary>
        public bool EnableAdversarialReview { get; set; } = true;
    }

    /// <summary>
    /// Quality gate configuration for a specific pipeline phase.
    /// BMAD pattern: halt-conditions that stop execution on failure.
    /// </summary>
    public class QualityGateConfig
    {
        /// <summary>Whether this gate is enabled.</summary>
        public bool Enabled { get; set; } = true;

        /// <summary>Minimum severity to trigger a halt (Warning, Error, Critical).</summary>
        public HaltSeverity MinimumSeverity { get; set; } = HaltSeverity.Error;

        /// <summary>Maximum allowed issues before halting.</summary>
        public int MaxAllowedIssues { get; set; } = 0;

        /// <summary>Whether build must pass at this gate.</summary>
        public bool RequireBuildPass { get; set; } = true;

        /// <summary>Custom halt conditions specific to this phase.</summary>
        public List<string> CustomHaltConditions { get; set; } = new();
    }
}
