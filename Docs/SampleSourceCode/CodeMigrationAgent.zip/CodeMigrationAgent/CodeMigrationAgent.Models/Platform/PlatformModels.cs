namespace CodeMigrationAgent.Platform;

public sealed record ActiveRunInfo(
    string RunId,
    string TenantId,
    string Status,
    string Phase,
    DateTime StartedAtUtc,
    DateTime? LastUpdatedAtUtc,
    int UsedTokens,
    int BudgetTokens);

public sealed record RunReplayRow(
    long Id,
    string RunId,
    DateTime TimestampUtc,
    string EventType,
    string Agent,
    string Payload,
    string TenantId);

public sealed record QueueJob(
    string JobId,
    string RunId,
    string TenantId,
    string Prompt,
    string? WorkspaceRoot,
    string? CustomInstructions,
    int BudgetTokens,
    string Status,
    DateTime EnqueuedAtUtc,
    DateTime? StartedAtUtc,
    DateTime? FinishedAtUtc,
    string? WorkerId,
    string? Error);

public sealed class PolicyOverride
{
    public string Key { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
    public string UpdatedBy { get; set; } = "system";
    public string Reason { get; set; } = string.Empty;
    public DateTime UpdatedAtUtc { get; set; } = DateTime.UtcNow;
}

public sealed class PromptVersionRecord
{
    public string AgentName { get; set; } = string.Empty;
    public string Version { get; set; } = "v1";
    public string Instructions { get; set; } = string.Empty;
}
