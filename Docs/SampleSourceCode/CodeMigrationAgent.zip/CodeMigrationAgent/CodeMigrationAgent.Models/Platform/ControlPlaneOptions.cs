namespace CodeMigrationAgent.Platform;

public sealed class ControlPlaneOptions
{
    public int DefaultPerRunTokenBudget { get; set; } = 150_000;
    public int DefaultTenantDailyTokenQuota { get; set; } = 1_000_000;
    public Dictionary<string, int> TenantDailyTokenQuota { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public int CanaryPercent { get; set; } = 0;
    public string StableConfigVersion { get; set; } = "stable-v1";
    public string CanaryConfigVersion { get; set; } = "canary-v1";
}
