using System.Security.Cryptography;
using System.Text;

namespace CodeMigrationAgent.Platform;

public sealed class ControlPlaneService
{
    private readonly IDurableStateStore _store;
    private readonly ControlPlaneOptions _options;

    public ControlPlaneService(IDurableStateStore store, ControlPlaneOptions options)
    {
        _store = store;
        _options = options;
    }

    public async Task EnsureTenantQuotaAsync(string tenantId, int expectedRunBudget, CancellationToken cancellationToken = default)
    {
        var dailyQuota = _options.TenantDailyTokenQuota.TryGetValue(tenantId, out var q)
            ? q
            : _options.DefaultTenantDailyTokenQuota;

        var used = await _store.GetTenantUsageAsync(tenantId, DateOnly.FromDateTime(DateTime.UtcNow), cancellationToken);
        if (used + expectedRunBudget > dailyQuota)
        {
            throw new InvalidOperationException(
                $"Tenant quota exceeded for '{tenantId}'. Used={used}, Requested={expectedRunBudget}, Quota={dailyQuota}.");
        }
    }

    public int ResolveRunBudget(string? overrideBudgetRaw)
    {
        if (!string.IsNullOrWhiteSpace(overrideBudgetRaw) && int.TryParse(overrideBudgetRaw, out var parsed) && parsed > 0)
        {
            return parsed;
        }
        return _options.DefaultPerRunTokenBudget;
    }

    public string ResolveConfigVersion(string tenantId, string runId)
    {
        var canaryPercent = Math.Clamp(_options.CanaryPercent, 0, 100);
        if (canaryPercent == 0)
        {
            return _options.StableConfigVersion;
        }

        var hashBytes = SHA256.HashData(Encoding.UTF8.GetBytes($"{tenantId}:{runId}"));
        var bucket = hashBytes[0] % 100;
        return bucket < canaryPercent ? _options.CanaryConfigVersion : _options.StableConfigVersion;
    }

    public Task TrackUsageAsync(string tenantId, int usedTokens, CancellationToken cancellationToken = default)
    {
        return _store.AddTenantUsageAsync(tenantId, DateOnly.FromDateTime(DateTime.UtcNow), usedTokens, cancellationToken);
    }
}
