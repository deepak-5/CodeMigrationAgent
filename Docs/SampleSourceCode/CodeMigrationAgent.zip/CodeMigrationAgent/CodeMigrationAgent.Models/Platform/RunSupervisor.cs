using System.Collections.Concurrent;

namespace CodeMigrationAgent.Platform;

public sealed class RunSupervisor
{
    private readonly ConcurrentDictionary<string, CancellationTokenSource> _ctsByRunId = new();

    public CancellationToken Register(string runId, CancellationToken outerToken)
    {
        var cts = CancellationTokenSource.CreateLinkedTokenSource(outerToken);
        _ctsByRunId[runId] = cts;
        return cts.Token;
    }

    public bool TryTerminate(string runId)
    {
        if (_ctsByRunId.TryRemove(runId, out var cts))
        {
            cts.Cancel();
            cts.Dispose();
            return true;
        }

        return false;
    }

    public void Complete(string runId)
    {
        if (_ctsByRunId.TryRemove(runId, out var cts))
        {
            cts.Dispose();
        }
    }
}
