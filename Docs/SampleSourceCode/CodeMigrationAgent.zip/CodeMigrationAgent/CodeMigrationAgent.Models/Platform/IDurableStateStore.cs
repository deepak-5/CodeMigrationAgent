using CodeMigrationAgent.Models;

namespace CodeMigrationAgent.Platform;

public interface IDurableStateStore : IReplayWriter
{
    Task InitializeAsync(CancellationToken cancellationToken = default);

    Task UpsertSessionAsync(string sessionId, string description, IReadOnlyList<ChatHistoryRow> messages, CancellationToken cancellationToken = default);
    Task<(string Description, List<ChatHistoryRow> Messages)?> GetSessionAsync(string sessionId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<(string SessionId, string Description, DateTime CreatedAtUtc, int MessageCount)>> ListSessionsAsync(CancellationToken cancellationToken = default);
    Task<bool> DeleteSessionAsync(string sessionId, CancellationToken cancellationToken = default);

    Task StartRunAsync(ActiveRunInfo run, CancellationToken cancellationToken = default);
    Task UpdateRunPhaseAsync(string runId, string phase, int usedTokens, string status, CancellationToken cancellationToken = default);
    Task CompleteRunAsync(string runId, string status, int usedTokens, string? error, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<ActiveRunInfo>> ListActiveRunsAsync(CancellationToken cancellationToken = default);
    Task<ActiveRunInfo?> GetRunAsync(string runId, CancellationToken cancellationToken = default);

    Task AddCheckpointAsync(string runId, string phase, string payload, CancellationToken cancellationToken = default);
    Task<string?> GetLatestCheckpointAsync(string runId, CancellationToken cancellationToken = default);

    Task AddPolicyOverrideAsync(PolicyOverride policyOverride, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<PolicyOverride>> GetPolicyOverridesAsync(CancellationToken cancellationToken = default);

    Task SavePromptVersionAsync(PromptVersionRecord record, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<PromptVersionRecord>> GetPromptVersionsAsync(string agentName, CancellationToken cancellationToken = default);

    Task<int> GetTenantUsageAsync(string tenantId, DateOnly dayUtc, CancellationToken cancellationToken = default);
    Task AddTenantUsageAsync(string tenantId, DateOnly dayUtc, int tokens, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<RunReplayRow>> GetReplayEventsAsync(string runId, CancellationToken cancellationToken = default);

    Task<string> EnqueueMigrationJobAsync(
        string tenantId,
        string runId,
        string prompt,
        int budgetTokens,
        string? workspaceRoot = null,
        string? customInstructions = null,
        CancellationToken cancellationToken = default);
    Task<QueueJob?> TryClaimNextJobAsync(string workerId, TimeSpan leaseDuration, CancellationToken cancellationToken = default);
    Task CompleteJobAsync(string jobId, string status, string? error = null, CancellationToken cancellationToken = default);
    Task<QueueJob?> GetJobAsync(string jobId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<QueueJob>> ListJobsAsync(int take = 100, CancellationToken cancellationToken = default);
}

public sealed record ChatHistoryRow(string Role, string Content);
