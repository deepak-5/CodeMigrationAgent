using System.Text;

namespace CodeMigrationAgent.Platform;

public sealed class PromptCatalogOptions
{
    public Dictionary<string, Dictionary<string, string>> AgentPrompts { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class PromptVersioningService
{
    private readonly PromptCatalogOptions _catalog;
    private readonly IDurableStateStore _store;
    private readonly ControlPlaneService _controlPlane;
    private readonly ProjectInstructionService _projectInstructions;

    public PromptVersioningService(
        PromptCatalogOptions catalog,
        IDurableStateStore store,
        ControlPlaneService controlPlane,
        ProjectInstructionService projectInstructions)
    {
        _catalog = catalog;
        _store = store;
        _controlPlane = controlPlane;
        _projectInstructions = projectInstructions;
    }

    public async Task<string?> ResolveInstructionsAsync(
        string agentName,
        string tenantId,
        string runId,
        string? workspaceRoot = null,
        string? customInstructions = null,
        CancellationToken cancellationToken = default)
    {
        var version = _controlPlane.ResolveConfigVersion(tenantId, runId);

        var overrides = await _store.GetPolicyOverridesAsync(cancellationToken);
        var promptOverride = overrides.FirstOrDefault(o => o.Key.Equals($"prompt:{agentName}:version", StringComparison.OrdinalIgnoreCase));
        if (promptOverride is not null)
        {
            version = promptOverride.Value;
        }

        string? catalogPrompt = null;
        if (_catalog.AgentPrompts.TryGetValue(agentName, out var versions) &&
            versions.TryGetValue(version, out var prompt))
        {
            catalogPrompt = prompt;
        }

        var snippets = await _projectInstructions.LoadInstructionsAsync(agentName, workspaceRoot, cancellationToken);
        var workspaceBlock = _projectInstructions.BuildInstructionBlock(snippets);
        var customBlock = customInstructions?.Trim();

        if (string.IsNullOrWhiteSpace(catalogPrompt) &&
            string.IsNullOrWhiteSpace(workspaceBlock) &&
            string.IsNullOrWhiteSpace(customBlock))
        {
            return null;
        }

        var composed = new StringBuilder();
        if (!string.IsNullOrWhiteSpace(catalogPrompt))
        {
            composed.AppendLine(catalogPrompt.Trim());
        }

        if (!string.IsNullOrWhiteSpace(workspaceBlock))
        {
            if (composed.Length > 0)
            {
                composed.AppendLine();
            }
            composed.AppendLine(workspaceBlock);
        }

        if (!string.IsNullOrWhiteSpace(customBlock))
        {
            if (composed.Length > 0)
            {
                composed.AppendLine();
            }
            composed.AppendLine("## Request-Level Instructions");
            composed.AppendLine(customBlock);
        }

        return composed.ToString().Trim();
    }
}
