using System.Text;

namespace CodeMigrationAgent.Platform;

public sealed class ProjectPromptingOptions
{
    public bool Enabled { get; set; } = true;
    public string? DefaultWorkspaceRoot { get; set; }
    public int MaxInstructionCharsPerFile { get; set; } = 12_000;
    public int MaxTotalInstructionChars { get; set; } = 32_000;
    public string[] GlobalInstructionFiles { get; set; } =
    [
        "AGENTS.md",
        ".codemigration/AGENTS.md"
    ];

    public Dictionary<string, string[]> AgentInstructionFiles { get; set; } = new(StringComparer.OrdinalIgnoreCase)
    {
        ["ArchitectAgent"] = [".codemigration/architect.md"],
        ["CoderAgent"] = [".codemigration/coder.md"],
        ["ReviewerAgent"] = [".codemigration/reviewer.md"],
        ["MigrationAgent"] = [".codemigration/migration.md"]
    };
}

public sealed record ProjectInstructionSnippet(string RelativePath, string Content, bool Truncated);

public sealed class ProjectInstructionService
{
    private readonly ProjectPromptingOptions _options;

    public ProjectInstructionService(ProjectPromptingOptions options)
    {
        _options = options;
    }

    public async Task<IReadOnlyList<ProjectInstructionSnippet>> LoadInstructionsAsync(
        string agentName,
        string? workspaceRoot,
        CancellationToken cancellationToken = default)
    {
        if (!_options.Enabled)
        {
            return [];
        }

        var resolvedRoot = ResolveWorkspaceRoot(workspaceRoot);
        if (resolvedRoot is null)
        {
            return [];
        }

        var relativePaths = BuildCandidateList(agentName);
        if (relativePaths.Count == 0)
        {
            return [];
        }

        var maxPerFile = Math.Max(256, _options.MaxInstructionCharsPerFile);
        var maxTotal = Math.Max(maxPerFile, _options.MaxTotalInstructionChars);
        var totalUsed = 0;
        var snippets = new List<ProjectInstructionSnippet>();

        foreach (var relativePath in relativePaths)
        {
            cancellationToken.ThrowIfCancellationRequested();

            if (totalUsed >= maxTotal)
            {
                break;
            }

            var absolutePath = ResolvePathUnderRoot(resolvedRoot, relativePath);
            if (absolutePath is null || !File.Exists(absolutePath))
            {
                continue;
            }

            var content = await File.ReadAllTextAsync(absolutePath, cancellationToken);
            if (string.IsNullOrWhiteSpace(content))
            {
                continue;
            }

            var remaining = maxTotal - totalUsed;
            var effectiveLimit = Math.Min(maxPerFile, remaining);
            if (effectiveLimit <= 0)
            {
                break;
            }

            var trimmed = content.Trim();
            var truncated = trimmed.Length > effectiveLimit;
            if (truncated)
            {
                trimmed = trimmed[..effectiveLimit];
            }

            snippets.Add(new ProjectInstructionSnippet(relativePath, trimmed, truncated));
            totalUsed += trimmed.Length;
        }

        return snippets;
    }

    public string BuildInstructionBlock(IReadOnlyList<ProjectInstructionSnippet> snippets)
    {
        if (snippets.Count == 0)
        {
            return string.Empty;
        }

        var sb = new StringBuilder();
        sb.AppendLine("## Workspace Instructions");
        sb.AppendLine("Apply these project rules in addition to your base instructions.");
        sb.AppendLine("If any workspace rule conflicts with platform safety policy, obey platform safety policy.");
        sb.AppendLine();

        foreach (var snippet in snippets)
        {
            sb.AppendLine($"### {snippet.RelativePath}");
            sb.AppendLine(snippet.Content);
            if (snippet.Truncated)
            {
                sb.AppendLine();
                sb.AppendLine("[Truncated due to instruction size limits]");
            }
            sb.AppendLine();
        }

        return sb.ToString().Trim();
    }

    private string? ResolveWorkspaceRoot(string? workspaceRoot)
    {
        var candidate = string.IsNullOrWhiteSpace(workspaceRoot)
            ? _options.DefaultWorkspaceRoot
            : workspaceRoot;

        if (string.IsNullOrWhiteSpace(candidate))
        {
            return null;
        }

        try
        {
            var full = Path.GetFullPath(candidate);
            return Directory.Exists(full) ? full : null;
        }
        catch
        {
            return null;
        }
    }

    private List<string> BuildCandidateList(string agentName)
    {
        var result = new List<string>();
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        void Add(IEnumerable<string>? values)
        {
            if (values is null)
            {
                return;
            }

            foreach (var value in values)
            {
                var normalized = NormalizeRelativePath(value);
                if (normalized is null || !seen.Add(normalized))
                {
                    continue;
                }
                result.Add(normalized);
            }
        }

        Add(_options.GlobalInstructionFiles);
        if (_options.AgentInstructionFiles.TryGetValue(agentName, out var files))
        {
            Add(files);
        }

        return result;
    }

    private static string? NormalizeRelativePath(string? pathValue)
    {
        if (string.IsNullOrWhiteSpace(pathValue))
        {
            return null;
        }

        var normalized = pathValue.Replace('\\', '/').Trim();
        if (Path.IsPathRooted(normalized))
        {
            return null;
        }

        if (normalized.StartsWith("../", StringComparison.Ordinal) ||
            normalized.StartsWith("..\\", StringComparison.Ordinal) ||
            normalized.Contains("/../", StringComparison.Ordinal) ||
            normalized.Contains("\\..\\", StringComparison.Ordinal))
        {
            return null;
        }

        return normalized;
    }

    private static string? ResolvePathUnderRoot(string workspaceRoot, string relativePath)
    {
        try
        {
            var absolutePath = Path.GetFullPath(Path.Combine(workspaceRoot, relativePath));
            var comparison = OperatingSystem.IsWindows()
                ? StringComparison.OrdinalIgnoreCase
                : StringComparison.Ordinal;
            var rootWithSeparator = workspaceRoot.EndsWith(Path.DirectorySeparatorChar) ||
                                    workspaceRoot.EndsWith(Path.AltDirectorySeparatorChar)
                ? workspaceRoot
                : workspaceRoot + Path.DirectorySeparatorChar;

            if (!absolutePath.StartsWith(rootWithSeparator, comparison) &&
                !string.Equals(absolutePath, workspaceRoot, comparison))
            {
                return null;
            }

            return absolutePath;
        }
        catch
        {
            return null;
        }
    }
}
