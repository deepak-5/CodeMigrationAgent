namespace CodeMigrationAgent.Models
{
    /// <summary>
    /// Defines a structured workflow with steps, mandates, and halt-conditions.
    /// Inspired by BMAD's workflow.xml execution engine that enforces strict step ordering,
    /// mandate compliance, and halt-condition evaluation at every phase boundary.
    /// </summary>
    public class WorkflowDefinition
    {
        /// <summary>Unique workflow identifier.</summary>
        public required string Name { get; set; }

        /// <summary>Human-readable description of what this workflow accomplishes.</summary>
        public string Description { get; set; } = "";

        /// <summary>Ordered list of steps to execute. Steps run in exact numerical order.</summary>
        public List<WorkflowStep> Steps { get; set; } = new();

        /// <summary>
        /// Mandates that MUST be followed throughout execution.
        /// BMAD pattern: "Always read COMPLETE files", "NEVER skip a step".
        /// Violations cause immediate halt.
        /// </summary>
        public List<string> Mandates { get; set; } = new();

        /// <summary>
        /// Conditions that cause the workflow to HALT immediately.
        /// BMAD pattern: "HALT if build fails", "HALT if zero findings — re-analyze".
        /// </summary>
        public List<HaltCondition> HaltConditions { get; set; } = new();

        /// <summary>Normal (checkpoint + confirm) or Yolo (full auto, skip confirmations).</summary>
        public ExecutionMode Mode { get; set; } = ExecutionMode.Normal;

        /// <summary>
        /// Reusable protocols that can be invoked by steps via invoke-protocol tag.
        /// BMAD pattern: "discover_inputs" protocol for smart file discovery.
        /// </summary>
        public Dictionary<string, WorkflowProtocol> Protocols { get; set; } = new();

        /// <summary>
        /// Input file patterns for smart context discovery.
        /// Maps pattern names to their loading configuration.
        /// </summary>
        public Dictionary<string, InputFilePattern> InputFilePatterns { get; set; } = new();
    }

    /// <summary>
    /// A single step in a workflow. Steps execute in exact numerical order.
    /// Supports conditional execution, iteration, and sub-step composition.
    /// </summary>
    public class WorkflowStep
    {
        /// <summary>Step number — determines execution order.</summary>
        public int StepNumber { get; set; }

        /// <summary>Human-readable title for logging and UI.</summary>
        public required string Title { get; set; }

        /// <summary>What this step does — the agent will execute this.</summary>
        public string Description { get; set; } = "";

        /// <summary>If true, this step cannot be skipped even in YOLO mode.</summary>
        public bool IsCritical { get; set; }

        /// <summary>If true, step can be skipped (in Normal mode, asks user; in YOLO, auto-skips).</summary>
        public bool IsOptional { get; set; }

        /// <summary>Conditional expression — step only executes if condition evaluates true.</summary>
        public string? Condition { get; set; }

        /// <summary>
        /// Actions to perform in this step. Each action is a required operation.
        /// BMAD: "Each action xml tag within step xml tag is a REQUIRED action."
        /// </summary>
        public List<string> Actions { get; set; } = new();

        /// <summary>Sub-steps for complex operations within a single step.</summary>
        public List<WorkflowStep> SubSteps { get; set; } = new();

        /// <summary>The agent to invoke for this step, if different from the default.</summary>
        public string? AgentName { get; set; }

        /// <summary>
        /// If set, this step produces a template-output checkpoint.
        /// BMAD: "Save content, discuss with user, NEVER proceed until user indicates."
        /// </summary>
        public bool IsCheckpoint { get; set; }
    }

    /// <summary>
    /// A condition that causes immediate workflow halt.
    /// BMAD: "HALT if zero findings — this is suspicious, re-analyze or ask for guidance."
    /// </summary>
    public record HaltCondition
    {
        /// <summary>Description of the condition that triggers a halt.</summary>
        public required string Condition { get; init; }

        /// <summary>How severe this halt is — determines if YOLO mode can override.</summary>
        public HaltSeverity Severity { get; init; } = HaltSeverity.Error;

        /// <summary>Optional recovery action to suggest when this halt triggers.</summary>
        public string? RecoveryAction { get; init; }
    }

    /// <summary>Halt severity levels — Critical cannot be overridden even in YOLO mode.</summary>
    public enum HaltSeverity
    {
        Warning,    // Logged but can continue
        Error,      // Halts in Normal mode, warns in YOLO
        Critical    // ALWAYS halts, even in YOLO mode
    }

    /// <summary>Execution mode — Normal (interactive) or Yolo (full auto).</summary>
    public enum ExecutionMode
    {
        /// <summary>Full user interaction and confirmation at every checkpoint.</summary>
        Normal,

        /// <summary>
        /// Skip all confirmations, minimize prompts, produce all output automatically.
        /// BMAD: "simulating the remaining discussions with a simulated expert user."
        /// </summary>
        Yolo
    }

    /// <summary>
    /// A reusable protocol that workflow steps can invoke.
    /// BMAD pattern: invoke-protocol name="discover_inputs".
    /// </summary>
    public class WorkflowProtocol
    {
        public required string Name { get; set; }
        public string Description { get; set; } = "";
        public List<WorkflowStep> Steps { get; set; } = new();
    }

    /// <summary>
    /// Defines a file pattern for smart context discovery.
    /// BMAD pattern: input_file_patterns with whole/sharded/load_strategy.
    /// </summary>
    public class InputFilePattern
    {
        public string Description { get; set; } = "";
        public string? WholePattern { get; set; }
        public string? ShardedPattern { get; set; }
        public string? ShardedIndexPattern { get; set; }
        public string? ShardedSinglePattern { get; set; }
        public ContextLoadStrategy LoadStrategy { get; set; } = ContextLoadStrategy.FullLoad;
    }

    /// <summary>
    /// Smart context loading strategies from BMAD's discover_inputs protocol.
    /// </summary>
    public enum ContextLoadStrategy
    {
        /// <summary>Load ALL files — used for architecture docs, PRDs.</summary>
        FullLoad,

        /// <summary>Load specific file using template variable — e.g., epic-{{epic_num}}.md</summary>
        SelectiveLoad,

        /// <summary>
        /// Load index.md → analyze → intelligently load relevant docs.
        /// BMAD mandate: "DO NOT BE LAZY — use best judgment to load docs with even 5% chance of relevance."
        /// </summary>
        IndexGuided
    }
}
