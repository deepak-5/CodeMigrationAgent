using System.Text.Json;

namespace CodeMigrationAgent.Models
{
    /// <summary>
    /// Serializable checkpoint for seamless agent hand-off when token budget is exhausted.
    /// The continuation agent receives this to resume work without losing progress.
    /// </summary>
    public class ContinuationState
    {
        public string PlanId { get; set; } = string.Empty;
        public int Iteration { get; set; } = 0;
        public List<TaskResult> CompletedTasks { get; set; } = new();
        public List<TaskAssignment> PendingTasks { get; set; } = new();
        public string SharedContextSummary { get; set; } = string.Empty; // Compressed summary of work done so far
        public Dictionary<string, string> FileSnapshots { get; set; } = new(); // Key file states
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public int TotalTokensUsedAcrossIterations { get; set; } = 0;

        public string Serialize() => JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true });

        public static ContinuationState Deserialize(string json) =>
            JsonSerializer.Deserialize<ContinuationState>(json) ?? new ContinuationState();
    }
}
