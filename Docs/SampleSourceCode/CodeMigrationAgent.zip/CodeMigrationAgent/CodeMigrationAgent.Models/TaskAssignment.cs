namespace CodeMigrationAgent.Models
{
    /// <summary>
    /// A lightweight work packet sent to each parallel worker agent.
    /// Contains only the surgical context needed for that specific task.
    /// </summary>
    public class TaskAssignment
    {
        public string TaskId { get; set; } = Guid.NewGuid().ToString("N")[..8];
        public string ParentPlanId { get; set; } = string.Empty;
        public string FilePath { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string ModificationType { get; set; } = string.Empty; // Create, Modify, Delete
        public string DependencyContext { get; set; } = string.Empty; // Just-enough info from related files
        public int Priority { get; set; } = 0; // 0 = normal, higher = more urgent
        public Dictionary<string, string> Metadata { get; set; } = new();
    }
}
