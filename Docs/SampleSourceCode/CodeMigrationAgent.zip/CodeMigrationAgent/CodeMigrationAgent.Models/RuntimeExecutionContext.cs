namespace CodeMigrationAgent.Models;

public static class RuntimeExecutionContext
{
    private static readonly AsyncLocal<string?> RunIdValue = new();
    private static readonly AsyncLocal<string?> TenantIdValue = new();
    private static readonly AsyncLocal<string?> ConfigVersionValue = new();

    public static string? RunId
    {
        get => RunIdValue.Value;
        set => RunIdValue.Value = value;
    }

    public static string? TenantId
    {
        get => TenantIdValue.Value;
        set => TenantIdValue.Value = value;
    }

    public static string? ConfigVersion
    {
        get => ConfigVersionValue.Value;
        set => ConfigVersionValue.Value = value;
    }
}
