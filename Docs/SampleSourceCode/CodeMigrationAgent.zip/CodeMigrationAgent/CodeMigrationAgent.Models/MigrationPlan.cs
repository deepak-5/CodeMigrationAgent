using System.Collections.Generic;

namespace CodeMigrationAgent.Models
{
    /// <summary>
    /// The structured migration plan produced by the Architect Agent.
    /// Groups independent modifications into ParallelTasks for concurrent execution.
    /// </summary>
    public class MigrationPlan
    {
        public string PlanId { get; set; } = Guid.NewGuid().ToString("N")[..8];
        public string Overview { get; set; } = string.Empty;
        public List<FileModification> Modifications { get; set; } = new();
        public List<ParallelTaskGroup> ParallelTasks { get; set; } = new();
        public List<string> VerificationSteps { get; set; } = new();
        public string SourceFramework { get; set; } = string.Empty; // e.g., ".NET Framework 4.8"
        public string TargetFramework { get; set; } = string.Empty; // e.g., ".NET 10"
    }

    public class FileModification
    {
        public string FilePath { get; set; } = string.Empty;
        public string ModificationType { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string DependencyContext { get; set; } = string.Empty; // Related file contents or summaries
        public List<string> DependsOn { get; set; } = new();
        public bool CanRunInParallel { get; set; } = true;
    }

    /// <summary>
    /// A group of independent file modifications that can be fanned out to parallel worker agents.
    /// </summary>
    public class ParallelTaskGroup
    {
        public string GroupName { get; set; } = string.Empty;
        public List<FileModification> Tasks { get; set; } = new();
    }
}
