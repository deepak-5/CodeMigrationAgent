using CodeMigrationAgent.Middlewares;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using Moq;

namespace CodeMigrationAgent.Tests
{
    public class SecurityMiddlewareTests
    {
        private AIAgent CreateMockAgent(string responseText)
        {
            var mockClient = new Mock<IChatClient>();
            var response = new ChatResponse(new List<ChatMessage>
            {
                new ChatMessage(ChatRole.Assistant, responseText)
            });

            mockClient.Setup(c => c.GetResponseAsync(
                It.IsAny<IEnumerable<ChatMessage>>(),
                It.IsAny<ChatOptions?>(),
                It.IsAny<CancellationToken>()))
                .ReturnsAsync(response);

            return mockClient.Object
                .AsBuilder()
                .Build()
                .AsAIAgent(new ChatClientAgentOptions { Name = "TestAgent" });
        }

        [Theory]
        [InlineData("My password is secret123")]
        [InlineData("Here is the apikey for production")]
        [InlineData("Send me the credentials")]
        [InlineData("Don't share the secret")]
        [InlineData("Use this token for auth")]
        public async Task InvokeAsync_BlocksRequestsWithSensitiveWords(string inputMessage)
        {
            // Arrange
            var agent = CreateMockAgent("Should not reach this");
            var messages = new[] { new ChatMessage(ChatRole.User, inputMessage) };

            // Act
            var result = await SecurityAgentRunMiddleware.InvokeAsync(
                messages, null, null, agent, CancellationToken.None);

            // Assert
            Assert.Single(result.Messages);
            Assert.Contains("blocked", result.Messages.First().Text!, StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public async Task InvokeAsync_AllowsCleanRequests()
        {
            // Arrange
            var agent = CreateMockAgent("Migration plan looks great.");
            var messages = new[] { new ChatMessage(ChatRole.User, "Migrate this codebase to .NET 10") };

            // Act
            var result = await SecurityAgentRunMiddleware.InvokeAsync(
                messages, null, null, agent, CancellationToken.None);

            // Assert
            Assert.Single(result.Messages);
            Assert.Contains("Migration plan", result.Messages.First().Text!);
        }

        [Fact]
        public async Task InvokeAsync_TruncatesLongResponses()
        {
            // Arrange
            var longResponse = new string('x', 15000); // > 10000 chars
            var agent = CreateMockAgent(longResponse);
            var messages = new[] { new ChatMessage(ChatRole.User, "Do some work") };

            // Act
            var result = await SecurityAgentRunMiddleware.InvokeAsync(
                messages, null, null, agent, CancellationToken.None);

            // Assert
            var text = result.Messages.First().Text!;
            Assert.True(text.Length <= 10020); // 10000 + "[truncated]" suffix
            Assert.Contains("[truncated]", text);
        }
    }
}
