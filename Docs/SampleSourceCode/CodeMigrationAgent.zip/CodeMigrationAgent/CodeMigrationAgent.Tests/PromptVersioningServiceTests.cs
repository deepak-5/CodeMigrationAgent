using CodeMigrationAgent.Platform;
using Moq;

namespace CodeMigrationAgent.Tests;

public class PromptVersioningServiceTests
{
    [Fact]
    public async Task LoadInstructionsAsync_LoadsGlobalAndAgentSpecificFiles()
    {
        var root = CreateTempDir();
        try
        {
            await File.WriteAllTextAsync(Path.Combine(root, "AGENTS.md"), "Global rules");
            Directory.CreateDirectory(Path.Combine(root, ".codemigration"));
            await File.WriteAllTextAsync(Path.Combine(root, ".codemigration", "coder.md"), "Coder rules");

            var options = new ProjectPromptingOptions
            {
                Enabled = true,
                DefaultWorkspaceRoot = root,
                GlobalInstructionFiles = ["AGENTS.md"],
                AgentInstructionFiles = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase)
                {
                    ["CoderAgent"] = [".codemigration/coder.md"]
                }
            };

            var service = new ProjectInstructionService(options);
            var snippets = await service.LoadInstructionsAsync("CoderAgent", root);

            Assert.Equal(2, snippets.Count);
            Assert.Contains(snippets, s => s.RelativePath == "AGENTS.md");
            Assert.Contains(snippets, s => s.RelativePath == ".codemigration/coder.md");
        }
        finally
        {
            Directory.Delete(root, recursive: true);
        }
    }

    [Fact]
    public async Task LoadInstructionsAsync_BlocksTraversalPaths()
    {
        var root = CreateTempDir();
        var outside = CreateTempDir();

        try
        {
            await File.WriteAllTextAsync(Path.Combine(outside, "secret.md"), "do-not-read");
            var options = new ProjectPromptingOptions
            {
                Enabled = true,
                DefaultWorkspaceRoot = root,
                GlobalInstructionFiles = ["../secret.md"]
            };

            var service = new ProjectInstructionService(options);
            var snippets = await service.LoadInstructionsAsync("CoderAgent", root);

            Assert.Empty(snippets);
        }
        finally
        {
            Directory.Delete(root, recursive: true);
            Directory.Delete(outside, recursive: true);
        }
    }

    [Fact]
    public async Task ResolveInstructionsAsync_ComposesCatalogWorkspaceAndRequestInstructions()
    {
        var root = CreateTempDir();
        try
        {
            await File.WriteAllTextAsync(Path.Combine(root, "AGENTS.md"), "Repo policy");

            var catalog = new PromptCatalogOptions
            {
                AgentPrompts = new Dictionary<string, Dictionary<string, string>>(StringComparer.OrdinalIgnoreCase)
                {
                    ["CoderAgent"] = new(StringComparer.OrdinalIgnoreCase)
                    {
                        ["stable-v1"] = "Base coder prompt"
                    }
                }
            };

            var projectOptions = new ProjectPromptingOptions
            {
                Enabled = true,
                DefaultWorkspaceRoot = root,
                GlobalInstructionFiles = ["AGENTS.md"],
                AgentInstructionFiles = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase)
            };

            var store = new Mock<IDurableStateStore>();
            store.Setup(s => s.GetPolicyOverridesAsync(It.IsAny<CancellationToken>()))
                .ReturnsAsync(Array.Empty<PolicyOverride>());

            var controlPlane = new ControlPlaneService(
                store.Object,
                new ControlPlaneOptions { CanaryPercent = 0, StableConfigVersion = "stable-v1" });

            var promptService = new PromptVersioningService(
                catalog,
                store.Object,
                controlPlane,
                new ProjectInstructionService(projectOptions));

            var composed = await promptService.ResolveInstructionsAsync(
                "CoderAgent",
                "tenant-a",
                "run-1",
                workspaceRoot: root,
                customInstructions: "Request preference");

            Assert.NotNull(composed);
            Assert.Contains("Base coder prompt", composed);
            Assert.Contains("Workspace Instructions", composed);
            Assert.Contains("Repo policy", composed);
            Assert.Contains("Request-Level Instructions", composed);
            Assert.Contains("Request preference", composed);
        }
        finally
        {
            Directory.Delete(root, recursive: true);
        }
    }

    private static string CreateTempDir()
    {
        var path = Path.Combine(Path.GetTempPath(), "cma-tests-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(path);
        return path;
    }
}
