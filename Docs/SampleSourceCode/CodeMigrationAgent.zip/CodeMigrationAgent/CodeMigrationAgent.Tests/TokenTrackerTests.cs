using CodeMigrationAgent.Models;
using CodeMigrationAgent.Workflows;
using Microsoft.Extensions.AI;
using Moq;

namespace CodeMigrationAgent.Tests
{
    public class TokenTrackerTests
    {
        [Fact]
        public async Task GetResponseAsync_WithUsageMetadata_UsesRealTokenCounts()
        {
            // Arrange
            var budget = new AgentTokenBudget { MaxTokens = 100_000 };
            var mockClient = new Mock<IChatClient>();

            var responseMessages = new List<ChatMessage>
            {
                new ChatMessage(ChatRole.Assistant, "Hello world")
            };

            var usage = new UsageDetails { InputTokenCount = 150, OutputTokenCount = 200 };
            var response = new ChatResponse(responseMessages) { Usage = usage };

            mockClient.Setup(c => c.GetResponseAsync(
                It.IsAny<IEnumerable<ChatMessage>>(),
                It.IsAny<ChatOptions?>(),
                It.IsAny<CancellationToken>()))
                .ReturnsAsync(response);

            var tracker = new TokenTracker(mockClient.Object, budget);
            var messages = new[] { new ChatMessage(ChatRole.User, new string('x', 400)) }; // 400 chars = ~100 estimated

            // Act
            await tracker.GetResponseAsync(messages);

            // Assert — real counts should replace estimation
            // Input: was estimated ~100 (400/4), corrected to 150
            // Output: 200 real
            // Total should be 150 + 200 = 350
            Assert.Equal(350, budget.UsedTokens);
        }

        [Fact]
        public async Task GetResponseAsync_WithoutUsage_FallsBackToCharEstimation()
        {
            // Arrange
            var budget = new AgentTokenBudget { MaxTokens = 100_000 };
            var mockClient = new Mock<IChatClient>();

            var responseMessages = new List<ChatMessage>
            {
                new ChatMessage(ChatRole.Assistant, new string('y', 800)) // 800 chars = 200 tokens
            };

            var response = new ChatResponse(responseMessages); // No Usage property set

            mockClient.Setup(c => c.GetResponseAsync(
                It.IsAny<IEnumerable<ChatMessage>>(),
                It.IsAny<ChatOptions?>(),
                It.IsAny<CancellationToken>()))
                .ReturnsAsync(response);

            var tracker = new TokenTracker(mockClient.Object, budget);
            var messages = new[] { new ChatMessage(ChatRole.User, new string('x', 400)) }; // 100 estimated

            // Act
            await tracker.GetResponseAsync(messages);

            // Assert — should use char/4 for both input and output
            // Input: 400/4 = 100, Output: 800/4 = 200
            Assert.Equal(300, budget.UsedTokens);
        }

        [Fact]
        public async Task GetResponseAsync_ThrowsWhenBudgetExhaustedBeforeCall()
        {
            // Arrange
            var budget = new AgentTokenBudget { MaxTokens = 100 };
            budget.AddTokens(95); // Already past 90% threshold

            var mockClient = new Mock<IChatClient>();
            var tracker = new TokenTracker(mockClient.Object, budget);
            var messages = new[] { new ChatMessage(ChatRole.User, new string('x', 400)) }; // +100 tokens pushes it way over

            // Act & Assert
            await Assert.ThrowsAsync<TokenBudgetExhaustedException>(
                () => tracker.GetResponseAsync(messages));
        }

        [Fact]
        public void Budget_IsExhausted_At90Percent()
        {
            var budget = new AgentTokenBudget { MaxTokens = 1000 };

            budget.AddTokens(899);
            Assert.False(budget.IsExhausted);

            budget.AddTokens(1); // Now at 900 = exactly 90%
            Assert.True(budget.IsExhausted);
        }

        [Fact]
        public void Budget_Reset_ClearsUsedTokens()
        {
            var budget = new AgentTokenBudget { MaxTokens = 1000 };
            budget.AddTokens(500);
            Assert.Equal(500, budget.UsedTokens);

            budget.Reset();
            Assert.Equal(0, budget.UsedTokens);
        }

        [Fact]
        public void Budget_CorrectInputTokens_ReplacesEstimateWithReal()
        {
            var budget = new AgentTokenBudget { MaxTokens = 10000 };
            budget.AddTokens(100); // estimated
            budget.AddTokens(50);  // output

            budget.CorrectInputTokens(100, 75); // real was 75, not 100

            // 100 + 50 - 100 + 75 = 125
            Assert.Equal(125, budget.UsedTokens);
        }

        [Fact]
        public void Budget_CorrectInputTokens_NeverGoesNegative()
        {
            var budget = new AgentTokenBudget { MaxTokens = 10000 };
            budget.AddTokens(10);

            budget.CorrectInputTokens(100, 5); // subtraction would go negative

            Assert.Equal(0, budget.UsedTokens);
        }
    }
}
