using CodeMigrationAgent.Models;

namespace CodeMigrationAgent.Tests
{
    public class AgentPersonaTests
    {
        [Fact]
        public void ToSystemPrompt_IncludesAllPersonaFields()
        {
            var persona = new AgentPersona
            {
                Name = "TestBot",
                Title = "Test Specialist",
                Icon = "🧪",
                Role = "A testing robot",
                Identity = "Expert in all things tests",
                CommunicationStyle = "Precise and technical",
                Principles = new[] { "Test everything", "Break nothing" },
                CriticalActions = new[] { "ALWAYS verify", "NEVER skip" }
            };

            var result = persona.ToSystemPrompt("Do the work.");

            Assert.Contains("TestBot", result);
            Assert.Contains("Test Specialist", result);
            Assert.Contains("🧪", result);
            Assert.Contains("A testing robot", result);
            Assert.Contains("Expert in all things tests", result);
            Assert.Contains("Precise and technical", result);
            Assert.Contains("Test everything", result);
            Assert.Contains("Break nothing", result);
            Assert.Contains("ALWAYS verify", result);
            Assert.Contains("NEVER skip", result);
            Assert.Contains("Do the work.", result);
        }

        [Fact]
        public void ToSystemPrompt_IncludesSectionHeaders()
        {
            var persona = new AgentPersona
            {
                Name = "Bot",
                Title = "Title",
                Icon = "🤖",
                Role = "Role",
                Identity = "Identity",
                CommunicationStyle = "Style",
                Principles = new[] { "P1" },
                CriticalActions = new[] { "CA1" }
            };

            var result = persona.ToSystemPrompt("Instructions here");

            Assert.Contains("Core Principles", result);
            Assert.Contains("CRITICAL ACTIONS", result);
            Assert.Contains("Mission & Instructions", result);
        }

        [Fact]
        public void ToSystemPrompt_OmitsCriticalActionsWhenEmpty()
        {
            var persona = new AgentPersona
            {
                Name = "Bot",
                Title = "Title",
                Icon = "🤖",
                Role = "Role",
                Identity = "Identity",
                CommunicationStyle = "Style",
                Principles = new[] { "P1" },
                CriticalActions = Array.Empty<string>()
            };

            var result = persona.ToSystemPrompt("Instructions");

            Assert.DoesNotContain("CRITICAL ACTIONS", result);
        }

        [Fact]
        public void ToSystemPrompt_OmitsPrinciplesWhenEmpty()
        {
            var persona = new AgentPersona
            {
                Name = "Bot",
                Title = "Title",
                Icon = "🤖",
                Role = "Role",
                Identity = "Identity",
                CommunicationStyle = "Style",
                Principles = Array.Empty<string>()
            };

            var result = persona.ToSystemPrompt("Instructions");

            Assert.DoesNotContain("Core Principles", result);
        }

        [Fact]
        public void DefaultCapabilities_IsEmptyArray()
        {
            var persona = new AgentPersona
            {
                Name = "Bot",
                Title = "Title",
                Icon = "🤖",
                Role = "Role",
                Identity = "Identity",
                CommunicationStyle = "Style",
                Principles = Array.Empty<string>()
            };

            Assert.Empty(persona.Capabilities);
        }

        [Fact]
        public void AdversarialReviewerPersona_HasCorrectCriticalActions()
        {
            var persona = CodeMigrationAgent.Agents.AdversarialReviewerAgentBuilder.Persona;

            Assert.Equal("Razor", persona.Name);
            Assert.Equal("🔪", persona.Icon);
            Assert.Contains(persona.CriticalActions, ca => ca.Contains("TEN issues"));
            Assert.Contains(persona.CriticalActions, ca => ca.Contains("ZERO issues"));
            Assert.Contains(persona.Principles, p => p.Contains("skeptical"));
        }

        [Fact]
        public void ArchitectPersona_HasDecompositionPrinciple()
        {
            var persona = CodeMigrationAgent.Agents.ArchitectAgentBuilder.Persona;

            Assert.Equal("Winston", persona.Name);
            Assert.Contains(persona.Principles, p => p.Contains("parallel"));
        }

        [Fact]
        public void CoderPersona_HasTDDCriticalActions()
        {
            var persona = CodeMigrationAgent.Agents.CoderAgentBuilder.Persona;

            Assert.Equal("Amelia", persona.Name);
            Assert.Contains(persona.CriticalActions, ca => ca.Contains("READ the entire task"));
            Assert.Contains(persona.CriticalActions, ca => ca.Contains("NEVER lie"));
        }
    }
}
