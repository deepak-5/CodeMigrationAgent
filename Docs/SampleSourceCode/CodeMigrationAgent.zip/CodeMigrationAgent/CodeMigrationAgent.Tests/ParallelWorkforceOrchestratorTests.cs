using CodeMigrationAgent.Tools;
using CodeMigrationAgent.Models;

namespace CodeMigrationAgent.Tests
{
    public class ParallelWorkforceOrchestratorTests
    {
        [Fact]
        public async Task EnqueueTaskAsync_And_StartWorkers_ProcessesTasksSuccessfully()
        {
            var orchestrator = new ParallelWorkforceOrchestrator(maxParallelWorkers: 2);
            var completedCount = 0;

            orchestrator.StartWorkers(async (assignment, ct) =>
            {
                await Task.Delay(10, ct); 
                Interlocked.Increment(ref completedCount);
                return $"Processed {assignment.Description}";
            });

            await orchestrator.EnqueueTaskAsync(new TaskAssignment { TaskId = "1", Description = "Test 1" });
            await orchestrator.EnqueueTaskAsync(new TaskAssignment { TaskId = "2", Description = "Test 2" });
            await orchestrator.EnqueueTaskAsync(new TaskAssignment { TaskId = "3", Description = "Test 3" });

            await orchestrator.WaitUntilDrainedAsync();

            var results = orchestrator.GetResults();

            Assert.Equal(3, completedCount);
            Assert.Equal(3, results.Count);
            Assert.Contains("Processed Test 1", results["1"]);
            Assert.Contains("Processed Test 3", results["3"]);
        }

        [Fact]
        public async Task ExceptionInTask_DoesNotCrashWorker_RecordsFailure()
        {
            var orchestrator = new ParallelWorkforceOrchestrator(maxParallelWorkers: 1);

            orchestrator.StartWorkers((assignment, ct) =>
            {
                if (assignment.TaskId == "fail")
                    throw new InvalidOperationException("Simulated crash");

                return Task.FromResult("Success");
            });

            await orchestrator.EnqueueTaskAsync(new TaskAssignment { TaskId = "fail" });
            await orchestrator.EnqueueTaskAsync(new TaskAssignment { TaskId = "pass" });

            await orchestrator.WaitUntilDrainedAsync();

            var results = orchestrator.GetResults();

            Assert.Equal(2, results.Count);
            Assert.Contains("[FAILED]", results["fail"]);
            Assert.Contains("Simulated crash", results["fail"]);
            Assert.Equal("Success", results["pass"]);
        }

        [Fact]
        public async Task Shutdown_CancelsActiveWorkers()
        {
            var orchestrator = new ParallelWorkforceOrchestrator(maxParallelWorkers: 1);
            var taskStarted = new TaskCompletionSource();

            orchestrator.StartWorkers(async (assignment, ct) =>
            {
                taskStarted.SetResult();
                await Task.Delay(5000, ct); // Should be cancelled
                return "Done";
            });

            _ = orchestrator.EnqueueTaskAsync(new TaskAssignment { TaskId = "long" });

            await taskStarted.Task; // Wait until the worker actually picks up the task
            
            orchestrator.Shutdown();
            
            // WaitUntilDrained immediately resolves after Shutdown since channels are force-completed
            await orchestrator.WaitUntilDrainedAsync();

            var results = orchestrator.GetResults();
            Assert.Empty(results); // The task was cancelled before returning a result
        }
    }
}
