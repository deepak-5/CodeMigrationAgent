using CodeMigrationAgent.Workflows;

namespace CodeMigrationAgent.Tests
{
    public class CheckpointManagerTests : IDisposable
    {
        private readonly string _testDir;
        private readonly CheckpointManager _manager;

        public CheckpointManagerTests()
        {
            _testDir = Path.Combine(Path.GetTempPath(), $"checkpoint-test-{Guid.NewGuid():N}");
            _manager = new CheckpointManager(_testDir);
        }

        public void Dispose()
        {
            if (Directory.Exists(_testDir))
                Directory.Delete(_testDir, true);
        }

        [Fact]
        public async Task SaveAndLoad_RoundTrips()
        {
            var checkpoint = new MigrationCheckpoint
            {
                CheckpointId = "run-001-architect",
                Phase = "architect",
                Data = "{\"plan\": \"test\"}",
                CompletedAt = DateTime.UtcNow
            };

            await _manager.SaveCheckpointAsync(checkpoint);
            var loaded = await _manager.LoadCheckpointAsync("run-001-architect");

            Assert.NotNull(loaded);
            Assert.Equal("run-001-architect", loaded.CheckpointId);
            Assert.Equal("architect", loaded.Phase);
            Assert.Equal("{\"plan\": \"test\"}", loaded.Data);
        }

        [Fact]
        public async Task LoadCheckpoint_ReturnsNullForMissing()
        {
            var loaded = await _manager.LoadCheckpointAsync("nonexistent");
            Assert.Null(loaded);
        }

        [Fact]
        public async Task ListCheckpoints_ReturnsInReverseChronologicalOrder()
        {
            await _manager.SaveCheckpointAsync(new MigrationCheckpoint
            {
                CheckpointId = "run-001-first",
                Phase = "architect",
                CompletedAt = DateTime.UtcNow.AddMinutes(-2)
            });
            await _manager.SaveCheckpointAsync(new MigrationCheckpoint
            {
                CheckpointId = "run-001-second",
                Phase = "coder",
                CompletedAt = DateTime.UtcNow.AddMinutes(-1)
            });
            await _manager.SaveCheckpointAsync(new MigrationCheckpoint
            {
                CheckpointId = "run-001-third",
                Phase = "reviewer",
                CompletedAt = DateTime.UtcNow
            });

            var list = _manager.ListCheckpoints();

            Assert.Equal(3, list.Count);
            Assert.Equal("run-001-third", list[0].CheckpointId);
            Assert.Equal("run-001-second", list[1].CheckpointId);
            Assert.Equal("run-001-first", list[2].CheckpointId);
        }

        [Fact]
        public async Task GetLatestCheckpoint_FindsCorrectOne()
        {
            await _manager.SaveCheckpointAsync(new MigrationCheckpoint
            {
                CheckpointId = "run-001-architect",
                Phase = "architect",
                CompletedAt = DateTime.UtcNow.AddMinutes(-1)
            });
            await _manager.SaveCheckpointAsync(new MigrationCheckpoint
            {
                CheckpointId = "run-001-coder",
                Phase = "coder",
                CompletedAt = DateTime.UtcNow
            });

            var latest = _manager.GetLatestCheckpoint("run-001");

            Assert.NotNull(latest);
            Assert.Equal("run-001-coder", latest.CheckpointId);
        }

        [Fact]
        public async Task CleanupCheckpoints_RemovesAll()
        {
            await _manager.SaveCheckpointAsync(new MigrationCheckpoint
            {
                CheckpointId = "run-001-a",
                Phase = "a"
            });
            await _manager.SaveCheckpointAsync(new MigrationCheckpoint
            {
                CheckpointId = "run-001-b",
                Phase = "b"
            });

            _manager.CleanupCheckpoints("run-001");

            Assert.Empty(_manager.ListCheckpoints());
        }

        [Fact]
        public async Task SaveCheckpoint_IncludesMetadata()
        {
            var checkpoint = new MigrationCheckpoint
            {
                CheckpointId = "meta-test",
                Phase = "test",
                Metadata = new() { ["key1"] = "value1", ["key2"] = "value2" }
            };

            await _manager.SaveCheckpointAsync(checkpoint);
            var loaded = await _manager.LoadCheckpointAsync("meta-test");

            Assert.NotNull(loaded);
            Assert.Equal(2, loaded.Metadata.Count);
            Assert.Equal("value1", loaded.Metadata["key1"]);
        }
    }
}
