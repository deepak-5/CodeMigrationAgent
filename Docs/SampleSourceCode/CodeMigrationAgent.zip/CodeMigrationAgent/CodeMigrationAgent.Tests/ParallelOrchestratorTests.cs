using CodeMigrationAgent.Models;
using CodeMigrationAgent.Workflows;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using Moq;

namespace CodeMigrationAgent.Tests
{
    public class ParallelOrchestratorTests
    {
        private AIAgent CreateMockAgent(string responseText, bool shouldFail = false)
        {
            var mockClient = new Mock<IChatClient>();

            if (shouldFail)
            {
                mockClient.Setup(c => c.GetResponseAsync(
                    It.IsAny<IEnumerable<ChatMessage>>(),
                    It.IsAny<ChatOptions?>(),
                    It.IsAny<CancellationToken>()))
                    .ThrowsAsync(new InvalidOperationException("Simulated failure"));
            }
            else
            {
                var response = new ChatResponse(new List<ChatMessage>
                {
                    new ChatMessage(ChatRole.Assistant, responseText)
                });

                mockClient.Setup(c => c.GetResponseAsync(
                    It.IsAny<IEnumerable<ChatMessage>>(),
                    It.IsAny<ChatOptions?>(),
                    It.IsAny<CancellationToken>()))
                    .ReturnsAsync(response);
            }

            return mockClient.Object
                .AsBuilder()
                .Build()
                .AsAIAgent(new ChatClientAgentOptions { Name = "TestWorker" });
        }

        [Fact]
        public async Task ExecuteParallelAsync_FansOutAndCollectsResults()
        {
            // Arrange
            var plan = new MigrationPlan
            {
                PlanId = "test-001",
                Modifications = new List<FileModification>
                {
                    new() { FilePath = "file1.cs", Description = "Task 1", ModificationType = "Modify", CanRunInParallel = true },
                    new() { FilePath = "file2.cs", Description = "Task 2", ModificationType = "Modify", CanRunInParallel = true },
                }
            };

            var orchestrator = new ParallelOrchestrator(
                () => CreateMockAgent("Done"),
                maxConcurrency: 4);

            // Act
            var results = await orchestrator.ExecuteParallelAsync(plan);

            // Assert
            Assert.Equal(2, results.Count);
            Assert.All(results, r => Assert.Equal(Models.TaskStatus.Completed, r.Status));
        }

        [Fact]
        public async Task ExecuteParallelAsync_FailedTasksReturnFailedStatus()
        {
            // Arrange
            var plan = new MigrationPlan
            {
                PlanId = "test-002",
                Modifications = new List<FileModification>
                {
                    new() { FilePath = "fail.cs", Description = "Will fail", ModificationType = "Modify", CanRunInParallel = true },
                }
            };

            var orchestrator = new ParallelOrchestrator(
                () => CreateMockAgent("", shouldFail: true),
                maxConcurrency: 2,
                retryPolicy: new RetryPolicy { MaxRetries = 0 }); // No retries

            // Act
            var results = await orchestrator.ExecuteParallelAsync(plan);

            // Assert
            Assert.Single(results);
            Assert.Equal(Models.TaskStatus.Failed, results[0].Status);
            Assert.Contains("Simulated failure", results[0].ErrorMessage);
        }

        [Fact]
        public async Task ExecuteParallelAsync_RetryLogicRetriesOnFailure()
        {
            // Arrange
            var callCount = 0;
            var plan = new MigrationPlan
            {
                PlanId = "test-003",
                Modifications = new List<FileModification>
                {
                    new() { FilePath = "retry.cs", Description = "Needs retry", ModificationType = "Modify", CanRunInParallel = true },
                }
            };

            // Factory that fails first then succeeds
            var orchestrator = new ParallelOrchestrator(
                () =>
                {
                    callCount++;
                    return CreateMockAgent("Success", shouldFail: callCount <= 1);
                },
                maxConcurrency: 2,
                retryPolicy: new RetryPolicy { MaxRetries = 2, InitialDelay = TimeSpan.FromMilliseconds(10) });

            // Act
            var results = await orchestrator.ExecuteParallelAsync(plan);

            // Assert — should succeed on retry
            Assert.Single(results);
            Assert.Equal(Models.TaskStatus.Completed, results[0].Status);
            Assert.True(callCount >= 2, "Should have been called at least twice (initial + retry)");
        }

        [Fact]
        public async Task ExecuteParallelAsync_IncludesParallelTaskGroups()
        {
            // Arrange
            var plan = new MigrationPlan
            {
                PlanId = "test-004",
                Modifications = new List<FileModification>(),
                ParallelTasks = new List<ParallelTaskGroup>
                {
                    new()
                    {
                        GroupName = "Group1",
                        Tasks = new List<FileModification>
                        {
                            new() { FilePath = "g1.cs", Description = "Group task", ModificationType = "Create" }
                        }
                    }
                }
            };

            var orchestrator = new ParallelOrchestrator(
                () => CreateMockAgent("Done from group"),
                maxConcurrency: 4);

            // Act
            var results = await orchestrator.ExecuteParallelAsync(plan);

            // Assert
            Assert.Single(results);
            Assert.Equal(Models.TaskStatus.Completed, results[0].Status);
        }
    }
}
