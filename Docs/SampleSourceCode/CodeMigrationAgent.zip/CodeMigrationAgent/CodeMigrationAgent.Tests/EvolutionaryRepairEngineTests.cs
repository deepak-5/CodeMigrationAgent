using CodeMigrationAgent.Workflows;
using CodeMigrationAgent.Models;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using Moq;

namespace CodeMigrationAgent.Tests
{
    public class EvolutionaryRepairEngineTests
    {
        [Fact]
        public async Task RunWithAutoHealingAsync_PassesFirstTime_NoRepairAttempted()
        {
            var mockClient = new Mock<IChatClient>();
            mockClient
                .Setup(c => c.GetResponseAsync(It.IsAny<IList<ChatMessage>>(), It.IsAny<ChatOptions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ChatResponse(new[] { new ChatMessage(ChatRole.Assistant, "Everything is perfect. Build succeeded.") }));

            var mockAgent = new ChatClientAgent(mockClient.Object, "TestPrimary", "Test Prompt");

            var engine = new EvolutionaryRepairEngine(maxRetries: 3);
            var config = new QualityGateConfig { RequireBuildPass = true };

            var result = await engine.RunWithAutoHealingAsync(mockClient.Object, mockAgent, new[] { new ChatMessage(ChatRole.User, "Do work") }, config, "CodePhase");

            Assert.Equal("Everything is perfect. Build succeeded.", result);
            mockClient.Verify(c => c.GetResponseAsync(It.IsAny<IList<ChatMessage>>(), It.IsAny<ChatOptions>(), It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async Task RunWithAutoHealingAsync_FailsGate_InvokesFixerAgentAndPasses()
        {
            var mockClient = new Mock<IChatClient>();
            
            // First call fails the gate (Build FAILED)
            mockClient
                .SetupSequence(c => c.GetResponseAsync(It.IsAny<IList<ChatMessage>>(), It.IsAny<ChatOptions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ChatResponse(new[] { new ChatMessage(ChatRole.Assistant, "Here is the code. Build FAILED.") }))
                // Second call (from FixerAgent) returns a passing build
                .ReturnsAsync(new ChatResponse(new[] { new ChatMessage(ChatRole.Assistant, "I fixed the error. Build succeeded.") }));

            var mockAgent = new ChatClientAgent(mockClient.Object, "TestPrimary", "Test Prompt");

            var engine = new EvolutionaryRepairEngine(maxRetries: 3);
            var config = new QualityGateConfig { RequireBuildPass = true };

            var result = await engine.RunWithAutoHealingAsync(mockClient.Object, mockAgent, new[] { new ChatMessage(ChatRole.User, "Do work") }, config, "CodePhase");

            Assert.Equal("I fixed the error. Build succeeded.", result);
            // It was called twice: once for primary, once for fixer
            mockClient.Verify(c => c.GetResponseAsync(It.IsAny<IList<ChatMessage>>(), It.IsAny<ChatOptions>(), It.IsAny<CancellationToken>()), Times.Exactly(2));
        }

        [Fact]
        public async Task RunWithAutoHealingAsync_FailsGateRepeatedly_ExhaustsRetries()
        {
            var mockClient = new Mock<IChatClient>();
            
            // It always returns a failed build
            mockClient
                .Setup(c => c.GetResponseAsync(It.IsAny<IList<ChatMessage>>(), It.IsAny<ChatOptions>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ChatResponse(new[] { new ChatMessage(ChatRole.Assistant, "Build FAILED.") }));

            var mockAgent = new ChatClientAgent(mockClient.Object, "TestPrimary", "Test Prompt");

            var engine = new EvolutionaryRepairEngine(maxRetries: 2);
            var config = new QualityGateConfig { RequireBuildPass = true };

            var result = await engine.RunWithAutoHealingAsync(mockClient.Object, mockAgent, new[] { new ChatMessage(ChatRole.User, "Do work") }, config, "CodePhase");

            Assert.Contains("[EVOLUTIONARY REPAIR HALTED]", result);
            Assert.Contains("Failed to resolve Quality Gate findings after 2 attempts", result);
            
            // 1 primary + 2 retries = 3 total calls
            mockClient.Verify(c => c.GetResponseAsync(It.IsAny<IList<ChatMessage>>(), It.IsAny<ChatOptions>(), It.IsAny<CancellationToken>()), Times.Exactly(3));
        }
    }
}
