using CodeMigrationAgent.Tools;

namespace CodeMigrationAgent.Tests
{
    public class SmartContextDiscoveryTests : IDisposable
    {
        private readonly string _testDir;

        public SmartContextDiscoveryTests()
        {
            _testDir = Path.Combine(Path.GetTempPath(), $"discovery-test-{Guid.NewGuid():N}");
            Directory.CreateDirectory(_testDir);

            // Create test files
            File.WriteAllText(Path.Combine(_testDir, "Program.cs"), "class Program { static void Main() {} }");
            File.WriteAllText(Path.Combine(_testDir, "Utils.cs"), "class Utils { static void Helper() {} }");
            File.WriteAllText(Path.Combine(_testDir, "README.md"), "# Test Project\n\nThis is a test.\n\n[Program](./Program.cs)\n[Utils](./Utils.cs)");
            
            var subDir = Path.Combine(_testDir, "Models");
            Directory.CreateDirectory(subDir);
            File.WriteAllText(Path.Combine(subDir, "User.cs"), "class User { string Name; }");
        }

        public void Dispose()
        {
            if (Directory.Exists(_testDir))
                Directory.Delete(_testDir, true);
        }

        [Fact]
        public async Task FullLoad_FindsAllMatchingFiles()
        {
            var result = await SmartContextDiscovery.DiscoverContext(_testDir, "*.cs", "FullLoad");

            Assert.Contains("FULL_LOAD", result);
            Assert.Contains("Program.cs", result);
            Assert.Contains("Utils.cs", result);
            Assert.Contains("User.cs", result);
            Assert.Contains("class Program", result); // Contains file content
        }

        [Fact]
        public async Task FullLoad_RespectsMaxFiles()
        {
            var result = await SmartContextDiscovery.DiscoverContext(_testDir, "*.cs", "FullLoad", maxFiles: 1);

            Assert.Contains("FULL_LOAD", result);
            // Should contain only 1 file (alphabetically first)
            Assert.Contains("Found 1 files", result);
        }

        [Fact]
        public async Task SelectiveLoad_LoadsFirstMatch()
        {
            var result = await SmartContextDiscovery.DiscoverContext(_testDir, "Program.cs", "SelectiveLoad");

            Assert.Contains("SELECTIVE_LOAD", result);
            Assert.Contains("Program.cs", result);
            Assert.Contains("class Program", result);
        }

        [Fact]
        public async Task IndexGuided_UsesReadmeAsIndex()
        {
            var result = await SmartContextDiscovery.DiscoverContext(_testDir, "*.cs", "IndexGuided");

            Assert.Contains("INDEX_GUIDED", result);
            Assert.Contains("README.md", result);
            Assert.Contains("linked files", result);
        }

        [Fact]
        public async Task FullLoad_ReturnsErrorForMissingDirectory()
        {
            var result = await SmartContextDiscovery.DiscoverContext(@"C:\nonexistent\path", "*.cs");

            Assert.Contains("Directory not found", result);
        }

        [Fact]
        public async Task FullLoad_ReturnsEmptyForNoMatches()
        {
            var result = await SmartContextDiscovery.DiscoverContext(_testDir, "*.xyz", "FullLoad");

            Assert.Contains("No files found", result);
        }

        [Fact]
        public async Task IndexGuided_FallsBackToFullLoadWhenNoIndex()
        {
            // Create a directory without any index files
            var noIndexDir = Path.Combine(_testDir, "no-index");
            Directory.CreateDirectory(noIndexDir);
            File.WriteAllText(Path.Combine(noIndexDir, "file.cs"), "test");

            var result = await SmartContextDiscovery.DiscoverContext(noIndexDir, "*.cs", "IndexGuided");

            Assert.Contains("falling back to FULL_LOAD", result);
        }

        [Fact]
        public async Task FullLoad_TruncatesLargeFiles()
        {
            var largeContent = new string('x', 15000); // > 10k limit
            File.WriteAllText(Path.Combine(_testDir, "Large.cs"), largeContent);

            var result = await SmartContextDiscovery.DiscoverContext(_testDir, "Large.cs", "FullLoad");

            Assert.Contains("TRUNCATED", result);
        }
    }
}
