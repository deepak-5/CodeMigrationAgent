using CodeMigrationAgent.Middlewares;
using CodeMigrationAgent.Models;

namespace CodeMigrationAgent.Tests
{
    public class QualityGateMiddlewareTests
    {
        [Fact]
        public void Evaluate_DetectsBuildFailure()
        {
            var config = new QualityGateConfig { RequireBuildPass = true };
            var output = "The operation completed.\nBuild FAILED.\n1 Error(s)";

            var result = QualityGateMiddleware.Evaluate(output, config, "coder");

            Assert.False(result.Passed);
            Assert.Contains(result.Findings, f => f.Category == "Build" && f.Severity == HaltSeverity.Critical);
        }

        [Fact]
        public void Evaluate_PassesCleanBuild()
        {
            var config = new QualityGateConfig { RequireBuildPass = true };
            var output = "Build succeeded. 0 Errors, 0 Warnings.";

            var result = QualityGateMiddleware.Evaluate(output, config, "coder");

            Assert.True(result.Passed);
            Assert.Empty(result.Findings.Where(f => f.Severity >= HaltSeverity.Error));
        }

        [Fact]
        public void Evaluate_DetectsSecurityConcerns()
        {
            var config = new QualityGateConfig();
            var output = "Found a hardcoded secret in appsettings.json";

            var result = QualityGateMiddleware.Evaluate(output, config, "reviewer");

            Assert.False(result.Passed);
            Assert.Contains(result.Findings, f => f.Category == "Security");
        }

        [Fact]
        public void Evaluate_DetectsZeroFindingsInReview()
        {
            var config = new QualityGateConfig();
            var output = "Everything looks great! No problems detected."; // No "Finding" or "Issue" words

            var result = QualityGateMiddleware.Evaluate(output, config, "adversarial-review");

            Assert.Contains(result.Findings, f =>
                f.Category == "Review" && f.Description.Contains("Zero findings"));
        }

        [Fact]
        public void Evaluate_DoesNotFlagZeroFindingsForNonReviewPhases()
        {
            var config = new QualityGateConfig();
            var output = "Code changes applied successfully.";

            var result = QualityGateMiddleware.Evaluate(output, config, "coder");

            Assert.DoesNotContain(result.Findings, f => f.Category == "Review");
        }

        [Fact]
        public void Evaluate_TriggersCustomHaltConditions()
        {
            var config = new QualityGateConfig
            {
                CustomHaltConditions = new() { "CRITICAL_FAILURE", "DATA_CORRUPTION" }
            };
            var output = "Detected potential DATA_CORRUPTION in migration output";

            var result = QualityGateMiddleware.Evaluate(output, config, "migration");

            Assert.False(result.Passed);
            Assert.Contains(result.Findings, f => f.Category == "Custom");
        }

        [Fact]
        public void Evaluate_RespectsMaxAllowedIssues()
        {
            var config = new QualityGateConfig
            {
                MaxAllowedIssues = 2,
                CustomHaltConditions = new() { "warning-a", "warning-b" }
            };
            var output = "Found warning-a and warning-b in the output";

            var result = QualityGateMiddleware.Evaluate(output, config, "test");

            Assert.True(result.Passed); // 2 issues <= MaxAllowedIssues of 2
        }

        [Fact]
        public void Evaluate_FailsWhenExceedingMaxAllowedIssues()
        {
            var config = new QualityGateConfig
            {
                MaxAllowedIssues = 0,
                CustomHaltConditions = new() { "problem" }
            };
            var output = "There is a problem here";

            var result = QualityGateMiddleware.Evaluate(output, config, "test");

            Assert.False(result.Passed); // 1 issue > MaxAllowedIssues of 0
        }

        [Fact]
        public void Evaluate_DisabledGateAlwaysPasses()
        {
            var config = new QualityGateConfig { Enabled = false, RequireBuildPass = true };
            var output = "Build FAILED.";

            // Even though there's a build failure, the gate evaluation still works
            // (the Enabled check is in the middleware, not in Evaluate)
            var result = QualityGateMiddleware.Evaluate(output, config, "test");

            // Evaluate doesn't check Enabled — that's the middleware's responsibility
            Assert.False(result.Passed);
        }
    }
}
