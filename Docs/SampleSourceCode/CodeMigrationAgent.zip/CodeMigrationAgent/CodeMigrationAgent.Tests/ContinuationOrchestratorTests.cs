using CodeMigrationAgent.Models;
using CodeMigrationAgent.Workflows;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using Moq;

namespace CodeMigrationAgent.Tests
{
    public class ContinuationOrchestratorTests
    {
        [Fact]
        public async Task RunWithContinuationAsync_CompletesInSingleIteration()
        {
            // Arrange
            var mockClient = new Mock<IChatClient>();
            var response = new ChatResponse(new List<ChatMessage>
            {
                new ChatMessage(ChatRole.Assistant, "Migration plan complete.")
            });

            mockClient.Setup(c => c.GetResponseAsync(
                It.IsAny<IEnumerable<ChatMessage>>(),
                It.IsAny<ChatOptions?>(),
                It.IsAny<CancellationToken>()))
                .ReturnsAsync(response);

            var orchestrator = new ContinuationOrchestrator(
                mockClient.Object,
                tracker =>
                {
                    return tracker
                        .AsBuilder()
                        .Build()
                        .AsAIAgent(new ChatClientAgentOptions { Name = "TestAgent" });
                },
                maxTokensPerAgent: 200_000);

            // Act
            var result = await orchestrator.RunWithContinuationAsync(
                new[] { new ChatMessage(ChatRole.User, "Migrate this codebase.") });

            // Assert
            Assert.NotEmpty(result.Messages);
            Assert.Contains(result.Messages, m => m.Text!.Contains("Migration plan complete"));
        }

        [Fact]
        public async Task RunWithContinuationAsync_ContinuesOnBudgetExhaustion()
        {
            // Arrange
            var callCount = 0;
            var mockClient = new Mock<IChatClient>();

            mockClient.Setup(c => c.GetResponseAsync(
                It.IsAny<IEnumerable<ChatMessage>>(),
                It.IsAny<ChatOptions?>(),
                It.IsAny<CancellationToken>()))
                .Returns<IEnumerable<ChatMessage>, ChatOptions?, CancellationToken>((msgs, opts, ct) =>
                {
                    callCount++;
                    if (callCount == 1)
                    {
                        // First call: simulate exhaustion by returning a large response
                        // that pushes a tiny budget over the limit
                        return Task.FromResult(new ChatResponse(new List<ChatMessage>
                        {
                            new ChatMessage(ChatRole.Assistant, new string('x', 4000)) // 1000 tokens
                        }));
                    }
                    // Second call: success
                    return Task.FromResult(new ChatResponse(new List<ChatMessage>
                    {
                        new ChatMessage(ChatRole.Assistant, "Continuation complete.")
                    }));
                });

            var orchestrator = new ContinuationOrchestrator(
                mockClient.Object,
                tracker =>
                {
                    return tracker
                        .AsBuilder()
                        .Build()
                        .AsAIAgent(new ChatClientAgentOptions { Name = "TestAgent" });
                },
                maxTokensPerAgent: 500, // Very small budget - will exhaust on first call
                maxContinuations: 3);

            // Act
            var result = await orchestrator.RunWithContinuationAsync(
                new[] { new ChatMessage(ChatRole.User, "Test") });

            // Assert — should have more than one iteration
            Assert.True(callCount >= 2, $"Expected at least 2 calls but got {callCount}");
        }

        [Fact]
        public async Task RunWithContinuationAsync_RespectsMaxContinuationsLimit()
        {
            // Arrange
            var mockClient = new Mock<IChatClient>();

            // Always return a huge response to exhaust tiny budget every time
            mockClient.Setup(c => c.GetResponseAsync(
                It.IsAny<IEnumerable<ChatMessage>>(),
                It.IsAny<ChatOptions?>(),
                It.IsAny<CancellationToken>()))
                .ReturnsAsync(new ChatResponse(new List<ChatMessage>
                {
                    new ChatMessage(ChatRole.Assistant, new string('x', 4000))
                }));

            var maxContinuations = 2;
            var orchestrator = new ContinuationOrchestrator(
                mockClient.Object,
                tracker =>
                {
                    return tracker
                        .AsBuilder()
                        .Build()
                        .AsAIAgent(new ChatClientAgentOptions { Name = "TestAgent" });
                },
                maxTokensPerAgent: 100, // Tiny budget
                maxContinuations: maxContinuations);

            // Act
            var result = await orchestrator.RunWithContinuationAsync(
                new[] { new ChatMessage(ChatRole.User, "Test") });

            // Assert — should have a "max continuations reached" message
            Assert.Contains(result.Messages,
                m => m.Text != null && m.Text.Contains("max continuation limit"));
        }
    }
}
