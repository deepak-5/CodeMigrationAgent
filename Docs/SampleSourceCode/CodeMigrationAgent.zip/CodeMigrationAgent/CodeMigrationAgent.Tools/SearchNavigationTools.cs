using System.ComponentModel;
using System.Diagnostics;

namespace CodeMigrationAgent.Tools
{
    /// <summary>
    /// Navigation and search tools — list directories, find files by glob, get git changes.
    /// </summary>
    public static class SearchNavigationTools
    {
        [Description("Lists all files and directories at the given path with metadata (type, size, last modified).")]
        public static Task<string> ListDirectory(
            [Description("Absolute path of the directory to list.")] string path)
        {
            try
            {
                if (!ToolSafety.IsPathAllowed(path, out var safePath, out var accessError))
                    return Task.FromResult(accessError);

                if (!Directory.Exists(safePath))
                    return Task.FromResult($"[ERROR] Directory not found: {safePath}");

                var entries = new List<string>();
                foreach (var dir in Directory.GetDirectories(safePath))
                {
                    var info = new DirectoryInfo(dir);
                    var childCount = 0;
                    try { childCount = Directory.GetFileSystemEntries(dir).Length; } catch { }
                    entries.Add($"[DIR]  {info.Name}/ ({childCount} items)");
                }
                foreach (var file in Directory.GetFiles(safePath))
                {
                    var info = new FileInfo(file);
                    entries.Add($"[FILE] {info.Name} ({FormatSize(info.Length)}) modified {info.LastWriteTimeUtc:yyyy-MM-dd HH:mm}");
                }

                return Task.FromResult(entries.Count > 0
                    ? $"Contents of {safePath}:\n" + string.Join("\n", entries)
                    : $"Directory {safePath} is empty.");
            }
            catch (Exception ex)
            {
                return Task.FromResult($"[ERROR] Cannot list directory: {ex.Message}");
            }
        }

        [Description("Searches for files matching a glob pattern in a directory tree. Returns matching file paths.")]
        public static Task<string> FileSearch(
            [Description("The glob pattern to match (e.g., '*.cs', '*Controller*').")] string pattern,
            [Description("The root directory to search in.")] string directory)
        {
            try
            {
                if (!ToolSafety.IsPathAllowed(directory, out var safeDirectory, out var accessError))
                    return Task.FromResult(accessError);

                var files = Directory.GetFiles(safeDirectory, pattern, SearchOption.AllDirectories)
                    .Where(f => !f.Contains("\\bin\\") && !f.Contains("\\obj\\") && !f.Contains("\\.git\\"))
                    .Take(50)
                    .ToList();

                return Task.FromResult(files.Count > 0
                    ? $"Found {files.Count} files:\n" + string.Join("\n", files)
                    : $"No files matching '{pattern}' in {safeDirectory}");
            }
            catch (Exception ex)
            {
                return Task.FromResult($"[ERROR] File search failed: {ex.Message}");
            }
        }

        [Description("Gets a summary of uncommitted changes in the git repository (equivalent to 'git status' + 'git diff --stat').")]
        public static async Task<string> GetChanges(
            [Description("The root directory of the git repository.")] string directory)
        {
            try
            {
                if (!ToolSafety.IsPathAllowed(directory, out var safeDirectory, out var accessError))
                    return accessError;

                var statusResult = await RunGitCommand("status --porcelain", safeDirectory);
                var diffResult = await RunGitCommand("diff --stat", safeDirectory);

                var output = "[Git Status]\n" + (string.IsNullOrWhiteSpace(statusResult) ? "No changes." : statusResult);
                output += "\n\n[Git Diff Stats]\n" + (string.IsNullOrWhiteSpace(diffResult) ? "No diffs." : diffResult);
                return output;
            }
            catch (Exception ex)
            {
                return $"[ERROR] Git command failed: {ex.Message}";
            }
        }

        private static async Task<string> RunGitCommand(string args, string cwd)
        {
            var psi = new ProcessStartInfo
            {
                FileName = "git",
                Arguments = args,
                WorkingDirectory = cwd,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };
            using var process = Process.Start(psi)!;
            var output = await process.StandardOutput.ReadToEndAsync();
            await process.WaitForExitAsync();
            return output.Length > 4000 ? output[..4000] + "\n... [truncated]" : output;
        }

        private static string FormatSize(long bytes) => bytes switch
        {
            < 1024 => $"{bytes}B",
            < 1024 * 1024 => $"{bytes / 1024.0:F1}KB",
            _ => $"{bytes / (1024.0 * 1024):F1}MB"
        };
    }
}
