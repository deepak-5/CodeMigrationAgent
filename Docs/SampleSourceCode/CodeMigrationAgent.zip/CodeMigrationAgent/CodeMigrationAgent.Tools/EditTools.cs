using System.ComponentModel;

namespace CodeMigrationAgent.Tools
{
    /// <summary>
    /// Surgical file editing tools — line-range edits, file creation, directory creation.
    /// </summary>
    public static class EditTools
    {
        [Description("Edits specific lines of a file by replacing content between startLine and endLine (1-indexed, inclusive). Use this for surgical modifications.")]
        public static async Task<string> EditFiles(
            [Description("Absolute path of the file to edit.")] string filePath,
            [Description("The 1-indexed start line to replace from.")] int startLine,
            [Description("The 1-indexed end line to replace to (inclusive).")] int endLine,
            [Description("The new content to insert in place of the old lines.")] string newContent)
        {
            try
            {
                if (!ToolSafety.IsPathAllowed(filePath, out var safePath, out var accessError))
                    return accessError;

                if (!File.Exists(safePath))
                    return $"[ERROR] File not found: {safePath}";

                var lines = (await File.ReadAllLinesAsync(safePath)).ToList();

                if (startLine < 1 || endLine > lines.Count || startLine > endLine)
                    return $"[ERROR] Invalid line range [{startLine}-{endLine}]. File has {lines.Count} lines.";

                var newLines = newContent.Split('\n').Select(l => l.TrimEnd('\r')).ToArray();

                lines.RemoveRange(startLine - 1, endLine - startLine + 1);
                lines.InsertRange(startLine - 1, newLines);

                await File.WriteAllLinesAsync(safePath, lines);
                return $"Successfully edited {safePath} lines {startLine}-{endLine}. File now has {lines.Count} lines.";
            }
            catch (Exception ex)
            {
                return $"[ERROR] Edit failed: {ex.Message}";
            }
        }

        [Description("Creates a new file with the given content. Creates parent directories if needed.")]
        public static async Task<string> CreateFile(
            [Description("Absolute path for the new file.")] string filePath,
            [Description("The full content of the file.")] string content)
        {
            try
            {
                if (!ToolSafety.IsPathAllowed(filePath, out var safePath, out var accessError))
                    return accessError;

                var dir = Path.GetDirectoryName(safePath);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                    Directory.CreateDirectory(dir);

                await File.WriteAllTextAsync(safePath, content);
                return $"Successfully created {safePath} ({content.Length} chars)";
            }
            catch (Exception ex)
            {
                return $"[ERROR] Create failed: {ex.Message}";
            }
        }

        [Description("Creates a new directory. Creates parent directories if needed.")]
        public static Task<string> CreateDirectory(
            [Description("Absolute path of the directory to create.")] string path)
        {
            try
            {
                if (!ToolSafety.IsPathAllowed(path, out var safePath, out var accessError))
                    return Task.FromResult(accessError);

                Directory.CreateDirectory(safePath);
                return Task.FromResult($"Successfully created directory: {safePath}");
            }
            catch (Exception ex)
            {
                return Task.FromResult($"[ERROR] Directory creation failed: {ex.Message}");
            }
        }
    }
}
