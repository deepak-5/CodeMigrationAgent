using System.ComponentModel;
using System.Diagnostics;
using Microsoft.Extensions.AI;
using ModelContextProtocol;
using ModelContextProtocol.Client;

namespace CodeMigrationAgent.Tools
{
    /// <summary>
    /// MCP Tool Provider — connects to MCP-compatible servers via stdio transport
    /// and retrieves tool definitions that can be registered with agents.
    /// Uses Process-based stdio communication for maximum compatibility with
    /// the ModelContextProtocol v1.0.0 package which uses DI-based client APIs.
    /// 
    /// This provider wraps external MCP server processes and creates AIFunction tools
    /// that proxy calls through to the MCP server via JSON-RPC over stdio.
    /// </summary>
    public class McpToolProvider : IAsyncDisposable
    {
        private readonly List<IAsyncDisposable> _clients = new();

        /// <summary>
        /// Connects to an MCP server via stdio and returns tools converted into AIFunctions.
        /// </summary>
        public async Task<IList<AITool>> ConnectAndGetToolsAsync(
            string serverName,
            string command,
            string[] args,
            Dictionary<string, string>? environmentVariables = null)
        {
            try
            {
                Console.WriteLine($"[McpToolProvider] 🔌 Connecting to MCP server '{serverName}' via {command} {string.Join(" ", args)}...");

                var transportOptions = new StdioClientTransportOptions
                {
                    Command = command,
                    Arguments = args
                };

                if (environmentVariables != null)
                {
                    transportOptions.EnvironmentVariables ??= new Dictionary<string, string?>();
                    foreach (var kvp in environmentVariables)
                    {
                        transportOptions.EnvironmentVariables[kvp.Key] = kvp.Value;
                    }
                }

                // Official framework pattern from docs
                var mcpClient = await McpClient.CreateAsync(new StdioClientTransport(transportOptions));
                _clients.Add(mcpClient);

                // Retrieve the list of tools available on the server
                var mcpTools = await mcpClient.ListToolsAsync().ConfigureAwait(false);
                
                Console.WriteLine($"[McpToolProvider] ✅ Connected to '{serverName}' — {mcpTools.Count()} tools registered.");
                
                // Return them casted properly so the agents can use them
                return mcpTools.Cast<AITool>().ToList();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[McpToolProvider] ⚠️ Failed to connect to '{serverName}': {ex.Message}");
                return new List<AITool>();
            }
        }

        /// <summary>
        /// Connects to multiple MCP servers from configuration and returns all tools.
        /// </summary>
        public async Task<IList<AITool>> ConnectFromConfigAsync(McpServerConfig[] servers)
        {
            var allTools = new List<AITool>();

            foreach (var server in servers)
            {
                if (!server.Enabled)
                {
                    Console.WriteLine($"[McpToolProvider] ⏩ Skipping disabled server: {server.Name}");
                    continue;
                }

                var tools = await ConnectAndGetToolsAsync(
                    server.Name,
                    server.Command,
                    server.Args,
                    server.EnvironmentVariables);

                allTools.AddRange(tools);
            }

            Console.WriteLine($"[McpToolProvider] 📦 Total MCP tools loaded: {allTools.Count}");
            return allTools;
        }

        public async ValueTask DisposeAsync()
        {
            foreach (var client in _clients)
            {
                try
                {
                    await client.DisposeAsync();
                }
                catch { /* best effort cleanup */ }
            }
            _clients.Clear();
        }
    }

    /// <summary>
    /// Configuration model for an MCP server connection.
    /// </summary>
    public class McpServerConfig
    {
        public string Name { get; set; } = string.Empty;
        public string Command { get; set; } = "npx";
        public string[] Args { get; set; } = Array.Empty<string>();
        public Dictionary<string, string>? EnvironmentVariables { get; set; }
        public bool Enabled { get; set; } = true;
    }
}
