using System.ComponentModel;
using CodeMigrationAgent.Models;
using Microsoft.Extensions.AI;

namespace CodeMigrationAgent.Tools
{
    /// <summary>
    /// BMAD-inspired Smart Context Discovery Tool.
    /// Implements BMAD's discover_inputs protocol with three loading strategies:
    ///
    /// - FULL_LOAD: Load ALL files in directory (architecture docs, PRDs)
    /// - SELECTIVE_LOAD: Load specific file matching a template variable
    /// - INDEX_GUIDED: Load index → analyze → intelligently load relevant docs
    ///
    /// BMAD mandate: "DO NOT BE LAZY — use best judgment to load documents that
    /// might have relevant information, even if only a 5% chance."
    /// </summary>
    public static class SmartContextDiscovery
    {
        /// <summary>
        /// Discovers and loads relevant context files using smart strategies.
        /// Use this to intelligently gather codebase context before analysis or planning.
        /// </summary>
        [Description("Smart context discovery — load relevant project files using FULL_LOAD, SELECTIVE_LOAD, or INDEX_GUIDED strategies. " +
                     "Use FULL_LOAD to get all files in a directory, SELECTIVE_LOAD to get a specific matching file, " +
                     "or INDEX_GUIDED to intelligently select files based on an index/readme.")]
        public static async Task<string> DiscoverContext(
            [Description("Root directory to search from")] string rootDirectory,
            [Description("File pattern to match (e.g., '*.cs', '*architecture*', '*.md')")] string pattern,
            [Description("Loading strategy: FullLoad, SelectiveLoad, or IndexGuided")] string strategy = "FullLoad",
            [Description("Max files to load (prevents context overflow)")] int maxFiles = 20)
        {
            if (!Directory.Exists(rootDirectory))
                return $"❌ Directory not found: {rootDirectory}";

            var loadStrategy = Enum.TryParse<ContextLoadStrategy>(strategy, true, out var parsed)
                ? parsed
                : ContextLoadStrategy.FullLoad;

            return loadStrategy switch
            {
                ContextLoadStrategy.FullLoad => await FullLoadAsync(rootDirectory, pattern, maxFiles),
                ContextLoadStrategy.SelectiveLoad => await SelectiveLoadAsync(rootDirectory, pattern),
                ContextLoadStrategy.IndexGuided => await IndexGuidedLoadAsync(rootDirectory, pattern, maxFiles),
                _ => await FullLoadAsync(rootDirectory, pattern, maxFiles)
            };
        }

        /// <summary>
        /// FULL_LOAD: Load ALL files matching pattern — used for architecture docs, comprehensive analysis.
        /// BMAD: "Load EVERY matching file completely. Concatenate in logical order."
        /// </summary>
        private static async Task<string> FullLoadAsync(string rootDir, string pattern, int maxFiles)
        {
            var files = Directory.GetFiles(rootDir, pattern, SearchOption.AllDirectories)
                .OrderBy(f => Path.GetFileName(f))
                .Take(maxFiles)
                .ToList();

            if (files.Count == 0)
                return $"○ No files found matching '{pattern}' in {rootDir}";

            var sb = new System.Text.StringBuilder();
            sb.AppendLine($"✓ FULL_LOAD: Found {files.Count} files matching '{pattern}'");
            sb.AppendLine();

            foreach (var file in files)
            {
                var relativePath = Path.GetRelativePath(rootDir, file);
                sb.AppendLine($"--- {relativePath} ---");
                try
                {
                    var content = await File.ReadAllTextAsync(file);
                    // Truncate very large files to prevent context overflow
                    if (content.Length > 10_000)
                    {
                        sb.AppendLine(content[..10_000]);
                        sb.AppendLine($"... [TRUNCATED - {content.Length} total chars]");
                    }
                    else
                    {
                        sb.AppendLine(content);
                    }
                }
                catch (Exception ex)
                {
                    sb.AppendLine($"[Error reading file: {ex.Message}]");
                }
                sb.AppendLine();
            }

            return sb.ToString();
        }

        /// <summary>
        /// SELECTIVE_LOAD: Load specific file matching pattern — used for targeted analysis.
        /// BMAD: "Resolve template to specific file path. Load that specific file."
        /// </summary>
        private static async Task<string> SelectiveLoadAsync(string rootDir, string pattern)
        {
            var files = Directory.GetFiles(rootDir, pattern, SearchOption.AllDirectories);

            if (files.Length == 0)
                return $"○ No files found matching '{pattern}' in {rootDir}";

            // Take the first match (most specific)
            var file = files[0];
            var relativePath = Path.GetRelativePath(rootDir, file);

            try
            {
                var content = await File.ReadAllTextAsync(file);
                return $"✓ SELECTIVE_LOAD: Loaded '{relativePath}'\n\n{content}";
            }
            catch (Exception ex)
            {
                return $"❌ Error reading '{relativePath}': {ex.Message}";
            }
        }

        /// <summary>
        /// INDEX_GUIDED: Load index → analyze → intelligently load relevant docs.
        /// BMAD mandate: "DO NOT BE LAZY — load documents that might have relevant info, even 5% chance."
        /// </summary>
        private static async Task<string> IndexGuidedLoadAsync(string rootDir, string pattern, int maxFiles)
        {
            // Look for index files first
            var indexFiles = new[] { "index.md", "README.md", "readme.md", "INDEX.md", "TOC.md" };
            string? indexFile = null;

            foreach (var idx in indexFiles)
            {
                var candidate = Path.Combine(rootDir, idx);
                if (File.Exists(candidate))
                {
                    indexFile = candidate;
                    break;
                }
            }

            var sb = new System.Text.StringBuilder();

            if (indexFile != null)
            {
                sb.AppendLine($"✓ INDEX_GUIDED: Found index file '{Path.GetFileName(indexFile)}'");
                var indexContent = await File.ReadAllTextAsync(indexFile);
                sb.AppendLine("--- INDEX CONTENT ---");
                sb.AppendLine(indexContent);
                sb.AppendLine("--- END INDEX ---");
                sb.AppendLine();

                // Extract linked files from the index
                var linkedFiles = ExtractLinkedFiles(indexContent, rootDir);
                sb.AppendLine($"📎 Found {linkedFiles.Count} linked files in index");
                sb.AppendLine();

                // Load linked files that match the pattern
                var loaded = 0;
                foreach (var linked in linkedFiles.Take(maxFiles))
                {
                    if (File.Exists(linked))
                    {
                        var relativePath = Path.GetRelativePath(rootDir, linked);
                        sb.AppendLine($"--- {relativePath} ---");
                        var content = await File.ReadAllTextAsync(linked);
                        if (content.Length > 8_000)
                        {
                            sb.AppendLine(content[..8_000]);
                            sb.AppendLine($"... [TRUNCATED - {content.Length} total chars]");
                        }
                        else
                        {
                            sb.AppendLine(content);
                        }
                        sb.AppendLine();
                        loaded++;
                    }
                }

                sb.AppendLine($"✓ Loaded {loaded} linked documents");
            }
            else
            {
                // No index found — fall back to FULL_LOAD
                sb.AppendLine("⚠️ No index file found — falling back to FULL_LOAD strategy");
                sb.AppendLine(await FullLoadAsync(rootDir, pattern, maxFiles));
            }

            return sb.ToString();
        }

        /// <summary>
        /// Extracts file references from markdown index content.
        /// Looks for markdown links: [text](./path/to/file.md)
        /// </summary>
        private static List<string> ExtractLinkedFiles(string indexContent, string rootDir)
        {
            var files = new List<string>();
            var linkPattern = new System.Text.RegularExpressions.Regex(@"\[.*?\]\((\.?/?[^\)]+)\)");
            var matches = linkPattern.Matches(indexContent);

            foreach (System.Text.RegularExpressions.Match match in matches)
            {
                var linkPath = match.Groups[1].Value.Trim();
                // Skip external URLs
                if (linkPath.StartsWith("http://") || linkPath.StartsWith("https://"))
                    continue;

                var fullPath = Path.GetFullPath(Path.Combine(rootDir, linkPath));
                if (File.Exists(fullPath))
                    files.Add(fullPath);
            }

            return files.Distinct().ToList();
        }
    }
}
