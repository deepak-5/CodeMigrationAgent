using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace CodeMigrationAgent.Tools
{
    /// <summary>
    /// RAG (Retrieval-Augmented Generation) provider that wraps the existing
    /// CodeSearchTools as a search adapter compatible with the Microsoft Agent Framework's
    /// TextSearchProvider pattern.
    ///
    /// Returns search results with file paths as source links so agents can
    /// cite their sources when answering questions about the codebase.
    /// </summary>
    public static class CodebaseRagProvider
    {
        /// <summary>
        /// Search adapter function that queries the codebase and returns
        /// TextSearchResult-compatible results with source information.
        /// </summary>
        [Description("Search the local codebase for relevant code context. Returns matching code snippets with file paths.")]
        public static async Task<IEnumerable<CodebaseSearchResult>> SearchCodebaseForRag(
            [Description("The search query to find relevant code")] string query,
            [Description("The workspace root path to search in")] string workspacePath = ".")
        {
            var results = new List<CodebaseSearchResult>();

            try
            {
                // Use existing CodeSearchTools to get raw search results
                var searchOutput = await CodeSearchTools.SearchCodebase(query, workspacePath);

                if (string.IsNullOrWhiteSpace(searchOutput))
                    return results;

                // Parse the search output into structured results
                var lines = searchOutput.Split('\n', StringSplitOptions.RemoveEmptyEntries);
                var currentFile = "";
                var currentSnippet = new List<string>();

                foreach (var line in lines)
                {
                    // Lines typically follow pattern: "filepath:linenum:content"
                    var colonIndex = line.IndexOf(':');
                    var secondColon = colonIndex >= 0 ? line.IndexOf(':', colonIndex + 1) : -1;

                    if (colonIndex > 0 && secondColon > colonIndex)
                    {
                        var filePath = line[..colonIndex].Trim();

                        if (filePath != currentFile && currentSnippet.Count > 0)
                        {
                            // Flush previous file's snippets
                            results.Add(new CodebaseSearchResult
                            {
                                SourceName = System.IO.Path.GetFileName(currentFile),
                                SourceLink = currentFile,
                                Text = string.Join("\n", currentSnippet.Take(20)) // Cap at 20 lines per file
                            });
                            currentSnippet.Clear();
                        }

                        currentFile = filePath;
                        currentSnippet.Add(line);
                    }
                    else
                    {
                        currentSnippet.Add(line);
                    }
                }

                // Flush the last file
                if (currentSnippet.Count > 0 && !string.IsNullOrEmpty(currentFile))
                {
                    results.Add(new CodebaseSearchResult
                    {
                        SourceName = System.IO.Path.GetFileName(currentFile),
                        SourceLink = currentFile,
                        Text = string.Join("\n", currentSnippet.Take(20))
                    });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[CodebaseRag] ⚠️ Search failed: {ex.Message}");
            }

            return results.Take(10); // Limit to top 10 results to avoid context overflow
        }
    }

    /// <summary>
    /// Represents a codebase search result with source metadata for RAG citations.
    /// Mirrors the TextSearchProvider.TextSearchResult pattern from the Agent Framework.
    /// </summary>
    public class CodebaseSearchResult
    {
        /// <summary>Display name of the source file.</summary>
        public string? SourceName { get; set; }

        /// <summary>Full path to the source file.</summary>
        public string? SourceLink { get; set; }

        /// <summary>The matching code text snippet.</summary>
        public string Text { get; set; } = "";
    }
}
