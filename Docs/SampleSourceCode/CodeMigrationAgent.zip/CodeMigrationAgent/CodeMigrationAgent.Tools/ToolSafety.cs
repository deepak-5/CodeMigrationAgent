namespace CodeMigrationAgent.Tools
{
    internal static class ToolSafety
    {
        private const string AllowedRootsEnv = "CMA_ALLOWED_PATH_ROOTS";
        private const string BlockedCommandsEnv = "CMA_BLOCKED_COMMAND_PATTERNS";

        private static readonly Lazy<string[]> AllowedRoots = new(LoadAllowedRoots);
        private static readonly Lazy<string[]> BlockedCommandPatterns = new(LoadBlockedCommandPatterns);

        public static bool TryNormalizePath(string path, out string normalizedPath, out string error)
        {
            normalizedPath = string.Empty;
            error = string.Empty;

            if (string.IsNullOrWhiteSpace(path))
            {
                error = "[ERROR] Path is required.";
                return false;
            }

            try
            {
                normalizedPath = Path.GetFullPath(path);
                return true;
            }
            catch (Exception ex)
            {
                error = $"[ERROR] Invalid path '{path}': {ex.Message}";
                return false;
            }
        }

        public static bool IsPathAllowed(string path, out string normalizedPath, out string error)
        {
            if (!TryNormalizePath(path, out normalizedPath, out error))
            {
                return false;
            }

            var roots = AllowedRoots.Value;
            if (roots.Length == 0)
            {
                error = string.Empty;
                return true;
            }

            var candidatePath = normalizedPath;
            var isAllowed = roots.Any(root =>
                candidatePath.StartsWith(root, StringComparison.OrdinalIgnoreCase));

            if (!isAllowed)
            {
                error = $"[ERROR] Access denied. Path '{normalizedPath}' is outside allowed roots: {string.Join(", ", roots)}";
            }
            else
            {
                error = string.Empty;
            }

            return isAllowed;
        }

        public static bool IsCommandAllowed(string command, out string error)
        {
            if (string.IsNullOrWhiteSpace(command))
            {
                error = "[ERROR] Command cannot be empty.";
                return false;
            }

            var normalized = command.ToLowerInvariant();
            foreach (var blocked in BlockedCommandPatterns.Value)
            {
                if (normalized.Contains(blocked, StringComparison.Ordinal))
                {
                    error = $"[ERROR] Command blocked by safety policy. Matched pattern: '{blocked}'.";
                    return false;
                }
            }

            error = string.Empty;
            return true;
        }

        public static int GetTerminalTimeoutMs()
        {
            var raw = Environment.GetEnvironmentVariable("CMA_TERMINAL_TIMEOUT_MS");
            if (!string.IsNullOrWhiteSpace(raw) &&
                int.TryParse(raw, out var parsed) &&
                parsed >= 1_000 &&
                parsed <= 600_000)
            {
                return parsed;
            }

            return 120_000;
        }

        private static string[] LoadAllowedRoots()
        {
            var raw = Environment.GetEnvironmentVariable(AllowedRootsEnv);
            if (string.IsNullOrWhiteSpace(raw))
            {
                return Array.Empty<string>();
            }

            var segments = raw.Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            var normalized = new List<string>();
            foreach (var segment in segments)
            {
                try
                {
                    normalized.Add(Path.GetFullPath(segment).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) + Path.DirectorySeparatorChar);
                }
                catch
                {
                    // Ignore malformed roots from config.
                }
            }

            return normalized.Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
        }

        private static string[] LoadBlockedCommandPatterns()
        {
            var defaults = new[]
            {
                "rm -rf /",
                "rm -rf ~",
                "format c:",
                "format d:",
                "del /s /q c:",
                "shutdown /s",
                "shutdown -h",
                "mkfs.",
                "dd if=",
                "curl http://169.254.169.254",
                "invoke-webrequest http://169.254.169.254"
            };

            var raw = Environment.GetEnvironmentVariable(BlockedCommandsEnv);
            if (string.IsNullOrWhiteSpace(raw))
            {
                return defaults;
            }

            var custom = raw.Split('|', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Select(x => x.ToLowerInvariant())
                .ToArray();

            return defaults
                .Concat(custom)
                .Distinct(StringComparer.Ordinal)
                .ToArray();
        }
    }
}
