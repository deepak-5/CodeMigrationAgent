using System.Threading.Channels;
using System.Collections.Concurrent;
using Microsoft.Extensions.Logging;
using CodeMigrationAgent.Models;

namespace CodeMigrationAgent.Tools
{
    /// <summary>
    /// SOTA Orchestrator for Dynamic Load Balancing.
    /// Manages a bounded thread-pool of concurrent agents to process massive mono-repos and horizontally scaled tasks.
    /// Uses System.Threading.Channels for high-performance job queueing.
    /// </summary>
    public class ParallelWorkforceOrchestrator
    {
        private readonly Channel<TaskAssignment> _taskChannel;
        private readonly int _maxParallelWorkers;
        private readonly ILogger<ParallelWorkforceOrchestrator>? _logger;
        
        // Maps TaskId -> Completed Result
        private readonly ConcurrentDictionary<string, string> _results = new();
        
        // A cancellation token to shut down workers
        private readonly CancellationTokenSource _cts = new();

        public ParallelWorkforceOrchestrator(int maxParallelWorkers = 8, ILogger<ParallelWorkforceOrchestrator>? logger = null)
        {
            _maxParallelWorkers = maxParallelWorkers;
            _logger = logger;

            // Bounded channel to prevent infinite memory usage if queued faster than processed
            var options = new BoundedChannelOptions(10_000)
            {
                FullMode = BoundedChannelFullMode.Wait
            };
            
            _taskChannel = Channel.CreateBounded<TaskAssignment>(options);
        }

        /// <summary>
        /// Starts the orchestrator background workers. These workers drain the channel dynamically.
        /// </summary>
        public void StartWorkers(Func<TaskAssignment, CancellationToken, Task<string>> taskProcessor)
        {
            _logger?.LogInformation("🚀 [ParallelWorkforce] Starting {Workers} concurrent workers...", _maxParallelWorkers);

            for (int i = 0; i < _maxParallelWorkers; i++)
            {
                var workerId = i + 1;
                Task.Run(() => WorkerLoopAsync(workerId, taskProcessor, _cts.Token), _cts.Token);
            }
        }

        /// <summary>
        /// Enqueues a task directly to the dynamic load balancer.
        /// </summary>
        public async ValueTask EnqueueTaskAsync(TaskAssignment taskAssignment, CancellationToken cancellationToken = default)
        {
            await _taskChannel.Writer.WriteAsync(taskAssignment, cancellationToken);
            _logger?.LogDebug("[ParallelWorkforce] Queued task {TaskId} Priority {Priority}", taskAssignment.TaskId, taskAssignment.Priority);
        }

        /// <summary>
        /// Signals that no more tasks will be enqueued, allowing workers to drain the queue and exit.
        /// Returns a task that completes when all currently queued items are processed.
        /// </summary>
        public async Task WaitUntilDrainedAsync()
        {
            _taskChannel.Writer.Complete();
            await _taskChannel.Reader.Completion;
            _logger?.LogInformation("🏁 [ParallelWorkforce] All tasks drained and completed.");
        }

        /// <summary>
        /// Fetches the results of all completed tasks.
        /// </summary>
        public IReadOnlyDictionary<string, string> GetResults() => _results;

        /// <summary>
        /// Shuts down the orchestrator forcefully, cancelling active jobs.
        /// </summary>
        public void Shutdown()
        {
            _cts.Cancel();
            _taskChannel.Writer.TryComplete();
        }

        private async Task WorkerLoopAsync(int workerId, Func<TaskAssignment, CancellationToken, Task<string>> processor, CancellationToken ct)
        {
            try
            {
                // ChannelReader.ReadAllAsync allows safe asynchronous enumeration of the channel
                await foreach (var task in _taskChannel.Reader.ReadAllAsync(ct))
                {
                    _logger?.LogInformation("[Worker-{Id}] ⚡ Starting Task {TaskId}...", workerId, task.TaskId);
                    
                    try
                    {
                        var result = await processor(task, ct);
                        _results[task.TaskId] = result;
                        _logger?.LogInformation("[Worker-{Id}] ✅ Completed Task {TaskId}.", workerId, task.TaskId);
                    }
                    catch (Exception ex)
                    {
                        _logger?.LogError(ex, "[Worker-{Id}] ❌ Failed Task {TaskId}: {Message}", workerId, task.TaskId, ex.Message);
                        _results[task.TaskId] = $"[FAILED] {ex.Message}";
                    }
                }
            }
            catch (OperationCanceledException)
            {
                _logger?.LogInformation("🛑 [Worker-{Id}] Cancelled.", workerId);
            }
        }
    }
}
