using System.ComponentModel;
using System.IO;
using System.Threading.Tasks;

namespace CodeMigrationAgent.Tools
{
    /// <summary>
    /// File I/O tools — read files (full or partial), write files.
    /// </summary>
    public static class FileSystemTools
    {
        [Description("Reads the entire contents of a file at the specified absolute path.")]
        public static async Task<string> ReadFile(
            [Description("The absolute path of the file to read.")] string filePath)
        {
            try
            {
                if (!ToolSafety.IsPathAllowed(filePath, out var safePath, out var accessError))
                    return accessError;

                if (!File.Exists(safePath))
                    return $"[ERROR] File not found: {safePath}";

                var content = await File.ReadAllTextAsync(safePath);
                return content.Length > 15000
                    ? content[..15000] + $"\n... [truncated, total {content.Length} chars. Use ReadFileLines for specific ranges.]"
                    : content;
            }
            catch (Exception ex)
            {
                return $"[ERROR] Cannot read file: {ex.Message}";
            }
        }

        [Description("Reads specific lines from a file (1-indexed, inclusive). Use this for large files to avoid token waste.")]
        public static async Task<string> ReadFileLines(
            [Description("The absolute path of the file to read.")] string filePath,
            [Description("The starting line number (1-indexed).")] int startLine,
            [Description("The ending line number (1-indexed, inclusive).")] int endLine)
        {
            try
            {
                if (!ToolSafety.IsPathAllowed(filePath, out var safePath, out var accessError))
                    return accessError;

                if (!File.Exists(safePath))
                    return $"[ERROR] File not found: {safePath}";

                var lines = await File.ReadAllLinesAsync(safePath);
                if (startLine < 1) startLine = 1;
                if (endLine > lines.Length) endLine = lines.Length;

                var selected = lines.Skip(startLine - 1).Take(endLine - startLine + 1);
                var numbered = selected.Select((line, idx) => $"{startLine + idx}: {line}");

                return $"File: {safePath} (total {lines.Length} lines)\nShowing lines {startLine}-{endLine}:\n" +
                    string.Join("\n", numbered);
            }
            catch (Exception ex)
            {
                return $"[ERROR] Cannot read file lines: {ex.Message}";
            }
        }

        [Description("Writes content to a file. Creates parent directories if needed. Overwrites existing content.")]
        public static async Task<string> WriteFile(
            [Description("The absolute path to write the file to.")] string filePath,
            [Description("The full contents of the file.")] string contents)
        {
            try
            {
                if (!ToolSafety.IsPathAllowed(filePath, out var safePath, out var accessError))
                    return accessError;

                var directory = Path.GetDirectoryName(safePath);
                if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                    Directory.CreateDirectory(directory);

                await File.WriteAllTextAsync(safePath, contents);
                return $"Successfully wrote {contents.Length} chars to {safePath}";
            }
            catch (Exception ex)
            {
                return $"[ERROR] Write failed: {ex.Message}";
            }
        }
    }
}

