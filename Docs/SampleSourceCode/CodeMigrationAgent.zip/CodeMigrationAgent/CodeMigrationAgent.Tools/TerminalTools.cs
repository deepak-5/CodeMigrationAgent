using System.ComponentModel;
using System.Diagnostics;
using System.Collections.Concurrent;
using System.Text;

namespace CodeMigrationAgent.Tools
{
    /// <summary>
    /// Production-grade terminal execution tools.
    /// Enables agents to run shell commands, read output, and manage processes.
    /// </summary>
    public static class TerminalTools
    {
        private static readonly ConcurrentDictionary<string, Process> RunningProcesses = new();
        private static readonly ConcurrentDictionary<string, TerminalExecution> Executions = new();
        private const int MaxToolOutputLength = 12_000;

        [Description("Executes a shell command in a terminal and returns the output. Use for builds, tests, git operations, etc.")]
        public static async Task<string> RunInTerminal(
            [Description("The command to execute (e.g., 'dotnet build').")] string command,
            [Description("The working directory for the command.")] string workingDirectory = ".")
        {
            var executionId = Guid.NewGuid().ToString("N")[..8];
            try
            {
                if (!ToolSafety.IsCommandAllowed(command, out var commandError))
                    return commandError;

                if (!ToolSafety.IsPathAllowed(workingDirectory, out var safeWorkingDirectory, out var pathError))
                    return pathError;

                var psi = new ProcessStartInfo
                {
                    FileName = OperatingSystem.IsWindows() ? "cmd.exe" : "/bin/bash",
                    Arguments = OperatingSystem.IsWindows() ? $"/c {command}" : $"-c \"{command}\"",
                    WorkingDirectory = safeWorkingDirectory,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                var process = Process.Start(psi);
                if (process is null)
                    return "[ERROR] Failed to start process.";

                RunningProcesses[executionId] = process;
                var execution = new TerminalExecution
                {
                    ExecutionId = executionId,
                    Command = command,
                    WorkingDirectory = safeWorkingDirectory,
                    StartedAtUtc = DateTime.UtcNow
                };
                Executions[executionId] = execution;

                using var timeoutCts = new CancellationTokenSource(ToolSafety.GetTerminalTimeoutMs());
                var stdoutTask = process.StandardOutput.ReadToEndAsync(timeoutCts.Token);
                var stderrTask = process.StandardError.ReadToEndAsync(timeoutCts.Token);

                try
                {
                    await process.WaitForExitAsync(timeoutCts.Token);
                }
                catch (OperationCanceledException)
                {
                    TryKillProcess(process);
                    execution.CompletedAtUtc = DateTime.UtcNow;
                    execution.ExitCode = null;
                    execution.TimedOut = true;
                    execution.StandardError = $"Command timed out after {ToolSafety.GetTerminalTimeoutMs()} ms.";
                    RunningProcesses.TryRemove(executionId, out _);
                    return BuildOutput(execution);
                }

                var stdout = await stdoutTask;
                var stderr = await stderrTask;

                execution.ExitCode = process.ExitCode;
                execution.CompletedAtUtc = DateTime.UtcNow;
                execution.StandardOutput = stdout;
                execution.StandardError = stderr;

                RunningProcesses.TryRemove(executionId, out _);
                return BuildOutput(execution);
            }
            catch (Exception ex)
            {
                RunningProcesses.TryRemove(executionId, out _);
                if (Executions.TryGetValue(executionId, out var execution))
                {
                    execution.CompletedAtUtc = DateTime.UtcNow;
                    execution.StandardError = ex.Message;
                }
                return $"[ERROR] Failed to execute command: {ex.Message}";
            }
        }

        [Description("Gets the output from a running or recently completed terminal process.")]
        public static Task<string> GetTerminalOutput(
            [Description("The process ID to read output from.")] string processId)
        {
            if (string.IsNullOrWhiteSpace(processId))
                return Task.FromResult("[ERROR] Process ID is required.");

            if (RunningProcesses.ContainsKey(processId))
            {
                return Task.FromResult($"[Process {processId}] is still running.");
            }

            if (Executions.TryGetValue(processId, out var execution))
            {
                return Task.FromResult(BuildOutput(execution));
            }

            return Task.FromResult($"[Process {processId}] not found.");
        }

        [Description("Waits for a terminal process to complete within the specified timeout.")]
        public static async Task<string> AwaitTerminal(
            [Description("The process ID to wait for.")] string processId,
            [Description("Maximum time to wait in milliseconds.")] int timeoutMs = 30000)
        {
            if (string.IsNullOrWhiteSpace(processId))
                return "[ERROR] Process ID is required.";

            if (!RunningProcesses.TryGetValue(processId, out var process))
            {
                return Executions.TryGetValue(processId, out var existing)
                    ? BuildOutput(existing)
                    : $"[Process {processId}] not found.";
            }

            using var cts = new CancellationTokenSource(timeoutMs);
            try
            {
                await process.WaitForExitAsync(cts.Token);
            }
            catch (OperationCanceledException)
            {
                return $"[Process {processId}] timed out after {timeoutMs}ms.";
            }

            if (!Executions.TryGetValue(processId, out var execution))
            {
                return $"[Process {processId}] completed.";
            }

            execution.CompletedAtUtc = DateTime.UtcNow;
            execution.ExitCode = process.ExitCode;
            RunningProcesses.TryRemove(processId, out _);
            return BuildOutput(execution);
        }

        [Description("Terminates a running terminal process.")]
        public static Task<string> KillTerminal(
            [Description("The process ID to terminate.")] string processId)
        {
            if (string.IsNullOrWhiteSpace(processId))
                return Task.FromResult("[ERROR] Process ID is required.");

            if (RunningProcesses.TryRemove(processId, out var process) && !process.HasExited)
            {
                TryKillProcess(process);
                if (Executions.TryGetValue(processId, out var execution))
                {
                    execution.CompletedAtUtc = DateTime.UtcNow;
                    execution.ExitCode = -1;
                    execution.StandardError = "Process terminated by KillTerminal.";
                    return Task.FromResult(BuildOutput(execution));
                }

                return Task.FromResult($"[Process {processId}] terminated.");
            }

            return Task.FromResult($"[Process {processId}] not found or already exited.");
        }

        private static string BuildOutput(TerminalExecution execution)
        {
            var sb = new StringBuilder();
            sb.AppendLine($"[ExecutionId] {execution.ExecutionId}");
            sb.AppendLine($"[Command] {execution.Command}");
            sb.AppendLine($"[WorkingDirectory] {execution.WorkingDirectory}");
            if (execution.TimedOut)
            {
                sb.AppendLine("[Timeout] true");
            }
            if (execution.ExitCode.HasValue)
            {
                sb.AppendLine($"[Exit Code] {execution.ExitCode.Value}");
            }
            if (!string.IsNullOrWhiteSpace(execution.StandardOutput))
            {
                sb.AppendLine("[STDOUT]");
                sb.AppendLine(execution.StandardOutput);
            }
            if (!string.IsNullOrWhiteSpace(execution.StandardError))
            {
                sb.AppendLine("[STDERR]");
                sb.AppendLine(execution.StandardError);
            }

            var output = sb.ToString();
            return output.Length > MaxToolOutputLength
                ? output[..MaxToolOutputLength] + "\n... [output truncated]"
                : output;
        }

        private static void TryKillProcess(Process process)
        {
            try
            {
                process.Kill(entireProcessTree: true);
            }
            catch
            {
                // Intentionally swallow kill errors; caller still gets best effort status.
            }
        }

        private sealed class TerminalExecution
        {
            public string ExecutionId { get; init; } = string.Empty;
            public string Command { get; init; } = string.Empty;
            public string WorkingDirectory { get; init; } = string.Empty;
            public DateTime StartedAtUtc { get; init; }
            public DateTime? CompletedAtUtc { get; set; }
            public int? ExitCode { get; set; }
            public bool TimedOut { get; set; }
            public string StandardOutput { get; set; } = string.Empty;
            public string StandardError { get; set; } = string.Empty;
        }
    }
}
