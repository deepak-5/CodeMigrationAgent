using System.ComponentModel;
using System.Collections.Concurrent;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;

namespace CodeMigrationAgent.Tools
{
    /// <summary>
    /// Enhanced Agent Delegation Tools — BMAD-inspired composable agent workflows.
    /// 
    /// Extends the basic delegation pattern with BMAD semantics:
    /// - invoke-workflow: Execute a complete named workflow
    /// - invoke-task: Execute a specific task with typed inputs
    /// - invoke-protocol: Execute a reusable protocol (e.g., discover_inputs)
    ///
    /// BMAD pattern: "invoke-workflow → Execute another workflow with given inputs."
    /// </summary>
    public static class AgentDelegationTools
    {
        // Registry of named agents, populated at startup
        private static readonly ConcurrentDictionary<string, AIAgent> _agentRegistry = new();

        // Registry of named workflows (BMAD: workflow handlers)
        private static readonly ConcurrentDictionary<string, Func<Dictionary<string, string>, Task<string>>> _workflowRegistry = new();

        // Registry of reusable protocols (BMAD: invoke-protocol)
        private static readonly ConcurrentDictionary<string, Func<string, Task<string>>> _protocolRegistry = new();

        public static void RegisterAgent(string name, AIAgent agent) => _agentRegistry[name] = agent;
        public static void RegisterWorkflow(string name, Func<Dictionary<string, string>, Task<string>> workflow) => _workflowRegistry[name] = workflow;
        public static void RegisterProtocol(string name, Func<string, Task<string>> protocol) => _protocolRegistry[name] = protocol;

        [Description("Delegates a task to a named sub-agent (e.g., 'CoderAgent', 'ReviewerAgent'). Returns the sub-agent's response.")]
        public static async Task<string> RunSubAgent(
            [Description("The name of the agent to delegate to (e.g., 'CoderAgent').")] string agentName,
            [Description("A clear description of the task for the sub-agent.")] string taskDescription,
            [Description("Relevant context the sub-agent needs (e.g., file contents, specifications).")] string context = "")
        {
            try
            {
                if (!_agentRegistry.TryGetValue(agentName, out var agent))
                    return $"[ERROR] Agent '{agentName}' not found. Available: {string.Join(", ", _agentRegistry.Keys)}";

                var prompt = $"Task: {taskDescription}";
                if (!string.IsNullOrWhiteSpace(context))
                    prompt += $"\n\nContext:\n{context}";

                var messages = new[] { new ChatMessage(ChatRole.User, prompt) };
                var response = await agent.RunAsync(messages);

                var result = response.Messages.LastOrDefault()?.Text ?? "[No response from sub-agent]";
                return result.Length > 8000 ? result[..8000] + "\n... [truncated]" : result;
            }
            catch (Exception ex)
            {
                return $"[ERROR] Sub-agent '{agentName}' failed: {ex.Message}";
            }
        }

        /// <summary>
        /// BMAD-inspired: Execute a named workflow with input parameters.
        /// BMAD pattern: "invoke-workflow → Execute another workflow with given inputs."
        /// </summary>
        [Description("Execute a named workflow (e.g., 'code-review', 'dev-story', 'sprint-planning'). " +
                     "Workflows are pre-defined multi-step processes that orchestrate multiple agents.")]
        public static async Task<string> InvokeWorkflow(
            [Description("Name of the workflow to execute.")] string workflowName,
            [Description("Input parameters as JSON string (e.g., '{\"target\":\"MyService.cs\"}')")] string inputsJson = "{}")
        {
            try
            {
                if (!_workflowRegistry.TryGetValue(workflowName, out var workflow))
                    return $"[ERROR] Workflow '{workflowName}' not found. Available: {string.Join(", ", _workflowRegistry.Keys)}";

                Dictionary<string, string>? inputs;
                try
                {
                    inputs = System.Text.Json.JsonSerializer.Deserialize<Dictionary<string, string>>(inputsJson)
                        ?? new Dictionary<string, string>();
                }
                catch
                {
                    inputs = new Dictionary<string, string> { ["raw_input"] = inputsJson };
                }

                Console.WriteLine($"[AgentDelegation] 🔄 Invoking workflow: {workflowName}");
                var result = await workflow(inputs);
                return result.Length > 8000 ? result[..8000] + "\n... [truncated]" : result;
            }
            catch (Exception ex)
            {
                return $"[ERROR] Workflow '{workflowName}' failed: {ex.Message}";
            }
        }

        /// <summary>
        /// BMAD-inspired: Execute a specific task with typed inputs.
        /// BMAD pattern: "invoke-task → Execute specified task."
        /// </summary>
        [Description("Execute a specific task with inputs. Tasks are focused operations (e.g., 'adversarial-review', 'context-discovery').")]
        public static async Task<string> InvokeTask(
            [Description("ID of the task to execute.")] string taskId,
            [Description("The content/input to process.")] string content,
            [Description("Additional parameters as JSON.")] string parametersJson = "{}")
        {
            try
            {
                // Check if there's a matching agent for this task
                var agentName = taskId switch
                {
                    "adversarial-review" => "AdversarialReviewerAgent",
                    "code-review" => "ReviewerAgent",
                    "architecture-analysis" => "ArchitectAgent",
                    "code-implementation" => "CoderAgent",
                    _ => null
                };

                if (agentName != null && _agentRegistry.TryGetValue(agentName, out var agent))
                {
                    Console.WriteLine($"[AgentDelegation] ⚡ Invoking task '{taskId}' via agent '{agentName}'");
                    var messages = new[] { new ChatMessage(ChatRole.User, content) };
                    var response = await agent.RunAsync(messages);
                    var result = response.Messages.LastOrDefault()?.Text ?? "[No response]";
                    return result.Length > 8000 ? result[..8000] + "\n... [truncated]" : result;
                }

                return $"[ERROR] Task '{taskId}' not recognized. Available tasks: adversarial-review, code-review, architecture-analysis, code-implementation";
            }
            catch (Exception ex)
            {
                return $"[ERROR] Task '{taskId}' failed: {ex.Message}";
            }
        }

        /// <summary>
        /// BMAD-inspired: Execute a reusable protocol.
        /// BMAD pattern: "invoke-protocol name='discover_inputs' → Execute reusable protocol."
        /// </summary>
        [Description("Execute a reusable protocol (e.g., 'discover-inputs' for smart context loading). " +
                     "Protocols are self-contained operations that can be composed into workflows.")]
        public static async Task<string> InvokeProtocol(
            [Description("Name of the protocol to execute.")] string protocolName,
            [Description("Input context for the protocol.")] string context = "")
        {
            try
            {
                if (_protocolRegistry.TryGetValue(protocolName, out var protocol))
                {
                    Console.WriteLine($"[AgentDelegation] 📋 Invoking protocol: {protocolName}");
                    return await protocol(context);
                }

                // Built-in protocols
                if (protocolName.Equals("discover-inputs", StringComparison.OrdinalIgnoreCase))
                {
                    return await SmartContextDiscovery.DiscoverContext(
                        context, // rootDirectory
                        "*.cs",   // default pattern
                        "IndexGuided");
                }

                return $"[ERROR] Protocol '{protocolName}' not found. Available: {string.Join(", ", _protocolRegistry.Keys)}, discover-inputs (built-in)";
            }
            catch (Exception ex)
            {
                return $"[ERROR] Protocol '{protocolName}' failed: {ex.Message}";
            }
        }

        private static ParallelWorkforceOrchestrator? _orchestrator;

        public static void InitializeOrchestrator(ParallelWorkforceOrchestrator orchestrator)
        {
            _orchestrator = orchestrator;
        }

        [Description("Creates a new task assignment that can be queued for parallel execution.")]
        public static async Task<string> CreateAndRunTask(
            [Description("Description of the task to create.")] string taskDescription,
            [Description("Priority level (0=normal, higher=urgent).")] int priority = 0)
        {
            var assignment = new Models.TaskAssignment
            {
                Description = taskDescription,
                Priority = priority
            };

            if (_orchestrator != null)
            {
                await _orchestrator.EnqueueTaskAsync(assignment);
                return $"[Task Queued] ID: {assignment.TaskId} | Priority: {priority}\n" +
                       $"Description: {taskDescription}\n" +
                       "Task has been successfully queued to the Parallel Workforce Orchestrator.";
            }

            return $"[Task Created] ID: {assignment.TaskId} | Priority: {priority}\n" +
                   $"Description: {taskDescription}\n" +
                   "Task created but no Parallel Orchestrator is running to process it.";
        }
    }
}
