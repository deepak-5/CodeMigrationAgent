using System.ComponentModel;

namespace CodeMigrationAgent.Tools
{
    /// <summary>
    /// Diagnostic tools — parse build errors, run build checks.
    /// Enables agents to self-diagnose and auto-fix issues.
    /// </summary>
    public static class DiagnosticTools
    {
        [Description("Runs 'dotnet build' on a project and returns any errors or warnings.")]
        public static async Task<string> RunBuildCheck(
            [Description("Absolute path to the project file (.csproj) or solution file (.slnx/.sln).")] string projectPath)
        {
            if (!ToolSafety.IsPathAllowed(projectPath, out var safeProjectPath, out var pathError))
                return pathError;

            var result = await TerminalTools.RunInTerminal($"dotnet build \"{safeProjectPath}\" --no-restore",
                Path.GetDirectoryName(safeProjectPath) ?? ".");

            // Parse out just the errors and warnings for a clean summary
            var lines = result.Split('\n');
            var diagnostics = lines
                .Where(l => l.Contains(": error ") || l.Contains(": warning ") || l.Contains("Build succeeded") || l.Contains("Build FAILED"))
                .ToList();

            if (diagnostics.Count == 0) return result;

            return $"[Build Diagnostics]\n" + string.Join("\n", diagnostics);
        }

        [Description("Reads build errors and warnings from a specific source file by searching recent build output.")]
        public static async Task<string> GetProblems(
            [Description("Absolute path of the source file to check for problems.")] string filePath)
        {
            if (!ToolSafety.IsPathAllowed(filePath, out var safeFilePath, out var pathError))
                return pathError;

            var dir = Path.GetDirectoryName(safeFilePath) ?? ".";
            
            // Walk up to find a .csproj
            var searchDir = dir;
            string? projectFile = null;
            while (searchDir != null)
            {
                var csprojs = Directory.GetFiles(searchDir, "*.csproj");
                if (csprojs.Length > 0)
                {
                    projectFile = csprojs[0];
                    break;
                }
                searchDir = Directory.GetParent(searchDir)?.FullName;
            }

            if (projectFile == null)
                return $"[WARN] No .csproj found for {safeFilePath}";

            var buildResult = await RunBuildCheck(projectFile);

            // Filter to only lines mentioning this file
            var fileName = Path.GetFileName(safeFilePath);
            var relevantLines = buildResult.Split('\n')
                .Where(l => l.Contains(fileName, StringComparison.OrdinalIgnoreCase))
                .ToList();

            return relevantLines.Count > 0
                ? $"Problems in {fileName}:\n" + string.Join("\n", relevantLines)
                : $"No problems found in {fileName}";
        }
    }
}
