using System.ComponentModel;
using System.Text.RegularExpressions;

namespace CodeMigrationAgent.Tools
{
    /// <summary>
    /// Code search tools — ripgrep-style text search, symbol usage finder, and regex search.
    /// Designed so agents can understand and navigate unfamiliar codebases.
    /// </summary>
    public static class CodeSearchTools
    {
        [Description("Searches the codebase for a text pattern across files. Returns matching file paths, line numbers, and content snippets. Results capped at 50 matches.")]
        public static async Task<string> SearchCodebase(
            [Description("The text pattern to search for.")] string query,
            [Description("The root directory to search in.")] string directory,
            [Description("Comma-separated file extensions to include (e.g., '.cs,.json'). Leave empty for all.")] string extensions = "")
        {
            return await Task.Run(() =>
            {
                try
                {
                    if (!ToolSafety.IsPathAllowed(directory, out var safeDirectory, out var accessError))
                        return accessError;

                    var extArray = string.IsNullOrEmpty(extensions)
                        ? Array.Empty<string>()
                        : extensions.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

                    var results = new List<string>();
                    var files = extArray.Length > 0
                        ? extArray.SelectMany(ext => Directory.GetFiles(safeDirectory, $"*{ext}", SearchOption.AllDirectories))
                        : Directory.GetFiles(safeDirectory, "*.*", SearchOption.AllDirectories);

                    foreach (var file in files)
                    {
                        if (ShouldSkip(file)) continue;

                        try
                        {
                            var lines = File.ReadAllLines(file);
                            for (int i = 0; i < lines.Length; i++)
                            {
                                if (lines[i].Contains(query, StringComparison.OrdinalIgnoreCase))
                                {
                                    results.Add($"{file}:{i + 1}: {lines[i].Trim()}");
                                    if (results.Count >= 50) break;
                                }
                            }
                        }
                        catch { /* Skip unreadable files */ }

                        if (results.Count >= 50) break;
                    }

                    return results.Count > 0
                        ? $"Found {results.Count} matches:\n" + string.Join("\n", results)
                        : $"No matches found for '{query}' in {safeDirectory}";
                }
                catch (Exception ex)
                {
                    return $"[ERROR] Search failed: {ex.Message}";
                }
            });
        }

        [Description("Finds all usages of a symbol (class, method, variable) in the codebase.")]
        public static async Task<string> SearchUsages(
            [Description("The symbol name to find usages for.")] string symbol,
            [Description("The root directory to search in.")] string directory)
        {
            return await SearchCodebase(symbol, directory, ".cs,.csx,.razor");
        }

        [Description("Performs a regex or literal text search across files in a directory.")]
        public static async Task<string> TextSearch(
            [Description("The search pattern.")] string pattern,
            [Description("The root directory to search in.")] string directory,
            [Description("If true, treats pattern as regex. If false, literal text.")] bool isRegex = false)
        {
            if (!isRegex) return await SearchCodebase(pattern, directory);

            return await Task.Run(() =>
            {
                try
                {
                    if (!ToolSafety.IsPathAllowed(directory, out var safeDirectory, out var accessError))
                        return accessError;

                    var regex = new Regex(pattern, RegexOptions.IgnoreCase | RegexOptions.Compiled);
                    var results = new List<string>();

                    foreach (var file in Directory.GetFiles(safeDirectory, "*.*", SearchOption.AllDirectories))
                    {
                        if (ShouldSkip(file)) continue;
                        try
                        {
                            var lines = File.ReadAllLines(file);
                            for (int i = 0; i < lines.Length; i++)
                            {
                                if (regex.IsMatch(lines[i]))
                                {
                                    results.Add($"{file}:{i + 1}: {lines[i].Trim()}");
                                    if (results.Count >= 50) break;
                                }
                            }
                        }
                        catch { }
                        if (results.Count >= 50) break;
                    }

                    return results.Count > 0
                        ? $"Found {results.Count} regex matches:\n" + string.Join("\n", results)
                        : $"No regex matches for '{pattern}' in {safeDirectory}";
                }
                catch (Exception ex)
                {
                    return $"[ERROR] Regex search failed: {ex.Message}";
                }
            });
        }

        private static bool ShouldSkip(string path)
        {
            var skip = new[] { "\\bin\\", "\\obj\\", "\\.git\\", "\\.vs\\", "\\node_modules\\" };
            return skip.Any(s => path.Contains(s, StringComparison.OrdinalIgnoreCase));
        }
    }
}
