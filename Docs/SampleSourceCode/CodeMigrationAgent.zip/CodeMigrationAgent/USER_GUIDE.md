# CodeMigrationAgent User Guide

## 1. What this system is
`CodeMigrationAgent` is a multi-agent code migration platform built on ASP.NET + Microsoft Agents.

Core capabilities:
- Multi-agent migration workflow (`Architect -> Coder -> Reviewer -> Migration`)
- Durable run/session/replay storage (SQLite)
- Queue-based distributed worker processing
- Replay timeline + admin operations dashboard
- Governance checks (dependency DAG validation, deterministic task ownership, conflict merge)
- Cost/control plane (per-run budgets, per-tenant quotas, canary prompt/config versioning)

---

## 2. Prerequisites
- .NET SDK supporting `net10.0`
- Azure OpenAI resource (or compatible endpoint)
- Optional: Node.js + `npx` if you enable MCP servers

---

## 3. Configuration
Main config file:
- `CodeMigrationAgent/appsettings.json`

Required values:
- `AZURE_OPENAI_ENDPOINT`
- `AZURE_OPENAI_DEPLOYMENT_NAME`
- `AZURE_OPENAI_API_KEY`

Optional canary routing:
- `AZURE_OPENAI_CANARY_DEPLOYMENT_NAME`

Important config sections:
- `AgentSafety`: tool safety and prompt/output limits
- `ControlPlane`: budget/quota/canary controls
- `QueueWorkers`: worker count/poll/lease settings
- `PromptCatalog`: versioned prompts per agent
- `ProjectPrompting`: project-level instruction file injection (OpenClaw-style layered prompt files)
- `McpServers`: external MCP tool servers

---

## 4. Run locally
From repo root:

```powershell
dotnet build CodeMigrationAgent.slnx
dotnet run --project CodeMigrationAgent
```

Default durable store path:
- `CodeMigrationAgent/data/agent-platform.db`

Swagger (dev):
- `/swagger`

---

## 5. API quick start

### 5.1 Synchronous migration
`POST /migrate`

Body:
```json
{
  "prompt": "Migrate this .NET Framework project to .NET 10.",
  "tenantId": "default",
  "runId": "optional-run-id",
  "budgetTokens": 120000,
  "workspaceRoot": "C:\\repos\\MyLegacyProject",
  "customInstructions": "Prefer minimal diffs and preserve existing public API behavior."
}
```

Instruction layering for `/migrate`:
- Base agent prompt from `PromptCatalog` (stable/canary/versioned)
- Workspace files from `ProjectPrompting` (if found)
- Request-level `customInstructions`

Default workspace files checked:
- `AGENTS.md`
- `.codemigration/AGENTS.md`
- `.codemigration/architect.md`
- `.codemigration/coder.md`
- `.codemigration/reviewer.md`
- `.codemigration/migration.md`

Notes:
- `workspaceRoot` is optional; if omitted, `ProjectPrompting.DefaultWorkspaceRoot` is used.
- Instruction file loading is bounded by `MaxInstructionCharsPerFile` and `MaxTotalInstructionChars`.
- `/queue/migrate` supports the same `workspaceRoot`/`customInstructions` fields as `/migrate`.

### 5.2 Queue-based migration (recommended for scale)
`POST /queue/migrate`

Returns `202 Accepted` with `jobId` + `runId`.

Check job:
- `GET /queue/jobs/{jobId}`
- `GET /queue/jobs`

### 5.3 Resume a run from durable checkpoint
`POST /migrate/resume/{runId}`

### 5.4 Streaming migration (SSE)
`POST /migrate/stream`

---

## 6. Session APIs (durable)
- `POST /sessions`
- `GET /sessions`
- `POST /sessions/{id}/chat`
- `DELETE /sessions/{id}`

---

## 7. Admin & operations

Runs:
- `GET /admin/runs`
- `POST /admin/runs/{runId}/terminate`

Policy overrides:
- `POST /admin/policy/override`
- `GET /admin/policy/override`

Prompt rollback:
- `POST /admin/prompts/rollback/{agentName}?version=stable-v1`

Replay:
- `GET /admin/replay/{runId}` (JSON)
- `GET /admin/replay-ui/{runId}` (visual timeline)

Dashboard:
- `GET /admin/dashboard`

Health:
- `GET /health`

---

## 8. Tenant and budget behavior
- Tenant ID is taken from request body `tenantId`, else header `X-Tenant-Id`, else `default`.
- Per-run budget can be set per request (`budgetTokens`), else `ControlPlane.DefaultPerRunTokenBudget`.
- Daily tenant quota is enforced via `ControlPlane.TenantDailyTokenQuota` or default quota.
- Config/prompt version is selected by stable/canary logic in `ControlPlane`.

---

## 9. Queue worker model
- Workers run as hosted background services.
- They lease queued jobs from durable store and execute in isolated service scopes.
- Key settings:
  - `QueueWorkers.WorkerCount`
  - `QueueWorkers.PollIntervalMs`
  - `QueueWorkers.LeaseSeconds`

---

## 10. Replay timeline usage
Open:
- `/admin/replay-ui/{runId}`

Features:
- Filter by event type
- Filter by agent
- Payload text search
- Relative-time filtering

Data source:
- `/admin/replay/{runId}`

---

## 11. Operational recommendations
- Put admin routes behind authentication/authorization at gateway level.
- Configure `AgentSafety.AllowedPathRoots` explicitly in non-dev environments.
- Use queue mode for heavy workloads and burst traffic.
- Monitor DB size (`agent-platform.db`) and archive replay data as needed.
- Start with low `CanaryPercent` and increase gradually.

---

## 12. Troubleshooting

`AZURE_OPENAI_API_KEY is not configured`
- Set `AZURE_OPENAI_API_KEY` in env/appsettings/user-secrets.

No workers processing queue jobs
- Verify app is running (hosted workers run inside API process).
- Check `QueueWorkers` settings.
- Inspect `/queue/jobs` and `/admin/runs`.

Resume fails with checkpoint error
- Confirm the run has checkpoints in durable store.
- Use `/admin/replay/{runId}` to inspect run progress.

---

## 13. Minimal curl examples

Queue a job:
```bash
curl -X POST http://localhost:5000/queue/migrate \
  -H "Content-Type: application/json" \
  -d "{\"prompt\":\"Upgrade this repo to .NET 10\",\"tenantId\":\"default\"}"
```

List queue jobs:
```bash
curl http://localhost:5000/queue/jobs
```

View replay JSON:
```bash
curl http://localhost:5000/admin/replay/<runId>
```
