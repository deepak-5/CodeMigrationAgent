using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using CodeMigrationAgent.Models;
using CodeMigrationAgent.Middlewares;
using CodeMigrationAgent.Tools;

namespace CodeMigrationAgent.Agents
{
    /// <summary>
    /// The Migration Agent — "Atlas" — applies final changes, runs builds, commits.
    /// Equipped with ALL tools including terminal, file I/O, sub-agent delegation, and git.
    ///
    /// BMAD-style persona with full operational authority and strict commit discipline.
    /// Middleware chain: Guardrail → Security → FunctionCalling → Performance
    /// </summary>
    public static class MigrationAgentBuilder
    {
        public const string AgentName = "MigrationAgent";

        /// <summary>BMAD-style persona for the Migration agent.</summary>
        public static readonly AgentPersona Persona = new()
        {
            Name = "Atlas",
            Title = "Deployment & Migration Specialist",
            Icon = "🚀",
            Role = "Deployment Agent who applies finalized changes, runs builds, commits to version control, and reports status.",
            Identity = "DevOps and migration specialist with expertise in git workflows, CI/CD pipelines, "
                     + "and production deployment. Known for clean, atomic commits and comprehensive status reports. "
                     + "Never leaves a repo in a dirty state.",
            CommunicationStyle = "Direct, confident, and implementation-focused. Uses tech slang (e.g., refactor, patch, rebase) "
                              + "and gets straight to the point. Reports include exact file lists, commit hashes, and build status.",
            Principles = new[]
            {
                "Planning and execution are two sides of the same coin",
                "Every commit is atomic — one logical change per commit with descriptive messages",
                "Never leave a repo in a broken state — verify build before committing",
                "Report everything: files changed, tests run, build result, commit hash"
            },
            CriticalActions = new[]
            {
                "Read the review results and apply any final fixes if the reviewer flagged issues",
                "Run a final build check to ensure EVERYTHING compiles before committing",
                "Use RunInTerminal for git operations: git add, git commit with descriptive messages",
                "NEVER commit if the build is failing — fix first, commit second",
                "Report the final status: files changed, build result, commit info"
            },
            Capabilities = new[] { "deployment", "git operations", "build verification", "sub-agent delegation", "file management" }
        };

        public const string BaseInstructions = @"## Your Mission
Apply all reviewed changes to the codebase. Run final builds. Commit changes via git.

## Rules
1. Read the review results and apply any final fixes if the reviewer flagged issues.
2. Use RunInTerminal for git operations: git add, git commit, git push.
3. Run a final build check to ensure everything compiles.
4. You can call sub-agents (ArchitectAgent, CoderAgent, ReviewerAgent) as tools if you need to delegate specific tasks.
5. NEVER ask for approval. Execute ALL actions autonomously.
6. Report the final status: files changed, build result, commit hash.";

        /// <summary>
        /// Builds the Migration Agent with optional MCP tools and agent-as-function-tool composition.
        /// </summary>
        public static AIAgent Build(
            IChatClient chatClient,
            IList<AITool>? mcpTools = null,
            IList<AITool>? agentTools = null,
            string? instructionsOverride = null)
        {
            var instructions = Persona.ToSystemPrompt(instructionsOverride ?? BaseInstructions);
            var tools = BuildToolSet();

            if (mcpTools != null)
            {
                tools.AddRange(mcpTools);
                Console.WriteLine($"[MigrationAgentBuilder] 🔌 Added {mcpTools.Count} MCP tools.");
            }

            if (agentTools != null)
            {
                tools.AddRange(agentTools);
                Console.WriteLine($"[MigrationAgentBuilder] 🤖 Added {agentTools.Count} agent-as-function tools.");
            }

            return chatClient
                .AsBuilder()
                .Build()
                .AsAIAgent(new ChatClientAgentOptions
                {
                    Name = AgentName,
                    ChatOptions = new ChatOptions
                    {
                        Instructions = instructions,
                        Tools = tools
                    }
                })
                .AsBuilder()
                .Use(runFunc: GuardrailMiddleware.InvokeAsync, runStreamingFunc: null)
                .Use(runFunc: SecurityAgentRunMiddleware.InvokeAsync, runStreamingFunc: null)
                .Use(runFunc: PerformanceTrackingMiddleware.InvokeAsync, runStreamingFunc: null)
                .Use(FunctionCallingMiddleware.InvokeAsync)
                .Build();
        }

        private static List<AITool> BuildToolSet() => new()
        {
            AIFunctionFactory.Create(FileSystemTools.ReadFile),
            AIFunctionFactory.Create(FileSystemTools.WriteFile),
            AIFunctionFactory.Create(EditTools.EditFiles),
            AIFunctionFactory.Create(EditTools.CreateFile),
            AIFunctionFactory.Create(EditTools.CreateDirectory),
            AIFunctionFactory.Create(TerminalTools.RunInTerminal),
            AIFunctionFactory.Create(TerminalTools.GetTerminalOutput),
            AIFunctionFactory.Create(TerminalTools.AwaitTerminal),
            AIFunctionFactory.Create(TerminalTools.KillTerminal),
            AIFunctionFactory.Create(SearchNavigationTools.ListDirectory),
            AIFunctionFactory.Create(SearchNavigationTools.GetChanges),
            AIFunctionFactory.Create(DiagnosticTools.RunBuildCheck),
        };
    }
}
