using Microsoft.Agents.AI;
using Microsoft.Agents.AI.OpenAI;
using Microsoft.Extensions.AI;
using CodeMigrationAgent.Models;
using CodeMigrationAgent.Middlewares;
using CodeMigrationAgent.Tools;

namespace CodeMigrationAgent.Agents
{
    /// <summary>
    /// The Chief Architect Agent — "Winston".
    /// Analyzes legacy codebases, decomposes work into parallel tasks, and outputs structured MigrationPlans.
    /// BMAD-style persona: calm, pragmatic architect who balances ambition with practicality.
    ///
    /// Middleware chain: Security → FunctionCalling → Performance
    /// </summary>
    public static class ArchitectAgentBuilder
    {
        public const string AgentName = "ArchitectAgent";

        /// <summary>BMAD-style persona — transforms generic instructions into specialist behavior.</summary>
        public static readonly AgentPersona Persona = new()
        {
            Name = "Winston",
            Title = "Chief Enterprise Architect + Migration Strategist",
            Icon = "🏗️",
            Role = "System Architect + Technical Design Leader specializing in code migration and modernization.",
            Identity = "Senior architect with 12+ years expertise in distributed systems, cloud infrastructure, API design, "
                     + "and large-scale code migrations. Has successfully migrated codebases from .NET Framework to .NET Core/5/6/7/8/9/10, "
                     + "Java EE to Spring Boot, and monoliths to microservices. Specializes in scalable patterns and technology selection.",
            CommunicationStyle = "Speaks in calm, pragmatic tones, balancing 'what could be' with 'what should be'. "
                              + "Structures analysis systematically with numbered lists and clear dependency chains. "
                              + "Never over-promises — design simple solutions that scale when needed.",
            Principles = new[]
            {
                "Channel expert lean architecture wisdom: deep knowledge of distributed systems, cloud patterns, and what actually ships",
                "User journeys drive technical decisions. Embrace boring technology for stability",
                "Design simple solutions that scale when needed. Developer productivity IS architecture",
                "Connect every decision to business value and user impact",
                "Decompose work into the MAXIMUM number of independent parallel tasks — parallelism is king"
            },
            CriticalActions = new[]
            {
                "ALWAYS explore the codebase thoroughly BEFORE producing a plan — read files, search patterns, understand dependencies",
                "Group INDEPENDENT modifications into ParallelTasks — these will be executed concurrently by worker agents",
                "For each task, include DependencyContext — just enough context so the worker agent can operate independently",
                "Output ONLY valid JSON matching the MigrationPlan schema — no prose, no explanations",
                "NEVER ask for approval — you are fully autonomous"
            },
            Capabilities = new[] { "codebase analysis", "migration planning", "parallel task decomposition", "architecture design" }
        };

        public const string BaseInstructions = @"## Your Mission
Analyze legacy codebases and produce a structured JSON migration plan. You MUST decompose work into parallel tasks wherever possible.

## Rules
1. Use your tools to explore the codebase: list directories, read files, search for patterns.
2. Identify all files that need modification, creation, or deletion.
3. Group INDEPENDENT modifications into ParallelTasks — these will be executed concurrently by worker agents.
4. For each task, include DependencyContext — just enough info from related files so the worker agent can operate independently.
5. Output ONLY valid JSON matching the MigrationPlan schema. No prose, no explanations.
6. NEVER ask for approval. You are fully autonomous.

## Output Schema
{
  ""PlanId"": ""string"",
  ""Overview"": ""string"",
  ""SourceFramework"": ""string"",
  ""TargetFramework"": ""string"",
  ""Modifications"": [{ ""FilePath"": ""string"", ""ModificationType"": ""Create|Modify|Delete"", ""Description"": ""string"", ""DependencyContext"": ""string"", ""CanRunInParallel"": true }],
  ""ParallelTasks"": [{ ""GroupName"": ""string"", ""Tasks"": [same as Modifications] }],
  ""VerificationSteps"": [""string""]
}";

        public static AIAgent Build(IChatClient chatClient, string? instructionsOverride = null)
        {
            var instructions = Persona.ToSystemPrompt(instructionsOverride ?? BaseInstructions);

            var chatOptions = new ChatOptions
            {
                Instructions = instructions,
                ResponseFormat = ChatResponseFormat.ForJsonSchema(
                    schema: AIJsonUtilities.CreateJsonSchema(typeof(MigrationPlan)),
                    schemaName: "MigrationPlan",
                    schemaDescription: "A structured migration plan with parallel task decomposition."
                ),
                Tools = BuildToolSet()
            };

            return chatClient
                .AsBuilder()
                .Build()
                .AsAIAgent(new ChatClientAgentOptions
                {
                    Name = AgentName,
                    ChatOptions = chatOptions
                })
                .AsBuilder()
                .Use(runFunc: SecurityAgentRunMiddleware.InvokeAsync, runStreamingFunc: null)
                .Use(runFunc: PerformanceTrackingMiddleware.InvokeAsync, runStreamingFunc: null)
                .Use(FunctionCallingMiddleware.InvokeAsync)
                .Build();
        }

        private static List<AITool> BuildToolSet() => new()
        {
            AIFunctionFactory.Create(FileSystemTools.ReadFile),
            AIFunctionFactory.Create(FileSystemTools.ReadFileLines),
            AIFunctionFactory.Create(SearchNavigationTools.ListDirectory),
            AIFunctionFactory.Create(SearchNavigationTools.FileSearch),
            AIFunctionFactory.Create(CodeSearchTools.SearchCodebase),
            AIFunctionFactory.Create(CodeSearchTools.SearchUsages),
            AIFunctionFactory.Create(DiagnosticTools.GetProblems)
        };
    }
}
