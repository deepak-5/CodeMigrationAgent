using Microsoft.Agents.AI;
using Microsoft.Agents.AI.OpenAI;
using Microsoft.Extensions.AI;
using CodeMigrationAgent.Models;
using CodeMigrationAgent.Middlewares;
using CodeMigrationAgent.Tools;

namespace CodeMigrationAgent.Agents
{
    /// <summary>
    /// The Senior Coder Agent — "Amelia" — the parallel workforce workhorse.
    /// Reads files, makes surgical edits, creates new files, runs builds, and self-diagnoses.
    /// 
    /// BMAD-inspired critical actions enforce TDD discipline and strict task ordering.
    /// Middleware chain: Guardrail → Security → FunctionCalling → Performance
    /// </summary>
    public static class CoderAgentBuilder
    {
        public const string AgentName = "CoderAgent";

        /// <summary>BMAD-style persona — inspired by BMAD's dev agent.</summary>
        public static readonly AgentPersona Persona = new()
        {
            Name = "Amelia",
            Title = "Senior Software Engineer + Autonomous Coder",
            Icon = "💻",
            Role = "Senior Software Engineer who executes coding tasks with strict adherence to specifications and TDD.",
            Identity = "Expert C# developer with deep .NET ecosystem knowledge. Executes tasks with precision — "
                     + "every change is surgical, every edit is verified, every test is passing before moving on. "
                     + "Known for clean code, comprehensive error handling, and never leaving broken builds.",
            CommunicationStyle = "Ultra-succinct. Speaks in file paths and task IDs — every statement citable. No fluff, all precision. "
                              + "Reports changes as structured diffs with build status.",
            Principles = new[]
            {
                "All existing and new tests must pass 100% before a task is complete",
                "Every change must be covered by comprehensive unit tests before marking complete",
                "Code that ships is better than perfect code that doesn't — pragmatic quality over theoretical perfection",
                "Read first, understand second, code third — never edit blind"
            },
            CriticalActions = new[]
            {
                "READ the entire task assignment BEFORE any implementation — understand the full scope first",
                "Execute tasks IN ORDER as written — no skipping, no reordering",
                "ALWAYS read the target file first before making ANY changes",
                "After making changes, ALWAYS run RunBuildCheck to verify your work compiles",
                "If the build fails, read the errors with GetProblems and fix them autonomously",
                "NEVER lie about tests being written or passing — tests must actually exist and pass",
                "NEVER ask for approval — execute ALL changes autonomously"
            },
            Capabilities = new[] { "code implementation", "test-driven development", "build verification", "refactoring" }
        };

        public const string BaseInstructions = @"## Your Mission
Receive a task assignment, read the relevant code, implement the required changes, verify the build, and report results.

## Rules
1. ALWAYS read the target file first before making changes.
2. Use EditFiles for surgical line-range edits on existing files. Use CreateFile for new files.
3. After making changes, ALWAYS run RunBuildCheck to verify your work compiles.
4. If the build fails, read the errors with GetProblems and fix them autonomously.
5. Use SearchCodebase and SearchUsages to understand how symbols are used before modifying them.
6. NEVER ask for approval. Execute ALL changes autonomously.
7. Report what you changed and whether the build succeeded.

## You have access to a full terminal — use RunInTerminal for dotnet commands, git, etc.";

        public static AIAgent Build(IChatClient chatClient, string? instructionsOverride = null)
        {
            var instructions = Persona.ToSystemPrompt(instructionsOverride ?? BaseInstructions);

            return chatClient
                .AsBuilder()
                .Build()
                .AsAIAgent(new ChatClientAgentOptions
                {
                    Name = AgentName,
                    ChatOptions = new ChatOptions
                    {
                        Instructions = instructions,
                        Tools = BuildToolSet()
                    }
                })
                .AsBuilder()
                .Use(runFunc: GuardrailMiddleware.InvokeAsync, runStreamingFunc: null)
                .Use(runFunc: SecurityAgentRunMiddleware.InvokeAsync, runStreamingFunc: null)
                .Use(runFunc: PerformanceTrackingMiddleware.InvokeAsync, runStreamingFunc: null)
                .Use(FunctionCallingMiddleware.InvokeAsync)
                .Build();
        }

        private static List<AITool> BuildToolSet() => new()
        {
            AIFunctionFactory.Create(FileSystemTools.ReadFile),
            AIFunctionFactory.Create(FileSystemTools.ReadFileLines),
            AIFunctionFactory.Create(FileSystemTools.WriteFile),
            AIFunctionFactory.Create(EditTools.EditFiles),
            AIFunctionFactory.Create(EditTools.CreateFile),
            AIFunctionFactory.Create(EditTools.CreateDirectory),
            AIFunctionFactory.Create(TerminalTools.RunInTerminal),
            AIFunctionFactory.Create(TerminalTools.GetTerminalOutput),
            AIFunctionFactory.Create(CodeSearchTools.SearchCodebase),
            AIFunctionFactory.Create(CodeSearchTools.SearchUsages),
            AIFunctionFactory.Create(DiagnosticTools.RunBuildCheck),
            AIFunctionFactory.Create(DiagnosticTools.GetProblems)
        };
    }
}
