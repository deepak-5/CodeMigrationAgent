using CodeMigrationAgent.Composition;
using CodeMigrationAgent.Tools;
using Microsoft.Extensions.AI;

var builder = WebApplication.CreateBuilder(args);

if (builder.Environment.IsDevelopment())
{
    builder.Configuration.AddUserSecrets<Program>();
}

var safetyPolicy = builder.ConfigureSafetyPolicy();
var durableStore = await builder.ConfigurePlatformServicesAsync();

var chatClient = builder.BuildChatClient();
builder.Services.AddSingleton<IChatClient>(chatClient);

var mcpProvider = new McpToolProvider();
var mcpTools = await builder.LoadMcpToolsAsync(mcpProvider);

var runtime = builder.RegisterDomainServices(chatClient, mcpTools, safetyPolicy, durableStore);

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.MapAppEndpoints(runtime);

app.Lifetime.ApplicationStopping.Register(() =>
{
    mcpProvider.DisposeAsync().AsTask().GetAwaiter().GetResult();
});

app.Run();

public partial class Program { }
