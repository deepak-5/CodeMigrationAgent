using CodeMigrationAgent.Workflows;

namespace CodeMigrationAgent.Platform;

public sealed class QueueWorkerHostedService : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<QueueWorkerHostedService> _logger;
    private readonly QueueWorkerOptions _options;

    public QueueWorkerHostedService(
        IServiceScopeFactory scopeFactory,
        QueueWorkerOptions options,
        ILogger<QueueWorkerHostedService> logger)
    {
        _scopeFactory = scopeFactory;
        _options = options;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var workers = Enumerable.Range(0, Math.Max(1, _options.WorkerCount))
            .Select(i => RunWorkerAsync($"queue-worker-{i:D2}", stoppingToken))
            .ToArray();

        await Task.WhenAll(workers);
    }

    private async Task RunWorkerAsync(string workerId, CancellationToken stoppingToken)
    {
        _logger.LogInformation("[QueueWorker] {WorkerId} started.", workerId);

        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                using var scope = _scopeFactory.CreateScope();
                var store = scope.ServiceProvider.GetRequiredService<IDurableStateStore>();
                var pipeline = scope.ServiceProvider.GetRequiredService<HybridMigrationPipeline>();

                var job = await store.TryClaimNextJobAsync(workerId, TimeSpan.FromSeconds(Math.Max(5, _options.LeaseSeconds)), stoppingToken);
                if (job is null)
                {
                    await Task.Delay(Math.Max(100, _options.PollIntervalMs), stoppingToken);
                    continue;
                }

                _logger.LogInformation("[QueueWorker] {WorkerId} claimed job {JobId} for run {RunId}.", workerId, job.JobId, job.RunId);

                try
                {
                    await pipeline.ExecuteAsync(
                        job.Prompt,
                        tenantId: job.TenantId,
                        runId: job.RunId,
                        budgetTokens: job.BudgetTokens,
                        workspaceRoot: job.WorkspaceRoot,
                        customInstructions: job.CustomInstructions,
                        cancellationToken: stoppingToken);

                    await store.CompleteJobAsync(job.JobId, "completed", cancellationToken: stoppingToken);
                }
                catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
                {
                    await store.CompleteJobAsync(job.JobId, "aborted", "Worker stopping", stoppingToken);
                    throw;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "[QueueWorker] Job {JobId} failed.", job.JobId);
                    await store.CompleteJobAsync(job.JobId, "failed", ex.Message, stoppingToken);
                }
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "[QueueWorker] {WorkerId} loop error.", workerId);
                await Task.Delay(Math.Max(250, _options.PollIntervalMs), stoppingToken);
            }
        }

        _logger.LogInformation("[QueueWorker] {WorkerId} stopped.", workerId);
    }
}
