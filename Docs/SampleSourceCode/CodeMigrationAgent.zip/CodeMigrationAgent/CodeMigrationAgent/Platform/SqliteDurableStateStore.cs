using System.Text.Json;
using CodeMigrationAgent.Models;
using Microsoft.Data.Sqlite;

namespace CodeMigrationAgent.Platform;

public sealed class SqliteDurableStateStore : IDurableStateStore
{
    private readonly string _connectionString;
    private readonly SemaphoreSlim _gate = new(1, 1);

    public SqliteDurableStateStore(string dbPath)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(dbPath)!);
        _connectionString = new SqliteConnectionStringBuilder { DataSource = dbPath }.ToString();
    }

    public async Task InitializeAsync(CancellationToken cancellationToken = default)
    {
        const string ddl = """
            CREATE TABLE IF NOT EXISTS sessions(
              session_id TEXT PRIMARY KEY,
              description TEXT NOT NULL,
              messages_json TEXT NOT NULL,
              created_at_utc TEXT NOT NULL,
              updated_at_utc TEXT NOT NULL,
              message_count INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS runs(
              run_id TEXT PRIMARY KEY,
              tenant_id TEXT NOT NULL,
              status TEXT NOT NULL,
              phase TEXT NOT NULL,
              started_at_utc TEXT NOT NULL,
              updated_at_utc TEXT NOT NULL,
              ended_at_utc TEXT NULL,
              used_tokens INTEGER NOT NULL,
              budget_tokens INTEGER NOT NULL,
              error TEXT NULL
            );
            CREATE TABLE IF NOT EXISTS checkpoints(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              run_id TEXT NOT NULL,
              phase TEXT NOT NULL,
              payload TEXT NOT NULL,
              created_at_utc TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS replay_events(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              run_id TEXT NOT NULL,
              event_type TEXT NOT NULL,
              agent TEXT NOT NULL,
              payload TEXT NOT NULL,
              tenant_id TEXT NOT NULL,
              timestamp_utc TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS tenant_usage(
              tenant_id TEXT NOT NULL,
              day_utc TEXT NOT NULL,
              tokens_used INTEGER NOT NULL,
              PRIMARY KEY(tenant_id, day_utc)
            );
            CREATE TABLE IF NOT EXISTS policy_overrides(
              key TEXT PRIMARY KEY,
              value TEXT NOT NULL,
              updated_by TEXT NOT NULL,
              reason TEXT NOT NULL,
              updated_at_utc TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS prompt_versions(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              agent_name TEXT NOT NULL,
              version TEXT NOT NULL,
              instructions TEXT NOT NULL,
              created_at_utc TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS queue_jobs(
              job_id TEXT PRIMARY KEY,
              run_id TEXT NOT NULL,
              tenant_id TEXT NOT NULL,
              prompt TEXT NOT NULL,
              budget_tokens INTEGER NOT NULL,
              status TEXT NOT NULL,
              enqueued_at_utc TEXT NOT NULL,
              started_at_utc TEXT NULL,
              finished_at_utc TEXT NULL,
              worker_id TEXT NULL,
              lease_until_utc TEXT NULL,
              error TEXT NULL
            );
            """;

        await ExecuteAsync(ddl, null, cancellationToken);
        await EnsureQueueJobColumnsAsync(cancellationToken);
    }

    public async Task UpsertSessionAsync(string sessionId, string description, IReadOnlyList<ChatHistoryRow> messages, CancellationToken cancellationToken = default)
    {
        var now = DateTime.UtcNow;
        var messagesJson = JsonSerializer.Serialize(messages);
        var sql = """
            INSERT INTO sessions(session_id, description, messages_json, created_at_utc, updated_at_utc, message_count)
            VALUES($id, $description, $messages, $now, $now, $count)
            ON CONFLICT(session_id) DO UPDATE SET
              description=$description,
              messages_json=$messages,
              updated_at_utc=$now,
              message_count=$count;
            """;
        await ExecuteAsync(sql, cmd =>
        {
            cmd.Parameters.AddWithValue("$id", sessionId);
            cmd.Parameters.AddWithValue("$description", description);
            cmd.Parameters.AddWithValue("$messages", messagesJson);
            cmd.Parameters.AddWithValue("$now", now.ToString("O"));
            cmd.Parameters.AddWithValue("$count", messages.Count);
        }, cancellationToken);
    }

    public async Task<(string Description, List<ChatHistoryRow> Messages)?> GetSessionAsync(string sessionId, CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            await using var con = new SqliteConnection(_connectionString);
            await con.OpenAsync(cancellationToken);
            await using var cmd = con.CreateCommand();
            cmd.CommandText = "SELECT description, messages_json FROM sessions WHERE session_id=$id;";
            cmd.Parameters.AddWithValue("$id", sessionId);
            await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
            if (!await reader.ReadAsync(cancellationToken))
            {
                return null;
            }

            var description = reader.GetString(0);
            var messagesJson = reader.GetString(1);
            var messages = JsonSerializer.Deserialize<List<ChatHistoryRow>>(messagesJson) ?? [];
            return (description, messages);
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task<IReadOnlyList<(string SessionId, string Description, DateTime CreatedAtUtc, int MessageCount)>> ListSessionsAsync(CancellationToken cancellationToken = default)
    {
        var result = new List<(string, string, DateTime, int)>();
        await _gate.WaitAsync(cancellationToken);
        try
        {
            await using var con = new SqliteConnection(_connectionString);
            await con.OpenAsync(cancellationToken);
            await using var cmd = con.CreateCommand();
            cmd.CommandText = "SELECT session_id, description, created_at_utc, message_count FROM sessions ORDER BY updated_at_utc DESC;";
            await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                result.Add((reader.GetString(0), reader.GetString(1), DateTime.Parse(reader.GetString(2)), reader.GetInt32(3)));
            }
        }
        finally
        {
            _gate.Release();
        }

        return result;
    }

    public async Task<bool> DeleteSessionAsync(string sessionId, CancellationToken cancellationToken = default)
    {
        const string sql = "DELETE FROM sessions WHERE session_id=$id;";
        var affected = await ExecuteAsync(sql, cmd => cmd.Parameters.AddWithValue("$id", sessionId), cancellationToken);
        return affected > 0;
    }

    public async Task StartRunAsync(ActiveRunInfo run, CancellationToken cancellationToken = default)
    {
        var sql = """
            INSERT INTO runs(run_id, tenant_id, status, phase, started_at_utc, updated_at_utc, used_tokens, budget_tokens, error)
            VALUES($id, $tenant, $status, $phase, $started, $updated, $used, $budget, NULL)
            ON CONFLICT(run_id) DO UPDATE SET
              tenant_id=$tenant, status=$status, phase=$phase, updated_at_utc=$updated, used_tokens=$used, budget_tokens=$budget;
            """;
        await ExecuteAsync(sql, cmd =>
        {
            cmd.Parameters.AddWithValue("$id", run.RunId);
            cmd.Parameters.AddWithValue("$tenant", run.TenantId);
            cmd.Parameters.AddWithValue("$status", run.Status);
            cmd.Parameters.AddWithValue("$phase", run.Phase);
            cmd.Parameters.AddWithValue("$started", run.StartedAtUtc.ToString("O"));
            cmd.Parameters.AddWithValue("$updated", (run.LastUpdatedAtUtc ?? DateTime.UtcNow).ToString("O"));
            cmd.Parameters.AddWithValue("$used", run.UsedTokens);
            cmd.Parameters.AddWithValue("$budget", run.BudgetTokens);
        }, cancellationToken);
    }

    public async Task UpdateRunPhaseAsync(string runId, string phase, int usedTokens, string status, CancellationToken cancellationToken = default)
    {
        const string sql = "UPDATE runs SET phase=$phase, status=$status, used_tokens=$used, updated_at_utc=$updated WHERE run_id=$id;";
        await ExecuteAsync(sql, cmd =>
        {
            cmd.Parameters.AddWithValue("$id", runId);
            cmd.Parameters.AddWithValue("$phase", phase);
            cmd.Parameters.AddWithValue("$status", status);
            cmd.Parameters.AddWithValue("$used", usedTokens);
            cmd.Parameters.AddWithValue("$updated", DateTime.UtcNow.ToString("O"));
        }, cancellationToken);
    }

    public async Task CompleteRunAsync(string runId, string status, int usedTokens, string? error, CancellationToken cancellationToken = default)
    {
        const string sql = "UPDATE runs SET status=$status, used_tokens=$used, error=$error, updated_at_utc=$updated, ended_at_utc=$ended WHERE run_id=$id;";
        await ExecuteAsync(sql, cmd =>
        {
            cmd.Parameters.AddWithValue("$id", runId);
            cmd.Parameters.AddWithValue("$status", status);
            cmd.Parameters.AddWithValue("$used", usedTokens);
            cmd.Parameters.AddWithValue("$error", (object?)error ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$updated", DateTime.UtcNow.ToString("O"));
            cmd.Parameters.AddWithValue("$ended", DateTime.UtcNow.ToString("O"));
        }, cancellationToken);
    }

    public async Task<IReadOnlyList<ActiveRunInfo>> ListActiveRunsAsync(CancellationToken cancellationToken = default)
    {
        const string sql = "SELECT run_id, tenant_id, status, phase, started_at_utc, updated_at_utc, used_tokens, budget_tokens FROM runs WHERE status IN ('running','checkpointed') ORDER BY updated_at_utc DESC;";
        return await QueryRunsAsync(sql, cancellationToken);
    }

    public async Task<ActiveRunInfo?> GetRunAsync(string runId, CancellationToken cancellationToken = default)
    {
        const string sql = "SELECT run_id, tenant_id, status, phase, started_at_utc, updated_at_utc, used_tokens, budget_tokens FROM runs WHERE run_id=$id;";
        var rows = await QueryRunsAsync(sql, cancellationToken, cmd => cmd.Parameters.AddWithValue("$id", runId));
        return rows.FirstOrDefault();
    }

    public async Task AddCheckpointAsync(string runId, string phase, string payload, CancellationToken cancellationToken = default)
    {
        const string sql = "INSERT INTO checkpoints(run_id, phase, payload, created_at_utc) VALUES($id, $phase, $payload, $now);";
        await ExecuteAsync(sql, cmd =>
        {
            cmd.Parameters.AddWithValue("$id", runId);
            cmd.Parameters.AddWithValue("$phase", phase);
            cmd.Parameters.AddWithValue("$payload", payload);
            cmd.Parameters.AddWithValue("$now", DateTime.UtcNow.ToString("O"));
        }, cancellationToken);
    }

    public async Task<string?> GetLatestCheckpointAsync(string runId, CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            await using var con = new SqliteConnection(_connectionString);
            await con.OpenAsync(cancellationToken);
            await using var cmd = con.CreateCommand();
            cmd.CommandText = "SELECT payload FROM checkpoints WHERE run_id=$id ORDER BY id DESC LIMIT 1;";
            cmd.Parameters.AddWithValue("$id", runId);
            var result = await cmd.ExecuteScalarAsync(cancellationToken);
            return result as string;
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task AddPolicyOverrideAsync(PolicyOverride policyOverride, CancellationToken cancellationToken = default)
    {
        const string sql = """
            INSERT INTO policy_overrides(key, value, updated_by, reason, updated_at_utc)
            VALUES($key, $value, $by, $reason, $time)
            ON CONFLICT(key) DO UPDATE SET value=$value, updated_by=$by, reason=$reason, updated_at_utc=$time;
            """;
        await ExecuteAsync(sql, cmd =>
        {
            cmd.Parameters.AddWithValue("$key", policyOverride.Key);
            cmd.Parameters.AddWithValue("$value", policyOverride.Value);
            cmd.Parameters.AddWithValue("$by", policyOverride.UpdatedBy);
            cmd.Parameters.AddWithValue("$reason", policyOverride.Reason);
            cmd.Parameters.AddWithValue("$time", policyOverride.UpdatedAtUtc.ToString("O"));
        }, cancellationToken);
    }

    public async Task<IReadOnlyList<PolicyOverride>> GetPolicyOverridesAsync(CancellationToken cancellationToken = default)
    {
        var rows = new List<PolicyOverride>();
        await _gate.WaitAsync(cancellationToken);
        try
        {
            await using var con = new SqliteConnection(_connectionString);
            await con.OpenAsync(cancellationToken);
            await using var cmd = con.CreateCommand();
            cmd.CommandText = "SELECT key, value, updated_by, reason, updated_at_utc FROM policy_overrides ORDER BY updated_at_utc DESC;";
            await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                rows.Add(new PolicyOverride
                {
                    Key = reader.GetString(0),
                    Value = reader.GetString(1),
                    UpdatedBy = reader.GetString(2),
                    Reason = reader.GetString(3),
                    UpdatedAtUtc = DateTime.Parse(reader.GetString(4))
                });
            }
        }
        finally
        {
            _gate.Release();
        }

        return rows;
    }

    public async Task SavePromptVersionAsync(PromptVersionRecord record, CancellationToken cancellationToken = default)
    {
        const string sql = "INSERT INTO prompt_versions(agent_name, version, instructions, created_at_utc) VALUES($agent, $version, $instructions, $time);";
        await ExecuteAsync(sql, cmd =>
        {
            cmd.Parameters.AddWithValue("$agent", record.AgentName);
            cmd.Parameters.AddWithValue("$version", record.Version);
            cmd.Parameters.AddWithValue("$instructions", record.Instructions);
            cmd.Parameters.AddWithValue("$time", DateTime.UtcNow.ToString("O"));
        }, cancellationToken);
    }

    public async Task<IReadOnlyList<PromptVersionRecord>> GetPromptVersionsAsync(string agentName, CancellationToken cancellationToken = default)
    {
        var rows = new List<PromptVersionRecord>();
        await _gate.WaitAsync(cancellationToken);
        try
        {
            await using var con = new SqliteConnection(_connectionString);
            await con.OpenAsync(cancellationToken);
            await using var cmd = con.CreateCommand();
            cmd.CommandText = "SELECT agent_name, version, instructions FROM prompt_versions WHERE agent_name=$agent ORDER BY id DESC;";
            cmd.Parameters.AddWithValue("$agent", agentName);
            await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                rows.Add(new PromptVersionRecord
                {
                    AgentName = reader.GetString(0),
                    Version = reader.GetString(1),
                    Instructions = reader.GetString(2)
                });
            }
        }
        finally
        {
            _gate.Release();
        }
        return rows;
    }

    public async Task<int> GetTenantUsageAsync(string tenantId, DateOnly dayUtc, CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            await using var con = new SqliteConnection(_connectionString);
            await con.OpenAsync(cancellationToken);
            await using var cmd = con.CreateCommand();
            cmd.CommandText = "SELECT tokens_used FROM tenant_usage WHERE tenant_id=$tenant AND day_utc=$day;";
            cmd.Parameters.AddWithValue("$tenant", tenantId);
            cmd.Parameters.AddWithValue("$day", dayUtc.ToString("yyyy-MM-dd"));
            var result = await cmd.ExecuteScalarAsync(cancellationToken);
            return result is null or DBNull ? 0 : Convert.ToInt32(result);
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task AddTenantUsageAsync(string tenantId, DateOnly dayUtc, int tokens, CancellationToken cancellationToken = default)
    {
        const string sql = """
            INSERT INTO tenant_usage(tenant_id, day_utc, tokens_used) VALUES($tenant, $day, $tokens)
            ON CONFLICT(tenant_id, day_utc) DO UPDATE SET tokens_used=tokens_used + $tokens;
            """;
        await ExecuteAsync(sql, cmd =>
        {
            cmd.Parameters.AddWithValue("$tenant", tenantId);
            cmd.Parameters.AddWithValue("$day", dayUtc.ToString("yyyy-MM-dd"));
            cmd.Parameters.AddWithValue("$tokens", tokens);
        }, cancellationToken);
    }

    public async Task WriteAsync(ReplayEvent replayEvent, CancellationToken cancellationToken = default)
    {
        const string sql = "INSERT INTO replay_events(run_id, event_type, agent, payload, tenant_id, timestamp_utc) VALUES($run, $type, $agent, $payload, $tenant, $time);";
        await ExecuteAsync(sql, cmd =>
        {
            cmd.Parameters.AddWithValue("$run", replayEvent.RunId);
            cmd.Parameters.AddWithValue("$type", replayEvent.EventType);
            cmd.Parameters.AddWithValue("$agent", replayEvent.Agent);
            cmd.Parameters.AddWithValue("$payload", replayEvent.Payload);
            cmd.Parameters.AddWithValue("$tenant", replayEvent.TenantId ?? "default");
            cmd.Parameters.AddWithValue("$time", replayEvent.TimestampUtc.ToString("O"));
        }, cancellationToken);
    }

    public async Task<IReadOnlyList<RunReplayRow>> GetReplayEventsAsync(string runId, CancellationToken cancellationToken = default)
    {
        var rows = new List<RunReplayRow>();
        await _gate.WaitAsync(cancellationToken);
        try
        {
            await using var con = new SqliteConnection(_connectionString);
            await con.OpenAsync(cancellationToken);
            await using var cmd = con.CreateCommand();
            cmd.CommandText = "SELECT id, run_id, timestamp_utc, event_type, agent, payload, tenant_id FROM replay_events WHERE run_id=$run ORDER BY id;";
            cmd.Parameters.AddWithValue("$run", runId);
            await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                rows.Add(new RunReplayRow(
                    reader.GetInt64(0),
                    reader.GetString(1),
                    DateTime.Parse(reader.GetString(2)),
                    reader.GetString(3),
                    reader.GetString(4),
                    reader.GetString(5),
                    reader.GetString(6)));
            }
        }
        finally
        {
            _gate.Release();
        }

        return rows;
    }

    public async Task<string> EnqueueMigrationJobAsync(
        string tenantId,
        string runId,
        string prompt,
        int budgetTokens,
        string? workspaceRoot = null,
        string? customInstructions = null,
        CancellationToken cancellationToken = default)
    {
        var jobId = Guid.NewGuid().ToString("N");
        const string sql = """
            INSERT INTO queue_jobs(job_id, run_id, tenant_id, prompt, workspace_root, custom_instructions, budget_tokens, status, enqueued_at_utc)
            VALUES($job, $run, $tenant, $prompt, $workspaceRoot, $customInstructions, $budget, 'queued', $time);
            """;
        await ExecuteAsync(sql, cmd =>
        {
            cmd.Parameters.AddWithValue("$job", jobId);
            cmd.Parameters.AddWithValue("$run", runId);
            cmd.Parameters.AddWithValue("$tenant", tenantId);
            cmd.Parameters.AddWithValue("$prompt", prompt);
            cmd.Parameters.AddWithValue("$workspaceRoot", (object?)workspaceRoot ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$customInstructions", (object?)customInstructions ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$budget", budgetTokens);
            cmd.Parameters.AddWithValue("$time", DateTime.UtcNow.ToString("O"));
        }, cancellationToken);
        return jobId;
    }

    public async Task<QueueJob?> TryClaimNextJobAsync(string workerId, TimeSpan leaseDuration, CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            await using var con = new SqliteConnection(_connectionString);
            await con.OpenAsync(cancellationToken);
            using var tx = con.BeginTransaction();
            var now = DateTime.UtcNow;
            var leaseUntil = now.Add(leaseDuration).ToString("O");

            await using var claimCmd = con.CreateCommand();
            claimCmd.Transaction = tx;
            claimCmd.CommandText = """
                UPDATE queue_jobs
                SET status='running', worker_id=$worker, started_at_utc=COALESCE(started_at_utc, $now), lease_until_utc=$lease
                WHERE job_id = (
                  SELECT job_id FROM queue_jobs
                  WHERE status='queued' OR (status='running' AND lease_until_utc < $now)
                  ORDER BY enqueued_at_utc
                  LIMIT 1
                );
                """;
            claimCmd.Parameters.AddWithValue("$worker", workerId);
            claimCmd.Parameters.AddWithValue("$now", now.ToString("O"));
            claimCmd.Parameters.AddWithValue("$lease", leaseUntil);

            var affected = await claimCmd.ExecuteNonQueryAsync(cancellationToken);
            if (affected == 0)
            {
                await tx.CommitAsync(cancellationToken);
                return null;
            }

            await using var readCmd = con.CreateCommand();
            readCmd.Transaction = tx;
            readCmd.CommandText = """
                SELECT job_id, run_id, tenant_id, prompt, workspace_root, custom_instructions, budget_tokens, status, enqueued_at_utc, started_at_utc, finished_at_utc, worker_id, error
                FROM queue_jobs
                WHERE worker_id=$worker AND status='running'
                ORDER BY started_at_utc DESC
                LIMIT 1;
                """;
            readCmd.Parameters.AddWithValue("$worker", workerId);
            await using var reader = await readCmd.ExecuteReaderAsync(cancellationToken);
            QueueJob? job = null;
            if (await reader.ReadAsync(cancellationToken))
            {
                job = MapQueueJob(reader);
            }

            await tx.CommitAsync(cancellationToken);
            return job;
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task CompleteJobAsync(string jobId, string status, string? error = null, CancellationToken cancellationToken = default)
    {
        const string sql = """
            UPDATE queue_jobs
            SET status=$status, finished_at_utc=$time, lease_until_utc=NULL, error=$error
            WHERE job_id=$job;
            """;
        await ExecuteAsync(sql, cmd =>
        {
            cmd.Parameters.AddWithValue("$status", status);
            cmd.Parameters.AddWithValue("$time", DateTime.UtcNow.ToString("O"));
            cmd.Parameters.AddWithValue("$error", (object?)error ?? DBNull.Value);
            cmd.Parameters.AddWithValue("$job", jobId);
        }, cancellationToken);
    }

    public async Task<QueueJob?> GetJobAsync(string jobId, CancellationToken cancellationToken = default)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            await using var con = new SqliteConnection(_connectionString);
            await con.OpenAsync(cancellationToken);
            await using var cmd = con.CreateCommand();
            cmd.CommandText = """
                SELECT job_id, run_id, tenant_id, prompt, workspace_root, custom_instructions, budget_tokens, status, enqueued_at_utc, started_at_utc, finished_at_utc, worker_id, error
                FROM queue_jobs WHERE job_id=$job;
                """;
            cmd.Parameters.AddWithValue("$job", jobId);
            await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
            return await reader.ReadAsync(cancellationToken) ? MapQueueJob(reader) : null;
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task<IReadOnlyList<QueueJob>> ListJobsAsync(int take = 100, CancellationToken cancellationToken = default)
    {
        var rows = new List<QueueJob>();
        await _gate.WaitAsync(cancellationToken);
        try
        {
            await using var con = new SqliteConnection(_connectionString);
            await con.OpenAsync(cancellationToken);
            await using var cmd = con.CreateCommand();
            cmd.CommandText = """
                SELECT job_id, run_id, tenant_id, prompt, workspace_root, custom_instructions, budget_tokens, status, enqueued_at_utc, started_at_utc, finished_at_utc, worker_id, error
                FROM queue_jobs ORDER BY enqueued_at_utc DESC LIMIT $take;
                """;
            cmd.Parameters.AddWithValue("$take", take);
            await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                rows.Add(MapQueueJob(reader));
            }
        }
        finally
        {
            _gate.Release();
        }
        return rows;
    }

    private async Task<int> ExecuteAsync(string sql, Action<SqliteCommand>? bind, CancellationToken cancellationToken)
    {
        await _gate.WaitAsync(cancellationToken);
        try
        {
            await using var con = new SqliteConnection(_connectionString);
            await con.OpenAsync(cancellationToken);
            await using var cmd = con.CreateCommand();
            cmd.CommandText = sql;
            bind?.Invoke(cmd);
            return await cmd.ExecuteNonQueryAsync(cancellationToken);
        }
        finally
        {
            _gate.Release();
        }
    }

    private async Task<IReadOnlyList<ActiveRunInfo>> QueryRunsAsync(string sql, CancellationToken cancellationToken, Action<SqliteCommand>? bind = null)
    {
        var rows = new List<ActiveRunInfo>();
        await _gate.WaitAsync(cancellationToken);
        try
        {
            await using var con = new SqliteConnection(_connectionString);
            await con.OpenAsync(cancellationToken);
            await using var cmd = con.CreateCommand();
            cmd.CommandText = sql;
            bind?.Invoke(cmd);
            await using var reader = await cmd.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
            {
                rows.Add(new ActiveRunInfo(
                    reader.GetString(0),
                    reader.GetString(1),
                    reader.GetString(2),
                    reader.GetString(3),
                    DateTime.Parse(reader.GetString(4)),
                    DateTime.Parse(reader.GetString(5)),
                    reader.GetInt32(6),
                    reader.GetInt32(7)));
            }
        }
        finally
        {
            _gate.Release();
        }
        return rows;
    }

    private static QueueJob MapQueueJob(SqliteDataReader reader)
    {
        static DateTime? ParseNullable(string? value) =>
            string.IsNullOrWhiteSpace(value) ? null : DateTime.Parse(value);

        return new QueueJob(
            reader.GetString(0),
            reader.GetString(1),
            reader.GetString(2),
            reader.GetString(3),
            reader.IsDBNull(4) ? null : reader.GetString(4),
            reader.IsDBNull(5) ? null : reader.GetString(5),
            reader.GetInt32(6),
            reader.GetString(7),
            DateTime.Parse(reader.GetString(8)),
            ParseNullable(reader.IsDBNull(9) ? null : reader.GetString(9)),
            ParseNullable(reader.IsDBNull(10) ? null : reader.GetString(10)),
            reader.IsDBNull(11) ? null : reader.GetString(11),
            reader.IsDBNull(12) ? null : reader.GetString(12));
    }

    private async Task EnsureQueueJobColumnsAsync(CancellationToken cancellationToken)
    {
        await EnsureTableColumnAsync("queue_jobs", "workspace_root", "TEXT NULL", cancellationToken);
        await EnsureTableColumnAsync("queue_jobs", "custom_instructions", "TEXT NULL", cancellationToken);
    }

    private async Task EnsureTableColumnAsync(
        string tableName,
        string columnName,
        string columnDefinition,
        CancellationToken cancellationToken)
    {
        var hasColumn = false;
        await _gate.WaitAsync(cancellationToken);
        try
        {
            await using var con = new SqliteConnection(_connectionString);
            await con.OpenAsync(cancellationToken);

            await using (var pragma = con.CreateCommand())
            {
                pragma.CommandText = $"PRAGMA table_info({tableName});";
                await using var reader = await pragma.ExecuteReaderAsync(cancellationToken);
                while (await reader.ReadAsync(cancellationToken))
                {
                    var name = reader.GetString(1);
                    if (name.Equals(columnName, StringComparison.OrdinalIgnoreCase))
                    {
                        hasColumn = true;
                        break;
                    }
                }
            }

            if (!hasColumn)
            {
                await using var alter = con.CreateCommand();
                alter.CommandText = $"ALTER TABLE {tableName} ADD COLUMN {columnName} {columnDefinition};";
                await alter.ExecuteNonQueryAsync(cancellationToken);
            }
        }
        finally
        {
            _gate.Release();
        }
    }
}
