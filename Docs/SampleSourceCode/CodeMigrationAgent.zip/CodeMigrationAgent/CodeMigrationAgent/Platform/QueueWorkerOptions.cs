namespace CodeMigrationAgent.Platform;

public sealed class QueueWorkerOptions
{
    public int WorkerCount { get; set; } = 4;
    public int PollIntervalMs { get; set; } = 800;
    public int LeaseSeconds { get; set; } = 30;
}
