using CodeMigrationAgent.Models;
using Microsoft.Extensions.AI;

namespace CodeMigrationAgent.Platform;

public sealed class AdaptiveRoutingChatClient : IChatClient
{
    private readonly IChatClient _stableClient;
    private readonly IChatClient? _canaryClient;

    public AdaptiveRoutingChatClient(IChatClient stableClient, IChatClient? canaryClient = null)
    {
        _stableClient = stableClient;
        _canaryClient = canaryClient;
    }

    public Task<ChatResponse> GetResponseAsync(IEnumerable<ChatMessage> chatMessages, ChatOptions? options = null, CancellationToken cancellationToken = default)
    {
        return ResolveClient(chatMessages).GetResponseAsync(chatMessages, options, cancellationToken);
    }

    public IAsyncEnumerable<ChatResponseUpdate> GetStreamingResponseAsync(IEnumerable<ChatMessage> chatMessages, ChatOptions? options = null, CancellationToken cancellationToken = default)
    {
        return ResolveClient(chatMessages).GetStreamingResponseAsync(chatMessages, options, cancellationToken);
    }

    public object? GetService(Type serviceType, object? serviceKey = null)
    {
        return _stableClient.GetService(serviceType, serviceKey);
    }

    public void Dispose()
    {
        _stableClient.Dispose();
        _canaryClient?.Dispose();
    }

    private IChatClient ResolveClient(IEnumerable<ChatMessage> chatMessages)
    {
        if (_canaryClient is null)
        {
            return _stableClient;
        }

        var configVersion = RuntimeExecutionContext.ConfigVersion ?? string.Empty;
        if (configVersion.Contains("canary", StringComparison.OrdinalIgnoreCase))
        {
            return _canaryClient;
        }

        // Adaptive fallback: large prompt routes to stable for reliability.
        var inputSize = chatMessages.Sum(m => m.Text?.Length ?? 0);
        return inputSize > 20_000 ? _stableClient : _stableClient;
    }
}
