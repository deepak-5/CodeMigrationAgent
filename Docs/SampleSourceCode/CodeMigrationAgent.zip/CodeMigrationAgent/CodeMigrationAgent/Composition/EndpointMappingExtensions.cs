using CodeMigrationAgent.Agents;
using CodeMigrationAgent.Platform;
using CodeMigrationAgent.Workflows;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using System.Text;
using System.Text.Json;

namespace CodeMigrationAgent.Composition;

public static class EndpointMappingExtensions
{
    public static void MapAppEndpoints(this WebApplication app, AppRuntimeState runtime)
    {
        app.MapGet("/", () => "Code Migration Agent is running.");

        app.MapPost("/migrate", async (
            MigrationRequest request,
            HybridMigrationPipeline pipeline,
            HttpContext ctx) =>
        {
            var tenantId = request.TenantId ?? ctx.Request.Headers["X-Tenant-Id"].FirstOrDefault() ?? "default";
            var response = await pipeline.ExecuteAsync(
                request.Prompt,
                tenantId: tenantId,
                runId: request.RunId,
                budgetTokens: request.BudgetTokens,
                workspaceRoot: request.WorkspaceRoot,
                customInstructions: request.CustomInstructions,
                cancellationToken: ctx.RequestAborted);

            var messages = response.Messages.Select(m => new { Role = m.Role.Value, Content = m.Text }).ToList();
            return Results.Ok(new { Status = "Complete", Messages = messages });
        });

        app.MapPost("/queue/migrate", async (
            MigrationRequest request,
            ControlPlaneService controlPlane,
            IDurableStateStore store,
            HttpContext ctx) =>
        {
            var tenantId = request.TenantId ?? ctx.Request.Headers["X-Tenant-Id"].FirstOrDefault() ?? "default";
            var runId = request.RunId ?? Guid.NewGuid().ToString("N");
            var budget = request.BudgetTokens ?? controlPlane.ResolveRunBudget(null);
            await controlPlane.EnsureTenantQuotaAsync(tenantId, budget, ctx.RequestAborted);

            var jobId = await store.EnqueueMigrationJobAsync(
                tenantId,
                runId,
                request.Prompt,
                budget,
                request.WorkspaceRoot,
                request.CustomInstructions,
                ctx.RequestAborted);
            await store.WriteAsync(new CodeMigrationAgent.Models.ReplayEvent(runId, "queue_enqueue", "api", $"Job {jobId} enqueued", DateTime.UtcNow, tenantId), ctx.RequestAborted);
            return Results.Accepted($"/queue/jobs/{jobId}", new
            {
                JobId = jobId,
                RunId = runId,
                Status = "Queued",
                TenantId = tenantId,
                BudgetTokens = budget,
                WorkspaceRoot = request.WorkspaceRoot
            });
        });

        app.MapGet("/queue/jobs/{jobId}", async (string jobId, IDurableStateStore store, HttpContext ctx) =>
        {
            var job = await store.GetJobAsync(jobId, ctx.RequestAborted);
            return job is null ? Results.NotFound(new { Error = $"Job '{jobId}' not found." }) : Results.Ok(job);
        });

        app.MapGet("/queue/jobs", async (IDurableStateStore store, HttpContext ctx) =>
            Results.Ok(await store.ListJobsAsync(200, ctx.RequestAborted)));

        app.MapPost("/migrate/resume/{runId}", async (string runId, HybridMigrationPipeline pipeline, HttpContext ctx) =>
        {
            var checkpoint = await runtime.DurableStore.GetLatestCheckpointAsync(runId, ctx.RequestAborted);
            if (string.IsNullOrWhiteSpace(checkpoint))
            {
                return Results.NotFound(new { Error = $"No checkpoint found for run '{runId}'." });
            }

            using var doc = JsonDocument.Parse(checkpoint);
            if (!doc.RootElement.TryGetProperty("Prompt", out var promptNode))
            {
                return Results.BadRequest(new { Error = "Checkpoint does not contain resumable prompt payload." });
            }

            var prompt = promptNode.GetString() ?? string.Empty;
            var tenant = doc.RootElement.TryGetProperty("tenantId", out var tNode) ? (tNode.GetString() ?? "default") : "default";
            var budget = doc.RootElement.TryGetProperty("runBudget", out var bNode) && bNode.TryGetInt32(out var b) ? b : (int?)null;
            var workspaceRoot = doc.RootElement.TryGetProperty("workspaceRoot", out var wNode) ? wNode.GetString() : null;
            var customInstructions = doc.RootElement.TryGetProperty("customInstructions", out var cNode) ? cNode.GetString() : null;

            var response = await pipeline.ExecuteAsync(
                prompt,
                tenantId: tenant,
                runId: runId,
                budgetTokens: budget,
                workspaceRoot: workspaceRoot,
                customInstructions: customInstructions,
                cancellationToken: ctx.RequestAborted);

            var messages = response.Messages.Select(m => new { Role = m.Role.Value, Content = m.Text }).ToList();
            return Results.Ok(new { Status = "Resumed", RunId = runId, Messages = messages });
        });

        app.MapPost("/migrate/stream", async (MigrationRequest request, StreamingPipeline pipeline, HttpContext ctx) =>
        {
            ctx.Response.ContentType = "text/event-stream";
            ctx.Response.Headers.CacheControl = "no-cache";
            ctx.Response.Headers.Connection = "keep-alive";

            var tenantId = request.TenantId ?? ctx.Request.Headers["X-Tenant-Id"].FirstOrDefault() ?? "default";
            await foreach (var evt in pipeline.ExecuteStreamingAsync(
                request.Prompt,
                tenantId: tenantId,
                runId: request.RunId,
                budgetTokens: request.BudgetTokens,
                workspaceRoot: request.WorkspaceRoot,
                customInstructions: request.CustomInstructions,
                cancellationToken: ctx.RequestAborted))
            {
                var json = JsonSerializer.Serialize(evt, new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });
                await ctx.Response.WriteAsync($"data: {json}\n\n", ctx.RequestAborted);
                await ctx.Response.Body.FlushAsync(ctx.RequestAborted);
            }

            await ctx.Response.WriteAsync("data: [DONE]\n\n");
        });

        app.MapPost("/sessions", async (SessionCreateRequest request, IDurableStateStore store, HttpContext ctx) =>
        {
            var sessionId = Guid.NewGuid().ToString("N");
            await store.UpsertSessionAsync(sessionId, request.Description ?? "Migration session", [], ctx.RequestAborted);
            return Results.Ok(new { SessionId = sessionId, Status = "Created" });
        });

        app.MapGet("/sessions", async (IDurableStateStore store, HttpContext ctx) =>
        {
            var sessions = await store.ListSessionsAsync(ctx.RequestAborted);
            return Results.Ok(sessions.Select(s => new
            {
                s.SessionId,
                s.Description,
                s.CreatedAtUtc,
                s.MessageCount
            }));
        });

        app.MapPost("/sessions/{id}/chat", async (string id, ChatRequest request, IChatClient client, IDurableStateStore store, HttpContext ctx) =>
        {
            var session = await store.GetSessionAsync(id, ctx.RequestAborted);
            if (session is null)
                return Results.NotFound(new { Error = $"Session '{id}' not found." });

            var messages = session.Value.Messages
                .Select(m => new ChatMessage(m.Role.Equals("assistant", StringComparison.OrdinalIgnoreCase) ? ChatRole.Assistant : ChatRole.User, m.Content))
                .ToList();
            messages.Add(new ChatMessage(ChatRole.User, request.Message));

            var response = await client.GetResponseAsync(messages, new ChatOptions
            {
                Instructions = "You are a helpful migration assistant."
            }, ctx.RequestAborted);

            var assistantText = response.Messages.LastOrDefault()?.Text ?? string.Empty;
            var updatedHistory = session.Value.Messages.ToList();
            updatedHistory.Add(new ChatHistoryRow("user", request.Message));
            updatedHistory.Add(new ChatHistoryRow("assistant", assistantText));
            await store.UpsertSessionAsync(id, session.Value.Description, updatedHistory, ctx.RequestAborted);

            return Results.Ok(new
            {
                SessionId = id,
                Response = assistantText,
                MessageCount = updatedHistory.Count
            });
        });

        app.MapDelete("/sessions/{id}", async (string id, IDurableStateStore store, HttpContext ctx) =>
        {
            var deleted = await store.DeleteSessionAsync(id, ctx.RequestAborted);
            return deleted
                ? Results.Ok(new { Status = "Deleted", SessionId = id })
                : Results.NotFound(new { Error = $"Session '{id}' not found." });
        });

        app.MapGet("/admin/runs", async (IDurableStateStore store, HttpContext ctx) =>
            Results.Ok(await store.ListActiveRunsAsync(ctx.RequestAborted)));

        app.MapPost("/admin/runs/{runId}/terminate", async (string runId, IDurableStateStore store, HttpContext ctx) =>
        {
            var terminated = runtime.RunSupervisor.TryTerminate(runId);
            if (terminated)
            {
                await store.CompleteRunAsync(runId, "terminated", 0, "Terminated by operator", ctx.RequestAborted);
                await store.WriteAsync(new CodeMigrationAgent.Models.ReplayEvent(runId, "admin_action", "admin", "Run terminated via admin endpoint", DateTime.UtcNow, "admin"), ctx.RequestAborted);
                return Results.Ok(new { Status = "Terminated", RunId = runId });
            }
            return Results.NotFound(new { Error = $"Active run '{runId}' not found." });
        });

        app.MapPost("/admin/policy/override", async (PolicyOverrideRequest request, IDurableStateStore store, HttpContext ctx) =>
        {
            var row = new PolicyOverride
            {
                Key = request.Key,
                Value = request.Value,
                UpdatedBy = request.UpdatedBy,
                Reason = request.Reason,
                UpdatedAtUtc = DateTime.UtcNow
            };
            await store.AddPolicyOverrideAsync(row, ctx.RequestAborted);
            await store.WriteAsync(new CodeMigrationAgent.Models.ReplayEvent("policy", "policy_override", "admin", JsonSerializer.Serialize(row), DateTime.UtcNow, "admin"), ctx.RequestAborted);
            return Results.Ok(new { Status = "Applied", row.Key, row.Value, row.UpdatedBy, row.UpdatedAtUtc });
        });

        app.MapPost("/admin/prompts/rollback/{agentName}", async (string agentName, IDurableStateStore store, HttpContext ctx) =>
        {
            var targetVersion = ctx.Request.Query["version"].FirstOrDefault() ?? "stable-v1";
            var overrideRow = new PolicyOverride
            {
                Key = $"prompt:{agentName}:version",
                Value = targetVersion,
                UpdatedBy = "admin",
                Reason = "Prompt rollback",
                UpdatedAtUtc = DateTime.UtcNow
            };

            await store.AddPolicyOverrideAsync(overrideRow, ctx.RequestAborted);
            await store.WriteAsync(new CodeMigrationAgent.Models.ReplayEvent(
                "policy",
                "prompt_rollback",
                "admin",
                JsonSerializer.Serialize(overrideRow),
                DateTime.UtcNow,
                "admin"), ctx.RequestAborted);

            return Results.Ok(new { Status = "RolledBack", Agent = agentName, Version = targetVersion });
        });

        app.MapGet("/admin/policy/override", async (IDurableStateStore store, HttpContext ctx) =>
            Results.Ok(await store.GetPolicyOverridesAsync(ctx.RequestAborted)));

        app.MapGet("/admin/replay/{runId}", async (string runId, IDurableStateStore store, HttpContext ctx) =>
            Results.Ok(await store.GetReplayEventsAsync(runId, ctx.RequestAborted)));

        app.MapGet("/admin/replay-ui/{runId}", (string runId) =>
        {
            var html = $@"
                <html>
                  <head>
                    <title>Replay Timeline - {runId}</title>
                    <style>
                      body {{ font-family: 'Segoe UI', sans-serif; background: #f4f8fb; margin: 20px; color: #102a43; }}
                      .layout {{ display: grid; grid-template-columns: 340px 1fr; gap: 16px; }}
                      .panel {{ background: #fff; border: 1px solid #d9e2ec; border-radius: 10px; padding: 12px; }}
                      .row {{ margin-bottom: 10px; }}
                      .timeline {{ position: relative; }}
                      .event {{ border-left: 4px solid #486581; margin: 8px 0; padding: 8px 10px; background: #fff; border-radius: 6px; }}
                      .meta {{ font-size: 12px; color: #627d98; }}
                      .payload {{ font-family: Consolas, monospace; white-space: pre-wrap; font-size: 12px; max-height: 120px; overflow: auto; }}
                      .badge {{ display: inline-block; padding: 2px 8px; font-size: 11px; border-radius: 999px; background: #d9e2ec; margin-right: 4px; }}
                      input, select {{ width: 100%; padding: 8px; border: 1px solid #bcccdc; border-radius: 6px; }}
                    </style>
                  </head>
                  <body>
                    <h1>Replay Timeline</h1>
                    <div class='meta'>Run: <b>{runId}</b></div>
                    <div class='layout'>
                      <div class='panel'>
                        <div class='row'><label>Event Type</label><select id='typeFilter'><option value=''>All</option></select></div>
                        <div class='row'><label>Agent</label><select id='agentFilter'><option value=''>All</option></select></div>
                        <div class='row'><label>Search Payload</label><input id='search' placeholder='keyword' /></div>
                        <div class='row'><label>Min Relative Time (ms)</label><input id='minTime' type='number' value='0' /></div>
                      </div>
                      <div class='panel timeline' id='timeline'></div>
                    </div>
                    <script>
                      const runId = '{runId}';
                      const timelineEl = document.getElementById('timeline');
                      const typeFilter = document.getElementById('typeFilter');
                      const agentFilter = document.getElementById('agentFilter');
                      const search = document.getElementById('search');
                      const minTime = document.getElementById('minTime');

                      let allEvents = [];
                      let t0 = 0;

                      function fmtDate(d) {{ return new Date(d).toLocaleString(); }}
                      function esc(s) {{ return (s ?? '').replaceAll('<', '&lt;').replaceAll('>', '&gt;'); }}

                      function populateFilters() {{
                        const types = [...new Set(allEvents.map(e => e.eventType))];
                        const agents = [...new Set(allEvents.map(e => e.agent))];
                        types.forEach(t => typeFilter.innerHTML += `<option value='${{t}}'>${{t}}</option>`);
                        agents.forEach(a => agentFilter.innerHTML += `<option value='${{a}}'>${{a}}</option>`);
                      }}

                      function render() {{
                        const tf = typeFilter.value;
                        const af = agentFilter.value;
                        const q = search.value.toLowerCase();
                        const min = Number(minTime.value || '0');

                        const filtered = allEvents.filter(e =>
                          (!tf || e.eventType === tf) &&
                          (!af || e.agent === af) &&
                          (!q || (e.payload || '').toLowerCase().includes(q)) &&
                          ((new Date(e.timestampUtc).getTime() - t0) >= min));

                        timelineEl.innerHTML = filtered.map(e => {{
                          const rel = new Date(e.timestampUtc).getTime() - t0;
                          return `
                            <div class='event'>
                              <div><span class='badge'>${{e.eventType}}</span><span class='badge'>${{e.agent}}</span></div>
                              <div class='meta'>${{fmtDate(e.timestampUtc)}} | +${{rel}}ms</div>
                              <div class='payload'>${{esc(e.payload)}}</div>
                            </div>`;
                        }}).join('');
                      }}

                      async function load() {{
                        const resp = await fetch(`/admin/replay/${{runId}}`);
                        allEvents = await resp.json();
                        if (allEvents.length > 0) {{
                          t0 = new Date(allEvents[0].timestampUtc).getTime();
                        }}
                        populateFilters();
                        render();
                      }}

                      [typeFilter, agentFilter, search, minTime].forEach(el => el.addEventListener('input', render));
                      load();
                    </script>
                  </body>
                </html>";
            return Results.Content(html, "text/html");
        });

        app.MapGet("/admin/dashboard", async (IDurableStateStore store, HttpContext ctx) =>
        {
            var runs = await store.ListActiveRunsAsync(ctx.RequestAborted);
            var rows = new StringBuilder();
            foreach (var run in runs)
            {
                rows.AppendLine($"<tr><td>{run.RunId}</td><td>{run.TenantId}</td><td>{run.Status}</td><td>{run.Phase}</td><td>{run.UsedTokens}/{run.BudgetTokens}</td></tr>");
            }

            var html = $@"
                <html><head><title>Agent Ops Dashboard</title>
                <style>
                  body {{ font-family: Segoe UI, sans-serif; margin: 24px; background: #f7fbff; color: #102a43; }}
                  h1 {{ margin-bottom: 8px; }}
                  table {{ border-collapse: collapse; width: 100%; background: white; }}
                  td, th {{ border: 1px solid #bcccdc; padding: 8px; text-align: left; }}
                  th {{ background: #d9e2ec; }}
                  .card {{ padding: 12px; background: #fff; border: 1px solid #d9e2ec; margin-bottom: 16px; }}
                </style></head>
                <body>
                  <h1>Operations Dashboard</h1>
                  <div class=""card"">Active Runs: {runs.Count}</div>
                  <table>
                    <thead><tr><th>RunId</th><th>Tenant</th><th>Status</th><th>Phase</th><th>Usage</th></tr></thead>
                    <tbody>{rows}</tbody>
                  </table>
                </body></html>";
            return Results.Content(html, "text/html");
        });

        app.MapGet("/health", async (IDurableStateStore store, HttpContext ctx) => new
        {
            Status = "Healthy",
            Version = "3.0",
            Features = new[]
            {
                "Multi-agent governance (DAG validation + deterministic ownership + conflict merge)",
                "Durable SQLite state store for runs/sessions/checkpoints/replay",
                "Workflow resume from checkpoints",
                "Cost and quota control plane",
                "Prompt/config versioning with canary support",
                "Operations dashboard + run termination + policy overrides",
                "Replay timeline API"
                ,"Distributed durable queue workers"
                ,"Advanced replay timeline UI"
            },
            Agents = new[] { ArchitectAgentBuilder.AgentName, CoderAgentBuilder.AgentName, ReviewerAgentBuilder.AgentName, MigrationAgentBuilder.AgentName },
            runtime.MaxTokensPerAgent,
            runtime.MaxParallelWorkers,
            runtime.McpToolsLoaded,
            ActiveRuns = (await store.ListActiveRunsAsync(ctx.RequestAborted)).Count,
            runtime.SafetyPolicy.AllowedPathRoots
        });

        app.MapGet("/agents", () =>
        {
            return Results.Ok(new[]
            {
                new { Name = ArchitectAgentBuilder.AgentName, Role = "Analyzes codebases, creates migration plans", Middleware = new[] { "Security", "Performance", "FunctionCalling" } },
                new { Name = CoderAgentBuilder.AgentName, Role = "Executes coding tasks, makes edits, runs builds", Middleware = new[] { "Guardrail", "Security", "Performance", "FunctionCalling" } },
                new { Name = ReviewerAgentBuilder.AgentName, Role = "Reviews code quality, security, build health", Middleware = new[] { "Security", "Performance", "FunctionCalling" } },
                new { Name = MigrationAgentBuilder.AgentName, Role = "Applies changes, runs builds, commits via git", Middleware = new[] { "Guardrail", "Security", "Performance", "FunctionCalling" } }
            });
        });
    }
}
