using Azure.AI.OpenAI;
using Azure.Monitor.OpenTelemetry.AspNetCore;
using CodeMigrationAgent.Agents;
using CodeMigrationAgent.Middlewares;
using CodeMigrationAgent.Models;
using CodeMigrationAgent.Platform;
using CodeMigrationAgent.Tools;
using CodeMigrationAgent.Workflows;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using OpenTelemetry.Trace;
using System.ClientModel;

namespace CodeMigrationAgent.Composition;

public sealed class AppRuntimeState
{
    public required AgentSafetyPolicy SafetyPolicy { get; init; }
    public required int MaxTokensPerAgent { get; init; }
    public required int MaxParallelWorkers { get; init; }
    public required int McpToolsLoaded { get; init; }
    public required IDurableStateStore DurableStore { get; init; }
    public required RunSupervisor RunSupervisor { get; init; }
}

public static class StartupCompositionExtensions
{
    public static AgentSafetyPolicy ConfigureSafetyPolicy(this WebApplicationBuilder builder)
    {
        var safetyPolicy = builder.Configuration.GetSection("AgentSafety").Get<AgentSafetyPolicy>() ?? new AgentSafetyPolicy();
        if (safetyPolicy.AllowedPathRoots.Length == 0)
        {
            safetyPolicy.AllowedPathRoots = new[] { builder.Environment.ContentRootPath };
        }

        var normalizedAllowedRoots = safetyPolicy.AllowedPathRoots
            .Where(root => !string.IsNullOrWhiteSpace(root))
            .Select(Path.GetFullPath)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();

        safetyPolicy.AllowedPathRoots = normalizedAllowedRoots;
        builder.Services.AddSingleton(safetyPolicy);

        Environment.SetEnvironmentVariable("CMA_ALLOWED_PATH_ROOTS", string.Join(Path.PathSeparator, normalizedAllowedRoots));
        Environment.SetEnvironmentVariable("CMA_BLOCKED_COMMAND_PATTERNS", string.Join("|", safetyPolicy.BlockedPromptSubstrings));
        Environment.SetEnvironmentVariable("CMA_TERMINAL_TIMEOUT_MS",
            builder.Configuration["AgentSafety:TerminalTimeoutMs"] ?? "120000");

        return safetyPolicy;
    }

    public static async Task<IDurableStateStore> ConfigurePlatformServicesAsync(this WebApplicationBuilder builder)
    {
        builder.Services.AddOpenApi();
        builder.Services.AddSwaggerGen();

        builder.Logging.ClearProviders();
        builder.Logging.AddSimpleConsole(o =>
        {
            o.SingleLine = true;
            o.TimestampFormat = "HH:mm:ss ";
        });

        builder.Services.AddOpenTelemetry()
            .UseAzureMonitor(options =>
            {
                var connStr = builder.Configuration["APPLICATIONINSIGHTS_CONNECTION_STRING"];
                if (!string.IsNullOrEmpty(connStr))
                {
                    options.ConnectionString = connStr;
                }
            })
            .WithTracing(tracing =>
            {
                tracing.AddSource(PipelineTelemetry.SourceName);
                tracing.AddSource("CodeMigrationAgent.Performance");
                tracing.AddSource("*Microsoft.Extensions.AI");
                tracing.AddSource("*Microsoft.Extensions.Agents*");
            });

        var dataDir = Path.Combine(builder.Environment.ContentRootPath, "data");
        var dbPath = Path.Combine(dataDir, "agent-platform.db");
        var durableStore = new SqliteDurableStateStore(dbPath);
        await durableStore.InitializeAsync();
        builder.Services.AddSingleton<IDurableStateStore>(durableStore);
        RuntimeObservability.ReplayWriter = durableStore;
        return durableStore;
    }

    public static IChatClient BuildChatClient(this WebApplicationBuilder builder)
    {
        var endpoint = builder.Configuration["AZURE_OPENAI_ENDPOINT"]
            ?? "https://your-resource-name.openai.azure.com/";
        var stableDeployment = builder.Configuration["AZURE_OPENAI_DEPLOYMENT_NAME"] ?? "gpt-5.3-codex";
        var canaryDeployment = builder.Configuration["AZURE_OPENAI_CANARY_DEPLOYMENT_NAME"];
        var apiKey = builder.Configuration["AZURE_OPENAI_API_KEY"]
            ?? throw new InvalidOperationException(
                "AZURE_OPENAI_API_KEY is not configured. " +
                "Set it via environment variables, dotnet user-secrets, or Azure Key Vault.");

        var isDev = builder.Environment.IsDevelopment();
        IChatClient BuildFromDeployment(string deployment) =>
            new AzureOpenAIClient(new Uri(endpoint), new ApiKeyCredential(apiKey))
                .GetChatClient(deployment)
                .AsIChatClient()
                .AsBuilder()
                .UseOpenTelemetry(
                    sourceName: "CodeMigrationAgent.LLM",
                    configure: cfg => cfg.EnableSensitiveData = isDev)
                .Build();

        var stable = BuildFromDeployment(stableDeployment);
        IChatClient? canary = string.IsNullOrWhiteSpace(canaryDeployment) ? null : BuildFromDeployment(canaryDeployment);
        return new AdaptiveRoutingChatClient(stable, canary);
    }

    public static async Task<IList<AITool>> LoadMcpToolsAsync(this WebApplicationBuilder builder, McpToolProvider mcpProvider)
    {
        var mcpServers = builder.Configuration.GetSection("McpServers").Get<McpServerConfig[]>();
        if (mcpServers is { Length: > 0 })
        {
            var tools = await mcpProvider.ConnectFromConfigAsync(mcpServers);
            Console.WriteLine($"[Program] Loaded {tools.Count} MCP tools from {mcpServers.Length} server(s).");
            return tools;
        }

        Console.WriteLine("[Program] No MCP servers configured. Skipping MCP tool loading.");
        return new List<AITool>();
    }

    public static AppRuntimeState RegisterDomainServices(
        this WebApplicationBuilder builder,
        IChatClient chatClient,
        IList<AITool> mcpTools,
        AgentSafetyPolicy safetyPolicy,
        IDurableStateStore durableStore)
    {
        var controlOptions = builder.Configuration.GetSection("ControlPlane").Get<ControlPlaneOptions>() ?? new ControlPlaneOptions();
        var promptCatalog = builder.Configuration.GetSection("PromptCatalog").Get<PromptCatalogOptions>() ?? new PromptCatalogOptions();
        var projectPrompting = builder.Configuration.GetSection("ProjectPrompting").Get<ProjectPromptingOptions>() ?? new ProjectPromptingOptions();
        var queueOptions = builder.Configuration.GetSection("QueueWorkers").Get<QueueWorkerOptions>() ?? new QueueWorkerOptions();

        if (string.IsNullOrWhiteSpace(projectPrompting.DefaultWorkspaceRoot))
        {
            projectPrompting.DefaultWorkspaceRoot = builder.Environment.ContentRootPath;
        }

        builder.Services.AddSingleton(controlOptions);
        builder.Services.AddSingleton(promptCatalog);
        builder.Services.AddSingleton(projectPrompting);
        builder.Services.AddSingleton<ProjectInstructionService>();
        builder.Services.AddSingleton(queueOptions);
        builder.Services.AddSingleton<ControlPlaneService>();
        builder.Services.AddSingleton<PromptVersioningService>();
        builder.Services.AddSingleton<GovernanceService>();
        builder.Services.AddHostedService<QueueWorkerHostedService>();

        var runSupervisor = new RunSupervisor();
        builder.Services.AddSingleton(runSupervisor);

        var architectAgent = ArchitectAgentBuilder.Build(chatClient);
        var coderAgent = CoderAgentBuilder.Build(chatClient);
        var reviewerAgent = ReviewerAgentBuilder.Build(chatClient);

        var agentFunctionTools = new List<AITool>
        {
            architectAgent.AsAIFunction(),
            coderAgent.AsAIFunction(),
            reviewerAgent.AsAIFunction()
        };

        var migrationAgent = MigrationAgentBuilder.Build(
            chatClient,
            mcpTools: mcpTools.Count > 0 ? mcpTools : null,
            agentTools: agentFunctionTools);

        builder.Services.AddKeyedSingleton<AIAgent>(ArchitectAgentBuilder.AgentName, architectAgent);
        builder.Services.AddKeyedSingleton<AIAgent>(CoderAgentBuilder.AgentName, coderAgent);
        builder.Services.AddKeyedSingleton<AIAgent>(ReviewerAgentBuilder.AgentName, reviewerAgent);
        builder.Services.AddKeyedSingleton<AIAgent>(MigrationAgentBuilder.AgentName, migrationAgent);

        AgentDelegationTools.RegisterAgent(ArchitectAgentBuilder.AgentName, architectAgent);
        AgentDelegationTools.RegisterAgent(CoderAgentBuilder.AgentName, coderAgent);
        AgentDelegationTools.RegisterAgent(ReviewerAgentBuilder.AgentName, reviewerAgent);
        AgentDelegationTools.RegisterAgent(MigrationAgentBuilder.AgentName, migrationAgent);

        var maxTokensPerAgent = int.TryParse(builder.Configuration["MAX_TOKENS_PER_AGENT"], out var t) ? t : 200_000;
        var maxParallelWorkers = int.TryParse(builder.Configuration["MAX_PARALLEL_WORKERS"], out var p) ? p : 8;

        builder.Services.AddSingleton(sp => new HybridMigrationPipeline(
            sp.GetRequiredService<IChatClient>(),
            sp.GetRequiredService<ILogger<HybridMigrationPipeline>>(),
            sp.GetRequiredService<IDurableStateStore>(),
            sp.GetRequiredService<ControlPlaneService>(),
            sp.GetRequiredService<PromptVersioningService>(),
            sp.GetRequiredService<GovernanceService>(),
            sp.GetRequiredService<RunSupervisor>(),
            maxTokensPerAgent,
            maxParallelWorkers));

        builder.Services.AddSingleton(sp => new StreamingPipeline(
            sp.GetRequiredService<HybridMigrationPipeline>()));

        return new AppRuntimeState
        {
            SafetyPolicy = safetyPolicy,
            MaxTokensPerAgent = maxTokensPerAgent,
            MaxParallelWorkers = maxParallelWorkers,
            McpToolsLoaded = mcpTools.Count,
            DurableStore = durableStore,
            RunSupervisor = runSupervisor
        };
    }
}
