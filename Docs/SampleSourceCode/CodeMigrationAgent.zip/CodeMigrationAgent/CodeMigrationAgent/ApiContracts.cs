using Microsoft.Agents.AI;

namespace CodeMigrationAgent;

public record MigrationRequest(
    string Prompt,
    string? TenantId = null,
    string? RunId = null,
    int? BudgetTokens = null,
    string? WorkspaceRoot = null,
    string? CustomInstructions = null);
public record SessionCreateRequest(string? Description = null);
public record ChatRequest(string Message);

public record PolicyOverrideRequest(string Key, string Value, string UpdatedBy, string Reason);

/// <summary>In-memory session tracker for multi-turn conversations.</summary>
public sealed class SessionInfo
{
    public string SessionId { get; set; } = string.Empty;
    public AIAgent Agent { get; set; } = null!;
    public AgentSession Session { get; set; } = null!;
    public DateTime CreatedAt { get; set; }
    public string Description { get; set; } = string.Empty;
    public int MessageCount { get; set; }
}
