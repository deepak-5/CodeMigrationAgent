---
trigger: always_on
---


# 🚀 Prompt: Build the "Amazing Code Migration Coding Agent"

**Role:** You are a Principal AI Architect and Lead Developer specializing in the **Microsoft Agent Framework**.  
**Objective:** Design and implement a production-ready, enterprise-grade **Code Migration Coding Agent** system.  
**Goal:** Create the world's best coding agent capable of autonomous code migration, refactoring, and modernization using agentic workflows, advanced tooling, and robust orchestration.

## 1. System Architecture & Orchestration
Do not build a single monolithic agent. Instead, construct a **Multi-Agent Workflow** using `AgentWorkflowBuilder` to orchestrate specialized agents.
*   **Orchestration Pattern:** Use a **Sequential Workflow** for the migration pipeline (Plan → Code → Review → Test) with **Concurrent Branches** for parallel file processing where possible.
*   **Agent Roles:**
    1.  **Architect Agent:** Analyzes legacy code and creates a migration plan (Structured Output).
    2.  **Coder Agent:** Executes the actual code transformation (uses Code Interpreter).
    3.  **Reviewer Agent:** Validates code quality and security (uses Guardrails).
    4.  **Migration Agent:** Handles file I/O and commit operations (uses MCP/File Search).
*   **State Management:** Implement `AgentSession` for persistent conversation state across long-running migration tasks. Use `ChatHistoryProvider` with a `MessageCountingChatReducer` to manage context limits.

## 2. Required Tooling & Capabilities
Equip the agents with the full suite of production tools defined in the Microsoft Agent Framework documentation:
*   **Code Execution:** Integrate `CodeInterpreterToolDefinition` to allow agents to write, run, and test Python/C# snippets in a sandboxed environment.
*   **Knowledge Retrieval:** 
    *   Use `FileSearchToolDefinition` with vector store IDs to search uploaded legacy codebases.
    *   Use `WebSearchToolDefinition` to fetch latest framework documentation (e.g., .NET 9, Azure updates).
*   **External Integration (MCP):** 
    *   Implement **Model Context Protocol (MCP)** clients to connect to external servers (e.g., GitHub, File System, SQL).
    *   Use `McpClientFactory` to retrieve tools from servers like `@modelcontextprotocol/server-github` for direct repo manipulation.
    *   **Security:** Ensure MCP tools support `RequireApproval` settings for critical actions (e.g., commits).
*   **Function Tools:** Create custom C# function tools using `AIFunctionFactory.Create` for specific migration utilities (e.g., `ConvertSyntax`, `AnalyzeDependencies`).

## 3. Production Readiness & Safety
This system must be safe for enterprise use. Implement the following:
*   **Guardrails & Middleware:** 
    *   Create `AgentRunMiddleware` to inspect inputs/outputs for sensitive data (PII, secrets).
    *   Implement `FunctionCallingMiddleware` to enforce **Human-in-the-Loop** approvals for critical tool calls (e.g., `ApprovalRequiredAIFunction`).
    *   Add `ExceptionHandlingMiddleware` to catch timeouts and provide graceful fallback responses.
*   **Structured Output:** Enforce JSON schemas for migration plans using `ChatResponseFormat.ForJsonSchema` to ensure downstream agents can parse plans reliably.
*   **Background Responses:** Enable `AllowBackgroundResponses = true` for long-running migration tasks, using continuation tokens to resume interrupted streams.

## 4. Hosting & Infrastructure
Build the system as a hostable service using **ASP.NET Core**:
*   **Dependency Injection:** Register agents and workflows using `IHostApplicationBuilder` (`builder.AddAIAgent`, `builder.AddWorkflow`).
*   **Hosting Protocol:** Expose the agent via **A2A Protocol** (`builder.Services.AddA2AServer()`) or **OpenAI-Compatible Endpoints** for broader client support.
*   **Observability:** 
    *   Integrate **OpenTelemetry** for traces, logs, and metrics.
    *   Enable sensitive data logging *only* in development (`enableSensitiveData: true`).
    *   Configure exporters for **Azure Monitor** (`AddAzureMonitorTraceExporter`).

## 5. Implementation Guidelines
*   **Language:** C# (.NET 10).
*   **Packages:** Use `Microsoft.Agents.AI`, `Microsoft.Agents.AI.OpenAI`, `Azure.AI.OpenAI`, `ModelContextProtocol`, `OpenTelemetry`.
*   **Code Style:** Async/await throughout, strong typing, dependency injection, and separation of concerns.
*   **Documentation:** Include XML comments and README instructions for environment variables (`AZURE_OPENAI_ENDPOINT`, `AZURE_FOUNDRY_PROJECT_ENDPOINT`).

## 6. Deliverables
1.  **Project Structure:** A solution file with separate projects for Agents, Workflows, Tools, and Hosting.
2.  **Core Code:** 
    *   Workflow definition (`AgentWorkflowBuilder`).
    *   Agent definitions (`ChatClientAgent` with specific instructions).
    *   Middleware implementations (Security, Logging, Approval).
    *   Hosting setup (`Program.cs` with DI registration).
3.  **Configuration:** Sample `appsettings.json` and `.env` files.
4.  **Testing:** Unit tests for middleware and workflow logic.

**Constraint:** Adhere strictly to the Microsoft Agent Framework patterns found in the provided documentation (e.g., use `AsAIAgent`, `AgentSession`, `WorkflowContext`). Do not use deprecated libraries like standalone AutoGen or Semantic Kernel v1; use the unified Agent Framework.

**Start by outlining the solution architecture, then proceed to generate the core code files.**

***
